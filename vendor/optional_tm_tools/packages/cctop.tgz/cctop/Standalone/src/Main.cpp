/*
 * CCTOP executable for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Main.cpp
 *
 *  Created on: 2014.06.27.
 *      Author: "Istvan Remenyi"
 */

#include "Cache/CacheManager.h"
#include "Utils/StringUtils.h"
#include "CCTopLib.h"

#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>


const char* STR_CMD 				= "-cmd=";
const char* STR_INPUT 				= "-input=";
const char* STR_RESULT 				= "-result=";
const char* STR_PARAM 				= "-param=";
const char* STR_CCTOPID				= "-cctopId=";
const char* STR_HMMTOP				= "-hmmtop=";
const char* STR_DISABLEDMETHODS		= "-disableMethods=";
const char* STR_MINMAX				= "-ignoreMinMax";
const char* STR_ENABLEEXPDUP		= "-enableExpDup";
const char* STR_UPDATE 				= "-u";
const char* STR_CLEAR 				= "-clear";
const char* STR_TMFILTER			= "-tmFilter";
const char* STR_SIGPRED				= "-sigPred=";

const int STR_CMD_LEN 				= strlen(STR_CMD);
const int STR_INPUT_LEN 			= strlen(STR_INPUT);
const int STR_RESULT_LEN 			= strlen(STR_RESULT);
const int STR_PARAM_LEN 			= strlen(STR_PARAM);
const int STR_UPDATE_LEN 			= strlen(STR_UPDATE);
const int STR_CLEAR_LEN 			= strlen(STR_CLEAR);
const int STR_CCTOPID_LEN 			= strlen(STR_CCTOPID);
const int STR_DISABLEDMETHODS_LEN 	= strlen(STR_DISABLEDMETHODS);
const int STR_HMMTOP_LEN 			= strlen(STR_HMMTOP);
const int STR_MINMAX_LEN 			= strlen(STR_MINMAX);
const int STR_ENABLEEXPDUP_LEN		= strlen(STR_ENABLEEXPDUP);
const int STR_TMFILTER_LEN			= strlen(STR_TMFILTER);
const int STR_SIGPRED_LEN			= strlen(STR_SIGPRED);

inline bool checkParameter(int& argc, char**& argv, const char* param)
{
	return (!std::strncmp(argv[argc], param, std::strlen(param)));
}


void validate(const char* str, const char* alphabet)
{
	int strLen = strlen(str);
	int alpLen = strlen(alphabet);
	for(int i = 0; i<strLen;i++)
	{
		bool match = false;
		for(int j = 0; j<alpLen&&!match;j++)
		{
			match = str[i] == alphabet[j];
		}
		if(!match)
			std::cerr << "Missmatch at:" << i << "(" << str[i] << ")"<< std::endl;
	}
}



int main ( int argc, char **argv )
{
	std::string inputFile;
	std::string resultFile;
	std::string paramFile;
	std::string cctopId;
	std::string hmmtopParam;
	std::string disabledMethods;
	std::string sigPred;
	bool isUpdate = false;
	bool isClear = false;
	bool ignoreMinMax = false;
	bool expDupEnabled = false;
	bool useTmFilter = false;

	for(int i = 0; i < argc; i++)
	{
		if(checkParameter(i, argv, STR_INPUT))
		{
			const char* input = argv[i] + STR_INPUT_LEN;
			inputFile = input;
		}else
			if(checkParameter(i, argv, STR_RESULT))
			{
				const char* input = argv[i] + STR_RESULT_LEN;
				resultFile = input;
			}else
				if(checkParameter(i, argv, STR_PARAM))
				{
					const char* param = argv[i] + STR_PARAM_LEN;
					paramFile = param;
				}else
					if(checkParameter(i, argv, STR_UPDATE))
					{
						isUpdate = true;
					}else
						if(checkParameter(i, argv, STR_CLEAR))
						{
							isClear = true;
						}else
							if(checkParameter(i, argv, STR_CCTOPID))
							{
								const char* param = argv[i] + STR_CCTOPID_LEN;
								cctopId = param;
							}else
								if(checkParameter(i, argv, STR_HMMTOP))
								{
									const char* param = argv[i] + STR_HMMTOP_LEN;
									hmmtopParam = param;
								}else
									if(checkParameter(i, argv, STR_MINMAX))
									{
										ignoreMinMax = true;
									}else
										if(checkParameter(i, argv, STR_DISABLEDMETHODS))
										{
											const char* param = argv[i] + STR_DISABLEDMETHODS_LEN;
											disabledMethods = param;
											std::cerr << "Disabled methods:" << disabledMethods << std::endl;
										}else
											if(checkParameter(i, argv, STR_ENABLEEXPDUP))
											{
												expDupEnabled = true;
											}else
												if(checkParameter(i, argv, STR_TMFILTER))
												{
													useTmFilter = true;
												}else
													if(checkParameter(i, argv, STR_SIGPRED))
													{
														const char* param = argv[i] + STR_SIGPRED_LEN;
														sigPred = param;
													}
	}

	std::cerr << "InputFile: " << inputFile << std::endl;

	if(!inputFile.empty() && isClear)
	{
		if(isClear)
		{
			CCTOP::CCTopLib lib;
			if(lib.loadParams(paramFile))
			{
				CCTOP::Cache::CacheManager& cache = CCTOP::Cache::CacheManager::instance();
				cache.setRootFolder(lib.getLibParam("CACHE_FOLDER"));

				std::string sequence;
				std::string result;
				CCTOP::Utils::loadFirstLine(inputFile, sequence);

				FILE* pFile = fopen (inputFile.c_str(), "r");
				std::string checksum = cache.generateChecksumForStream(pFile);

				//0x6d3118 "d41d8cd98f00b204e9800998ecf8427e"
				cache.lockChecksum(checksum);

				if(cache.removeContent(inputFile, checksum))
				{
					std::cout << "Removing from cache!" << std::endl;
				}else
				{
					std::cout << "Nothing to do!" << std::endl;
				}
				cache.unlockChecksum(checksum);
			}
		}
	}else
	{
		if(inputFile.empty() || resultFile.empty() || paramFile.empty() || cctopId.empty())
		{
			std::cerr << "Program usage: cctop " << std::endl
					<< STR_INPUT << " <input sequence file - req.> " << std::endl
					<< STR_RESULT << " <result file - req.> " << std::endl
					<< STR_PARAM << " <parameter file - req.> " << std::endl
					<< STR_CCTOPID << " <cctopId - req.> " << std::endl
					<< STR_HMMTOP << " <hmmtop - opt.> " << std::endl
					<< STR_MINMAX << " <ignore min-max - opt.> " << std::endl
					<< STR_UPDATE << " <update - opt.> " << std::endl
					<< STR_CLEAR << " <clear - opt.> "
					<< std::endl;
		}else
		{
			std::cout << "Checking cache!" << std::endl;
			CCTOP::CCTopLib lib;
			if(lib.loadParams(paramFile))
			{
				CCTOP::Core::SignalMode sigMode = CCTOP::Core::SIGNALMODE_UNDEFINED;
				if(sigPred.empty())
					sigPred = lib.getLibParam("SIGNALTYPE");
				//UNIPROT|SIGNALP|TOPDB|EXT
				if(!strcmp(sigPred.c_str(), "UNIPROT"))
					sigMode = CCTOP::Core::SIGNALMODE_UNIPROT;
				else
					if(!strcmp(sigPred.c_str(), "SIGNALP"))
						sigMode = CCTOP::Core::SIGNALMODE_SIGNALP;
					else
						if(!strcmp(sigPred.c_str(), "TOPDB"))
							sigMode = CCTOP::Core::SIGNALMODE_TOPDB;
						else
							if(!strcmp(sigPred.c_str(), "EXT"))
								sigMode = CCTOP::Core::SIGNALMODE_UNIPROT_EN;

				CCTOP::Core::TransitMode tranMode = CCTOP::Core::TRANSITMODE_UNDEFINED;
				std::string transitM = lib.getLibParam("TRANSITTYPE");
				if(!strcmp(transitM.c_str(), "UNIPROT"))
					tranMode = CCTOP::Core::TRANSITMODE_UNIPROT;
				else
					if(!strcmp(transitM.c_str(), "TOPDB"))
						tranMode = CCTOP::Core::TRANSITMODE_TOPDB;

				std::string str = lib.getLibParam("ENABLE_MEMBRAIN");
				bool activateMembrain = !str.empty() && str[0] == 't';

				//cacheing
				CCTOP::Cache::CacheManager& cache = CCTOP::Cache::CacheManager::instance();
				cache.setRootFolder(lib.getLibParam("CACHE_FOLDER"));

				std::string sequence;
				std::string result;
				CCTOP::Utils::loadFirstLine(inputFile, sequence);

				FILE* pFile = fopen (inputFile.c_str(), "r");
				std::string checksum = cache.generateChecksumForStream(pFile);

				validate(sequence.c_str(),"ACDEFGHIKLMNPQRSTVWY-#");

				//0x6d3118 "d41d8cd98f00b204e9800998ecf8427e"
				cache.lockChecksum(checksum);

				std::string cInputPath;
				std::string cResultPath;
				bool exists = cache.isExists(inputFile, checksum, cInputPath, cResultPath);
				bool served = false;
				bool cacheable = false;

				if(exists)
				{
					served = cache.serveContent(inputFile, resultFile, checksum);

					//update is is stronger parameter :D
					if(isUpdate)
					{
						std::cout << "Updateing content!" << std::endl;

						lib.initialize(ignoreMinMax, expDupEnabled);
						lib.getMethodContext().activateMembrain(activateMembrain);

						if(sequence.empty())
						{
							std::cerr << "Empty sequence!" << std::endl;
						}else
						{
							CCTOP::Core::SequenceContext seqContext;
							std::vector<std::string> vec;
							CCTOP::Utils::splitSafe(disabledMethods, ',', vec);
							for(unsigned int i=0; i<vec.size(); i++)
								seqContext.addDisabledMethod(vec[i]);

							seqContext.setTMFilter(useTmFilter);
							seqContext.setSequence(sequence);
							seqContext.setCCTopID(cctopId);
							seqContext.setSequenceChecksum(checksum);
							seqContext.setHMMTopParam(hmmtopParam);
							//Set Signaling mode
							seqContext.setSignalMode(sigMode);
							seqContext.setTransitMode(tranMode);
							//Call The thing :)
							lib.update(seqContext, cResultPath, result);

							CCTOP::Utils::saveFile(resultFile, result);
							cacheable = true;
							served = true;
						}
					}else
					{
						std::cout << "Serving from cache!" << std::endl;
						served = true;
					}
				}

				//update can fail, then should generate new content
				if(!served && !isClear)
				{
					std::cout << "Creating content!" << std::endl;
					lib.initialize(ignoreMinMax, expDupEnabled);
					lib.getMethodContext().activateMembrain(activateMembrain);

					if(sequence.empty())
					{
						std::cerr << "Empty sequence!" << std::endl;
					}else
					{
						CCTOP::Core::SequenceContext seqContext;
						std::vector<std::string> vec;
						CCTOP::Utils::splitSafe(disabledMethods, ',', vec);
						for(unsigned int i=0; i<vec.size(); i++)
							seqContext.addDisabledMethod(vec[i]);

						seqContext.setTMFilter(useTmFilter);
						seqContext.setSequence(sequence);
						seqContext.setCCTopID(cctopId);
						seqContext.setSequenceChecksum(checksum);
						seqContext.setHMMTopParam(hmmtopParam);
						//Parse input&hits
						lib.preProcess(seqContext);
						//Set Signaling mode
						seqContext.setSignalMode(sigMode);
						seqContext.setTransitMode(tranMode);
						//Call The thing :)
						lib.process(seqContext, result);

						CCTOP::Utils::saveFile(resultFile, result);
						cacheable = true;
					}
				}

				if(cacheable)
				{
					bool cached = cache.updateContent(inputFile, resultFile, cInputPath, cResultPath, checksum);
					if(cached)
					{
						std::cout << "Content is cached!" << std::endl;
					}else
					{
						std::cout << "Content caching failed!" << std::endl;
					}
				}

				cache.unlockChecksum(checksum);

				if(pFile)
					fclose(pFile);
			}
		}
	}

	return 0;
}
