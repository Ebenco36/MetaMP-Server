#!/bin/bash
fastafiles=$1
root=`dirname $0`



if [[ ! -d $fastafiles/preds ]]; then
	mkdir $fastafiles/preds
fi

for prot in $(ls $fastafiles/*.fa); do
	if [[ ! -a $fastafiles/preds/${prot%.*}.memsat_svm ]]; then
		perl $root/memsat-svm/run_memsat-svm.pl -p 1 $prot -j $fastafiles/preds/
	else
		echo "$prot HAS BEEN IS GENERATED"
	fi
done
