#!/bin/bash

if [[ ! $1 == *\** ]]
then
	if [ -d "$1" ]; then
		rm -rf "$1"	
	fi
fi
