#!/bin/bash

## remove contents of scratch directory
#rm -fr $scratch/*

## make sure we're in the correct working directory
#cd /philius/philius_run

if [ -d "$1" ]; then
	rmdir "$1"	
fi

mkdir -p $1
cp $2 $1/seq

scratch=$1
cd $scratch

## make the directory we're going to be working in

## copy over two files from the gmtk/params directory
cp ../gmtk/params/model_test2.master.Viterbi ./
cp ../gmtk/params/commonParams.txt ./

## the first thing we need to do is to translate the input sequence from
## FASTA format to GMTK format ...
##	command-line argument : input FASTA file name
##	outputs : creates two output files in the same directory as the
##		the input FASTA file, one is called <name>.obs (where "name"
##		is taken from the ">" header line in the FASTA file), and
##		the other file is called "input.list"
python ../src/python/faa2gmtk.py ./seq

## next we need to create two other "list" files
rm -f ./curPostpFiles.list
sed "s/\.obs/\.test\.postp/g" ./input.list > ./curPostpFiles.list

rm -f ./testVitFiles.list
sed "s/\.obs/\.testVit\.anyType\.bin/g" ./input.list > ./testVitFiles.list

date
echo " first pass : gmtkJT "

../bin/gmtkJT  -strFile ../gmtk/params/model_test1.str \
            -triFile ../gmtk/params/model_test1.mytrifile \
            -of1 ./input.list -nf1 0 -ni1 1 -fmt1 ascii \
            -inputMasterFile ../gmtk/params/model_test1.master.Viterbi \
            -inputTrainableParameters ../gmtk/params/learnedParamsALL.out \
            -pCliquePrintRange 1:2 \
            -cCliquePrintRange 1:1 \
            -eCliquePrintRange 1:2 \
            -doDist \
            -cptNormThreshold 10. \
            -verbosity 1 > ./runJT_test.out

date
echo " preparing for second pass "

python ../src/python/prepVEdata10.py ./input.list ./runJT_test.out test.postp

date
echo " second pass : gmtkViterbi "

../bin/gmtkViterbiNew \
	-strFile ../gmtk/params/model_test2_anyType.str \
        -of1 ./input.list -nf1 0 -ni1 1 -fmt1 ascii \
        -inputMasterFile ./model_test2.master.Viterbi \
        -inputTrainableParameters ../gmtk/params/learnedParamsALL.out \
        -dumpNames ../gmtk/params/new.dumpNames.list \
        -ofilelist ./testVitFiles.list \
        -cptNormThreshold 10. \
        -verbosity 19 > ./runVit_test.out

grep "log(prob(e" ./runVit_test.out > ./pass2.probs.anyType.out

date
echo " writing report file "

python ../src/python/writeReportOnly.py ./testVitFiles.list ./runJT_test.out ./pass2.probs.anyType.out


