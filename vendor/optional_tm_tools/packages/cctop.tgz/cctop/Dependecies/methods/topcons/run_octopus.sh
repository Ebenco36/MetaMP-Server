#!/bin/bash

# Run both OCTOPUS-TMHMM for a number of sequences in $2 with names in $1
if (( $# < 8 )); then
    /bin/echo "Usage: $0 <protein names file> <fasta directory> <output directory> <blast directory> <blast database> "\
		"<topcons-dir> <modhmm-dir> <makemat>";
    exit 1;
fi

names=$1;
fastadir=$2;
outputDir=$3;
blastDir=$4;
blastall=$4/bin/blastall;
blastpgp=$4/bin/blastpgp;
blastdb=$5;
topconsdir=$6;
modhmmdir=$7;
makemat=$8

my_dir=`dirname $0`

/bin/echo "Running Blast";
$my_dir/run_blast.sh ${names} ${fastadir} ${outputDir} ${blastall} ${blastdb}
/bin/echo "Running msa2prf";
$my_dir/msa2prf.sh ${names} ${fastadir} ${outputDir} ${outputDir}
/bin/echo "Running run_psiblast";
$my_dir/run_psiblast.sh ${names} ${fastadir} ${outputDir} ${outputDir} ${blastpgp} ${blastdb} ${makemat}
/bin/echo "Running mtx2prf";
$my_dir/mtx2prf.sh ${names} ${outputDir} ${outputDir}
/bin/echo "Running OCTOPUS";
$my_dir/OCTOPUS.sh ${names} ${outputDir} ${outputDir} ${outputDir} ${outputDir}
cp ${outputDir}/seq.top ${outputDir}/octopus.top
/bin/echo "END";

