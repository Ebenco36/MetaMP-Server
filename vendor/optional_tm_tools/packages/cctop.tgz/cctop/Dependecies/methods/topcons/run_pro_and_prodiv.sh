#!/bin/bash

# Run both PRO- and PRODIV-TMHMM for a number of sequences in $2 with names in $1
if (( $# < 6 )); then
    /bin/echo "Usage: $0 <protein names file> <fasta directory> <output directory> <blastall-executable> <database> "\
		"<tmp-dir> <topcons-dir> <modhmm-dir>";
    exit 1;
fi

set -e

names=$1;
fastadir=$2;
outdir=$3;
blastall=$4/bin/blastall;
db=$5;
tmpdir=$6;
topconsdir=$7;
modhmmdir=$8;

paths_tmp=${tmpdir}/prodivtmhmm.names.txt;
outfile=${tmpdir}/prodivtmhmm_modhmm.xml;
outfile_top=${tmpdir}/prodivtmhmm_modhmm.top;
blastmsadir=$outdir/blast_msa;
[[ -d $blastmsadir ]] || mkdir -pv $blastmsadir;
modhmm_tmpdir=${tmpdir}/prodivtmhmm_modhmm_tmp;
[[ -d $modhmm_tmpdir ]] || mkdir -pv $modhmm_tmpdir;

while read name; do /bin/echo $modhmm_tmpdir/$name.mod; done < $names > $paths_tmp;

/bin/echo `date` "Running BLAST";
${topconsdir}/prodiv_tmhmm/bin/run_blast.sh $names $fastadir $blastmsadir $blastall $db;

/bin/echo `date` "Converting BLAST result files to modhmm-format";
${topconsdir}/prodiv_tmhmm/bin/msa62mod.pl $names 0 $blastmsadir $modhmm_tmpdir $fastadir;

/bin/echo `date` "Running modhmms";
${modhmmdir}/bin/modhmms -m ${topconsdir}/prodiv_tmhmm/HMM_FILES/PRODIV_TMHMM_0.92b.txt -s $paths_tmp -f msa -r ${topconsdir}/prodiv_tmhmm/util/replacement_letter_multi.rpl -M GM -L -c 1 --max_d > $outfile;

/bin/echo `date` "Converting output to topology-format";
${modhmmdir}/bin/modhmmxml2top < $outfile > $outfile_top;
${topconsdir}/prodiv_tmhmm/bin/fasta_split.py $outfile_top $outdir top;


paths_tmp=${tmpdir}/pro_tmhmm.names.txt;
outfile=${tmpdir}/pro_tmhmm_modhmm.xml;
outfile_top=${tmpdir}/pro_tmhmm_modhmm.top;
modhmm_tmpdir=${tmpdir}/pro_tmhmm_modhmm_tmp;
[[ -d $modhmm_tmpdir ]] || mkdir -pv $modhmm_tmpdir;

cp ${tmpdir}/prodivtmhmm.names.txt $paths_tmp

/bin/echo `date` "Converting BLAST result files to modhmm-format";
${topconsdir}/prodiv_tmhmm/bin/msa62mod.pl $names 0 $blastmsadir $modhmm_tmpdir $fastadir;

/bin/echo `date` "Running modhmms";
${modhmmdir}/bin/modhmms -m ${topconsdir}/prodiv_tmhmm/HMM_FILES/PRO_TMHMM_0.92b.txt -s $paths_tmp -f msa -r ${topconsdir}/prodiv_tmhmm/util/replacement_letter_multi.rpl -M GM -L -c 1 > $outfile;

/bin/echo `date` "Converting output to topology-format";
${modhmmdir}/bin/modhmmxml2top < $outfile > $outfile_top;
${topconsdir}/prodiv_tmhmm/bin/fasta_split.py $outfile_top $outdir top;

