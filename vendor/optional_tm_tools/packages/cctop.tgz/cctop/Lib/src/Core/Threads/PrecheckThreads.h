/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * PrecheckThreads.h
 *
 *  Created on: 2014.08.05.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_THREADS_PRECHECKTHREADS_H_
#define CCTOP_CORE_THREADS_PRECHECKTHREADS_H_

#include "../../Utils/Threading/BaseThread.h"
#include "../../CCTopLib.h"
#include "../SequenceContext.h"

namespace CCTOP { namespace Core { namespace Threads {

class PhobiousThread : public CCTOP::Utils::Threading::BaseThread
{
protected:
	const CCTopLib&			_lib;
	SequenceContext* 	_seqContext;

	virtual void* run()
	{
		if(_seqContext)
			_lib.methodCallPhobious(*_seqContext);

		return NULL;
	}

public:
	PhobiousThread(const CCTopLib& lib) : _lib(lib), _seqContext(NULL) {}
	virtual ~PhobiousThread(){}

	void setSequenceContext(SequenceContext* seqContext) { _seqContext = seqContext; }
};

class ScampiThread : public CCTOP::Utils::Threading::BaseThread
{
protected:
	const CCTopLib&			_lib;
	SequenceContext* 	_seqContext;

	virtual void* run()
	{
		if(_seqContext)
			_lib.methodCallScampi(*_seqContext);

		return NULL;
	}

public:
	ScampiThread(const CCTopLib& lib) : _lib(lib), _seqContext(NULL) {}
	virtual ~ScampiThread(){}

	void setSequenceContext(SequenceContext* seqContext) { _seqContext = seqContext; }
};


class TMHMMThread : public CCTOP::Utils::Threading::BaseThread
{
protected:
	const CCTopLib&			_lib;
	SequenceContext* 	_seqContext;

	virtual void* run()
	{
		if(_seqContext)
			_lib.methodCallTMHMM(*_seqContext);

		return NULL;
	}

public:
	TMHMMThread(const CCTopLib& lib) : _lib(lib), _seqContext(NULL) {}
	virtual ~TMHMMThread(){}

	void setSequenceContext(SequenceContext* seqContext) { _seqContext = seqContext; }
};

//methodCallPhobious(seqContext);
//	methodCallScampi(seqContext);
//	methodCallTMHMM(seqContext);

}}}



#endif /* CCTOP_CORE_COMMANDS_MEMBRAINTHREAD_H_ */
