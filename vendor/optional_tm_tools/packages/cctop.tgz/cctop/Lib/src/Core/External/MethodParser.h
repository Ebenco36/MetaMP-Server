/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MethodParser.h
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_EXTERNAL_METHODPARSER_H_
#define CCTOP_CORE_EXTERNAL_METHODPARSER_H_

#include "../MethodContext.h"
#include "../SequenceContext.h"

#include <string>
#include <vector>

namespace CCTOP { namespace Core { namespace External
{

class MethodParser
{
protected:

public:
	MethodParser();
	MethodParser(const MethodParser& copy);
	~MethodParser();
	MethodParser& operator=(const MethodParser& copy);

	void parseTMHMM(const std::string& result, Core::SequenceContext& context) const;
	void parsePhobious(const std::string& result, Core::SequenceContext& context) const;
	void parsePhilius(const std::string& result, Core::SequenceContext& context) const;
	std::string parseMemBrainInvoke(const std::string& result, Core::SequenceContext& context) const;
	bool parseMemBrain(const std::string& result, Core::SequenceContext& context) const;

	void parseTOPCON(const std::string& result, Core::SequenceContext& context, const std::string& type) const;
	void parseScampiMsa(const std::string& result, Core::SequenceContext& context) const;
	void parsePro(const std::string& result, Core::SequenceContext& context) const;
	void parseProDiv(const std::string& result, Core::SequenceContext& context) const;
	void parseOctopus(const std::string& result, Core::SequenceContext& context) const;
	void parseScampi(const std::string& result, Core::SequenceContext& context) const;

	bool parseMemsatGlob(const std::string& result, Core::SequenceContext& context) const;
	void parseMemsat(const std::string& result, Core::SequenceContext& context) const;

	void parseTopDom(const std::string& result, Core::SequenceContext& context, const std::string& resultURL) const;
	bool parseTopDomSub(const std::string& resultURL, const std::string& topdomId) const;
};

}}}


#endif /* CCTOP_CORE_EXTERNAL_METHODPARSER_H_ */
