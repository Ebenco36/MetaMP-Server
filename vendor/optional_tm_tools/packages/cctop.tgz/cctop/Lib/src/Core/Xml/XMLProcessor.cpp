/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * XMLProcessor.cpp
 *
 *  Created on: 2013.11.26.
 *      Author: "Istvan Remenyi"
 */

#include "XMLProcessor.h"

#include <string.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>

#include "../../Utils/Xml/rapidxml_print.hpp"
#include "../MethodContext.h"
#include "../../CCTopLibDefs.h"

using namespace rapidxml;

//static var definitions
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CCTOPITEM 			= "CCTOPItem";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_COPYRIGHT			= "Copyright";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CROSSREF			= "CrossRef";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_UNIPROT				= "UniProt";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_SIGNALP 			= "SignalP";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_AC					= "AC";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_PARAMETERS			= "Parameters";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_RESULTS				= "Results";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_RESOLUTION			= "Resolution";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_METHOD				= "Method";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CHAINS				= "Chains";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CHAIN				= "Chain";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_FRAGMENT			= "Fragment";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_SIDEDEFINITION		= "SideDefinition";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_PDBTM				= "PDBTM";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_MODELTM				= "ModelTM";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_TOPDB				= "TOPDB";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_TOPDOM				= "TOPDOM";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_SEQUENCE			= "Sequence";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_NAME				= "Name";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_TRANSIT				= "Transit";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_SIGNAL				= "Signal";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_PROPEPTIDE			= "Propeptide";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_NOTE				= "Note";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_SEQ					= "Seq";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_TOPOLOGY			= "Topology";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_RELIABILITY			= "Reliability";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_REGION				= "Region";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CONSTRAINTREGION	= "ConstraintRegion";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_PREDICTIONS			= "Predictions";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_PREDICTION			= "Prediction";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CONSTRAINTS			= "Constraints";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CONSTRAINT			= "Constraint";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_ALIGNMENT			= "Alignment";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_CROSSREFSEQ			= "CrossRefSeq";
const char* CCTOP::Core::XML::XMLProcessor::XML_ELEMENT_HTPSEQ				= "OrigSeq";

const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_AC				= "ac";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_TYPE				= "type";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_TRANSMEMBRANE		= "transmembrane";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_ID				= "id";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_RELIABILITY		= "reliability";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_CHECKSUM			= "checkSum";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_LENGTH			= "length";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_TMSEQCOUNT		= "tmSeqCount";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_NUMTM				= "numTM";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_LOC				= "loc";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_NAME				= "name";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_SOURCE			= "source";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_SOURCEID			= "sourceId";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_SUBID				= "subId";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_SUBSOURCE			= "subSource";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_FROM				= "from";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_TO				= "to";
const char* CCTOP::Core::XML::XMLProcessor::XML_ATTRIBUTE_EVIDENCE			= "evidence";

const char* CCTOP::Core::XML::XMLProcessor::VALUE_CONSTRAINTTYPE_SIGNAL		= "SIGNAL";

const char* CCTOP::Core::XML::XMLProcessor::VALUE_SIGNALMODE_UNDEFINED		= "Undefined";
const char* CCTOP::Core::XML::XMLProcessor::VALUE_SIGNALMODE_TOPDB			= "TopDB";
const char* CCTOP::Core::XML::XMLProcessor::VALUE_SIGNALMODE_UNIPROT		= "Uniprot";
const char* CCTOP::Core::XML::XMLProcessor::VALUE_SIGNALMODE_SIGNALP		= "SignalP";


//const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_METHODTYPE_OBSERVED	= "Observed";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_METHODTYPE_HTP			= "HTP";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_METHODTYPE_SIGNAL		= "SIGNAL";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_METHODTYPE_ENUM_RESERVED = "ENUM_RESERVED";

const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_PDBTM		= "PDBTM";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_PDB		= "PDB";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_TOPDOM	= "TOPDOM";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_TOPDB		= "TOPDB";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_UNIPROT	= "UniProt";
const char*	CCTOP::Core::XML::XMLProcessor::DB_VALUE_CROSSREFTYPE_SIGNAL	= "Signal";


const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_MEMBRANE	= "Membrane";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_TRANSIT		= "Transit";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_SIGNAL		= "Signal";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_PROPEPTIDE	= "Propeptide";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_UNKNOWN		= "Unknown";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_INSIDE		= "Inside";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_OUTSIDE		= "Outside";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_RE_ENTRANT	= "Re-entrant loop";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_REGIONTYPE_MEMREENTRANT= "Membrane re-entrant loop";

const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_STRLEVEL_3D 			= "3D";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_STRLEVEL_EXPERIMENT	= "Experiment";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_STRLEVEL_EXISTS		= "Exists";
const char* CCTOP::Core::XML::XMLProcessor::DB_VALUE_STRLEVEL_PREDICTION	= "Prediction";


//class definitions;
CCTOP::Core::XML::XMLProcessor::XMLProcessor(const CCTopLib& lib)
: _lib(lib)
{}

CCTOP::Core::XML::XMLProcessor::XMLProcessor(const XMLProcessor& copy)
: _lib(copy._lib)
{}


CCTOP::Core::XML::XMLProcessor& CCTOP::Core::XML::XMLProcessor::operator=(const XMLProcessor& copy)
{
	return *this;
}

CCTOP::Core::XML::XMLProcessor::~XMLProcessor()
{
	std::vector<char*>::iterator iter = _stringCache.begin();
	while(iter != _stringCache.end())
	{
		delete [] *iter;
		iter++;
	}
}

bool CCTOP::Core::XML::XMLProcessor::writableLocalization(Core::Localization loc) const
{
	return loc == LOCALIZATION_SIGNAL
			|| loc == LOCALIZATION_INSIDE
			|| loc == LOCALIZATION_MEMBRANE
			|| loc == LOCALIZATION_OUTSIDE
			|| loc == LOCALIZATION_MEMBLOOP;
}

void CCTOP::Core::XML::XMLProcessor::writeCopyright(const std::string& copyright, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	xml_node<>* decl = doc.allocate_node(node_element, XML_ELEMENT_COPYRIGHT);
	decl->value(copyright.c_str());
	node->append_node(decl);
}

void CCTOP::Core::XML::XMLProcessor::writeName(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	xml_node<>* decl = doc.allocate_node(node_element, XML_ELEMENT_NAME);
	decl->value(seqContext.getName().c_str());
	node->append_node(decl);
}

void CCTOP::Core::XML::XMLProcessor::writeSequence(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	xml_node<>* sequenceNode = doc.allocate_node(node_element, XML_ELEMENT_SEQUENCE);

	std::stringstream strL;
	strL << seqContext.getSequence().length();
	_stringCache.push_back( copyString( strL.str()));
	const char* strLen = _stringCache[_stringCache.size()-1];
	sequenceNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LENGTH, strLen));
	sequenceNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_CHECKSUM, seqContext.getSequenceChecksum().c_str()));


	std::vector<CCTOP::Core::Region>::iterator trIter = seqContext.getRemovedTransitRegions().begin();
	while(trIter != seqContext.getRemovedTransitRegions().end())
	{
		std::stringstream strSStart;
		strSStart << (*trIter).begin;
		_stringCache.push_back( copyString(strSStart.str()));

		std::stringstream strSStop;
		strSStop << (*trIter).end;
		_stringCache.push_back( copyString(strSStop.str()));

		const char* strStart = _stringCache[_stringCache.size()-2];
		const char* strStop = _stringCache[_stringCache.size()-1];

		xml_node<>* sigNode = doc.allocate_node(node_element, XML_ELEMENT_TRANSIT);
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

		sequenceNode->append_node(sigNode);

		trIter++;
	}

	std::vector<TopologyEntry>& cctopology = seqContext.getCCTOPTopology();
	std::vector<TopologyEntry>::iterator cctopIter = cctopology.begin();
	while(cctopIter != cctopology.end())
	{
		if(cctopIter->loc == QUASI_LOCALICATION_TRANSIT)
		{
			std::stringstream strSStart;
			if((*cctopIter).beg > -1)
				strSStart << (*cctopIter).beg;
			else
				strSStart << "?";
			_stringCache.push_back( copyString(strSStart.str()));

			std::stringstream strSStop;
			if((*cctopIter).end > -1)
				strSStop << (*cctopIter).end;
			else
				strSStop << "?";
			_stringCache.push_back( copyString(strSStop.str()));

			const char* strStart = _stringCache[_stringCache.size()-2];
			const char* strStop = _stringCache[_stringCache.size()-1];

			xml_node<>* sigNode = doc.allocate_node(node_element, XML_ELEMENT_TRANSIT);
			sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
			sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

			sequenceNode->append_node(sigNode);
		}
		cctopIter++;
	}

	trIter = seqContext.getRemovedSignalRegions().begin();
	while(trIter != seqContext.getRemovedSignalRegions().end())
	{
		std::stringstream strSStart;
		strSStart << (*trIter).begin;
		_stringCache.push_back( copyString(strSStart.str()));

		std::stringstream strSStop;
		strSStop << (*trIter).end;
		_stringCache.push_back( copyString(strSStop.str()));

		const char* strStart = _stringCache[_stringCache.size()-2];
		const char* strStop = _stringCache[_stringCache.size()-1];

		xml_node<>* sigNode = doc.allocate_node(node_element, XML_ELEMENT_SIGNAL);
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

		sequenceNode->append_node(sigNode);

		trIter++;
	}

	trIter = seqContext.getPropeptideRegions().begin();
	while(trIter != seqContext.getPropeptideRegions().end())
	{
		std::stringstream strSStart;
		strSStart << (*trIter).begin;
		_stringCache.push_back( copyString(strSStart.str()));

		std::stringstream strSStop;
		strSStop << (*trIter).end;
		_stringCache.push_back( copyString(strSStop.str()));

		const char* strStart = _stringCache[_stringCache.size()-2];
		const char* strStop = _stringCache[_stringCache.size()-1];

		xml_node<>* sigNode = doc.allocate_node(node_element, DB_VALUE_REGIONTYPE_PROPEPTIDE);
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

		sequenceNode->append_node(sigNode);

		trIter++;
	}

	if(!seqContext.getNote().empty())
	{
		xml_node<>* noteNode = doc.allocate_node(node_element, XML_ELEMENT_NOTE);
		noteNode->value(seqContext.getNote().c_str());
		sequenceNode->append_node(noteNode);
	}

	xml_node<>* seqNode = doc.allocate_node(node_element, XML_ELEMENT_SEQ);
	const std::string& seq = seqContext.getSequence();
	std::stringstream str;
	int blockSize = 50;
	for(unsigned int i = 0; i < seq.length(); i++)
	{
		str << seq[i];
		if(i && i%blockSize == 49)
			str << "\n";
	}
	_stringCache.push_back( copyString( str.str()));
	seqNode->value(_stringCache[_stringCache.size()-1]);
	sequenceNode->append_node(seqNode);

	node->append_node(sequenceNode);
}

void CCTOP::Core::XML::XMLProcessor::writeCrossRef(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	std::string evidence;

	if(!seqContext.getUniprotBlastAc().empty()
			|| seqContext.getTopDBHits().size()
			|| seqContext.getTOPDOMHits().size()
			|| seqContext.getRemovedSignalRegions().size())
	{
		xml_node<>* decl = doc.allocate_node(node_element, XML_ELEMENT_CROSSREF);
		node->append_node(decl);

		if(!seqContext.getUniprotBlastAc().empty())
		{
			xml_node<>* crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_UNIPROT);
			crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, seqContext.getUniprotId().c_str()));

			xml_node<>* ac = doc.allocate_node(node_element, XML_ELEMENT_AC);
			ac->value(seqContext.getUniprotBlastAc().c_str());
			crNode->append_node(ac);

			std::vector< std::string >::const_iterator uniIter = seqContext.getUniprotACs().begin();
			while(uniIter != seqContext.getUniprotACs().end())
			{
				xml_node<>* ac = doc.allocate_node(node_element, XML_ELEMENT_AC);
				ac->value((*uniIter).c_str());
				crNode->append_node(ac);

				uniIter++;
			}

			decl->append_node(crNode);
		}

		if(seqContext.getTopDBHits().size())
		{
			bool isEvidence3D = false;
			std::map<std::string, std::vector<std::string> > pdbs;
			std::map<std::string, std::vector<std::string> >::iterator pdbsIter;
			std::vector<std::string> pdbtm;

			bool hasExperiment = false;

			std::vector<CCTOP::Core::TopDBHit>::const_iterator hitIterator = seqContext.getTopDBHits().begin();
			while(hitIterator != seqContext.getTopDBHits().end())
			{
				if(!hasExperiment) hasExperiment =  (*hitIterator).experiments.size();

				std::vector<CCTOP::Core::ExperimentEntry>::const_iterator expIter = (*hitIterator).experiments.begin();
				while(expIter != (*hitIterator).experiments.end())
				{
					//no need since experiments is processed if(expIter->evidenceLevel == CCTOP::Core::EVIDENCELEVEL_EXPERIMENT)
					if(!expIter->pdbId.empty())
					{
						if(!isEvidence3D)
							isEvidence3D =  expIter->loc == LOCALIZATION_MEMBRANE;

						std::vector<std::string>::const_iterator chainIter = expIter->chainIds.begin();
						while(chainIter != expIter->chainIds.end())
						{
							std::string chainId = *chainIter;

							if((pdbsIter = pdbs.find(expIter->pdbId)) != pdbs.end())
							{
								std::vector<std::string>::iterator chIter = pdbsIter->second.begin();
								while(chIter != pdbsIter->second.end()
										&& (*chIter).compare(chainId))
								{
									chIter++;
								}

								if(chIter == pdbsIter->second.end())
								{
									pdbsIter->second.push_back(chainId);
								}
							}else
							{
								std::vector<std::string> temp;
								temp.push_back(chainId);
								pdbs[expIter->pdbId] = temp;
							}
							chainIter++;
						}

						if(expIter->loc == LOCALIZATION_MEMBRANE)
						{
							std::vector<std::string>::const_iterator pdbtmIter = pdbtm.begin();
							while(pdbtmIter != pdbtm.end()
									&& (*pdbtmIter).compare(expIter->pdbId))
							{
								pdbtmIter++;
							}

							if(pdbtmIter == pdbtm.end())
								pdbtm.push_back(expIter->pdbId);
						}
					}
					expIter++;
				}

				hitIterator++;
			}

			pdbsIter = pdbs.begin();
			while(pdbsIter != pdbs.end())
			{
				std::vector<std::string>::const_iterator pdbtmIter = pdbtm.begin();
				while(pdbtmIter != pdbtm.end()
						&& (*pdbtmIter).compare(pdbsIter->first))
				{
					pdbtmIter++;
				}
				xml_node<>* crNode = NULL;
				if(pdbtmIter != pdbtm.end())
					crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_PDBTM);
				else
					crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_PDB);

				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, (pdbsIter->first).c_str()));

				std::vector<std::string>::iterator chIter = pdbsIter->second.begin();
				while(chIter != pdbsIter->second.end())
				{
					xml_node<>* chainNode = doc.allocate_node(node_element, XML_ELEMENT_CHAIN);
					chainNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, (*chIter).c_str()));
					crNode->append_node(chainNode);

					chIter++;
				}

				decl->append_node(crNode);

				pdbsIter++;
			}

			hitIterator = seqContext.getTopDBHits().begin();
			while(hitIterator != seqContext.getTopDBHits().end())
			{
				xml_node<>* crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_TOPDB);
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, (*hitIterator).topDBId.c_str()));

				xml_node<>* paNode = doc.allocate_node(node_element, XML_ELEMENT_ALIGNMENT);
				crNode->append_node(paNode);

				xml_node<>* typedSeqNode = NULL;
				typedSeqNode = doc.allocate_node(node_element, XML_ELEMENT_CROSSREFSEQ);
				typedSeqNode->value((*hitIterator).crossRefSeq.c_str());
				paNode->append_node(typedSeqNode);

				xml_node<>* htpNode = doc.allocate_node(node_element, XML_ELEMENT_HTPSEQ);
				htpNode->value((*hitIterator).cctopSeq.c_str());
				paNode->append_node(htpNode);

				decl->append_node(crNode);

				hitIterator++;
			}

			if(isEvidence3D)
			{
				evidence = DB_VALUE_STRLEVEL_3D;
			}else
				if(hasExperiment)
					evidence = DB_VALUE_STRLEVEL_EXPERIMENT;
		}

		if(seqContext.getTOPDOMHits().size())
		{
			std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator hitIterator = seqContext.getTOPDOMHits().begin();
			while(hitIterator != seqContext.getTOPDOMHits().end())
			{
				xml_node<>* crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_TOPDOM);
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, hitIterator->first.c_str()));
				decl->append_node(crNode);

				hitIterator++;
			}
		}

		if(seqContext.getRemovedSignalRegions().size())
		{
			xml_node<>* crNode = doc.allocate_node(node_element, DB_VALUE_CROSSREFTYPE_SIGNAL);
			decl->append_node(crNode);

			switch(seqContext.getSignalMode())
			{
			case CCTOP::Core::SIGNALMODE_SIGNALP:
			{
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, VALUE_SIGNALMODE_SIGNALP));

				xml_node<>* resNode = doc.allocate_node(node_element, XML_ELEMENT_RESULTS);
				Region reg = seqContext.getSignalRegionMap()[Core::SIGNALMODE_SIGNALP];
				std::stringstream strSStop;
				strSStop << reg.begin;
				strSStop << '-';
				strSStop << reg.end;
				_stringCache.push_back( copyString(strSStop.str()));

				const char* strStart = _stringCache[_stringCache.size()-1];
				resNode->value(strStart);
				crNode->append_node(resNode);

				xml_node<>* paramNode = doc.allocate_node(node_element, XML_ELEMENT_PARAMETERS);
				std::stringstream strSS;
				strSS << seqContext.getSignalPDScore();
				_stringCache.push_back( copyString(strSS.str()));

				const char* strSs = _stringCache[_stringCache.size()-1];
				paramNode->value(strSs);
				crNode->append_node(paramNode);

				break;
			}
			case CCTOP::Core::SIGNALMODE_TOPDB:
			{
				std::string tmp;
				tmp = VALUE_SIGNALMODE_TOPDB;
				if(seqContext.getTopDBHits().size())
				{
					tmp += "-";
					tmp += seqContext.getTopDBHits().begin()->topDBId;
				}
				_stringCache.push_back( copyString( tmp ));
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, _stringCache[_stringCache.size()-1]));

				xml_node<>* resNode = doc.allocate_node(node_element, XML_ELEMENT_RESULTS);
				Region reg = seqContext.getSignalRegionMap()[Core::SIGNALMODE_TOPDB];
				std::stringstream strSStop;
				strSStop << reg.begin;
				strSStop << '-';
				strSStop << reg.end;
				_stringCache.push_back( copyString(strSStop.str()));

				const char* strStart = _stringCache[_stringCache.size()-1];
				resNode->value(strStart);
				crNode->append_node(resNode);

				break;
			}
			case CCTOP::Core::SIGNALMODE_UNIPROT:
			{
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, VALUE_SIGNALMODE_UNIPROT));
				xml_node<>* resNode = doc.allocate_node(node_element, XML_ELEMENT_RESULTS);
				Region reg = seqContext.getSignalRegionMap()[Core::SIGNALMODE_UNIPROT];
				std::stringstream strSStop;
				strSStop << reg.begin;
				strSStop << '-';
				strSStop << reg.end;
				_stringCache.push_back( copyString(strSStop.str()));

				const char* strStart = _stringCache[_stringCache.size()-1];
				resNode->value(strStart);
				crNode->append_node(resNode);

				break;
			}
			case CCTOP::Core::SIGNALMODE_UNIPROT_EN:
			{
				if(seqContext.getSignalRegionMap().find(SIGNALMODE_TOPDB) != seqContext.getSignalRegionMap().end())
				{
					std::string tmp = VALUE_SIGNALMODE_TOPDB;
					if(seqContext.getTopDBHits().size())
					{
						tmp += "-";
						tmp += seqContext.getTopDBHits().begin()->topDBId;
					}
					_stringCache.push_back( copyString( tmp ));
					crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, _stringCache[_stringCache.size()-1]));
					xml_node<>* resNode = doc.allocate_node(node_element, XML_ELEMENT_RESULTS);
					Region reg = seqContext.getSignalRegionMap()[Core::SIGNALMODE_TOPDB];
					std::stringstream strSStop;
					strSStop << reg.begin;
					strSStop << '-';
					strSStop << reg.end;
					_stringCache.push_back( copyString(strSStop.str()));

					const char* strStart = _stringCache[_stringCache.size()-1];
					resNode->value(strStart);
					crNode->append_node(resNode);
				}

				if(seqContext.getSignalRegionMap().find(SIGNALMODE_SIGNALP) != seqContext.getSignalRegionMap().end())
				{
					crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, VALUE_SIGNALMODE_SIGNALP));
					xml_node<>* resNode = doc.allocate_node(node_element, XML_ELEMENT_RESULTS);
					Region reg = seqContext.getSignalRegionMap()[Core::SIGNALMODE_SIGNALP];
					std::stringstream strSStop;
					strSStop << reg.begin;
					strSStop << '-';
					strSStop << reg.end;
					_stringCache.push_back( copyString(strSStop.str()));

					const char* strStart = _stringCache[_stringCache.size()-1];
					resNode->value(strStart);
					crNode->append_node(resNode);

					xml_node<>* paramNode = doc.allocate_node(node_element, XML_ELEMENT_PARAMETERS);
					std::stringstream strSS;
					strSS << seqContext.getSignalPDScore();
					_stringCache.push_back( copyString(strSS.str()));

					const char* strSs = _stringCache[_stringCache.size()-1];
					paramNode->value(strSs);
					crNode->append_node(paramNode);
				}
				break;
			}
			case CCTOP::Core::SIGNALMODE_UNDEFINED:
			default:
				crNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, VALUE_SIGNALMODE_UNDEFINED));
				break;
			}
		}
	}

	if(evidence.empty())
	{
		/*if(seqContext.hasUniprotEvidence())
			evidence = DB_VALUE_STRLEVEL_EXISTS;
		else*/
		evidence = DB_VALUE_STRLEVEL_PREDICTION;
	}

	_stringCache.push_back( copyString(evidence));
	const char* srtEvi = _stringCache[_stringCache.size()-1];
	node->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_EVIDENCE, srtEvi));
}

void CCTOP::Core::XML::XMLProcessor::writeTopologies(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	xml_node<>* topologyNode = doc.allocate_node(node_element, XML_ELEMENT_TOPOLOGY);
	node->append_node(topologyNode);


	std::vector<CCTOP::Core::Region>::iterator trIter = seqContext.getRemovedTransitRegions().begin();
	while(trIter != seqContext.getRemovedTransitRegions().end())
	{
		std::stringstream strSStart;
		strSStart << (*trIter).begin;
		_stringCache.push_back( copyString(strSStart.str()));

		std::stringstream strSStop;
		strSStop << (*trIter).end;
		_stringCache.push_back( copyString(strSStop.str()));

		const char* strStart = _stringCache[_stringCache.size()-2];
		const char* strStop = _stringCache[_stringCache.size()-1];

		xml_node<>* sigNode = doc.allocate_node(node_element, XML_ELEMENT_REGION);
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

		std::string regType;
		regType += Core::localizationToChar(LOCALIZATION_TRANSIT);
		_stringCache.push_back( copyString(regType));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));

		topologyNode->append_node(sigNode);

		trIter++;
	}

	trIter = seqContext.getRemovedSignalRegions().begin();
	while(trIter != seqContext.getRemovedSignalRegions().end())
	{
		std::stringstream strSStart;
		strSStart << (*trIter).begin;
		_stringCache.push_back( copyString(strSStart.str()));

		std::stringstream strSStop;
		strSStop << (*trIter).end;
		_stringCache.push_back( copyString(strSStop.str()));

		const char* strStart = _stringCache[_stringCache.size()-2];
		const char* strStop = _stringCache[_stringCache.size()-1];

		xml_node<>* sigNode = doc.allocate_node(node_element, XML_ELEMENT_REGION);
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

		std::string regType;
		regType += Core::localizationToChar(LOCALIZATION_SIGNAL);
		_stringCache.push_back( copyString(regType));
		sigNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));

		topologyNode->append_node(sigNode);

		trIter++;
	}

	int tmCount = 0;
	std::vector<TopologyEntry>& cctopology = seqContext.getCCTOPTopology();
	std::vector<TopologyEntry>::iterator cctopIter = cctopology.begin();
	while(cctopIter != cctopology.end())
	{
		if(cctopIter->loc < QUASI_LOCALICATION_TRANSIT)
		{
			std::stringstream strSStart;
			strSStart << (*cctopIter).beg;
			_stringCache.push_back( copyString(strSStart.str()));

			std::stringstream strSStop;
			strSStop << (*cctopIter).end;
			_stringCache.push_back( copyString(strSStop.str()));

			const char* strStart = _stringCache[_stringCache.size()-2];
			const char* strStop = _stringCache[_stringCache.size()-1];

			xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_REGION);
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

			std::string regType;
			regType += Core::localizationToChar((*cctopIter).loc);
			_stringCache.push_back( copyString(regType));
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));

			topologyNode->append_node(regNode);

			if((*cctopIter).loc == LOCALIZATION_MEMBRANE)
				tmCount++;
		}
		cctopIter++;
	}

	std::stringstream strT;
	strT << tmCount;
	_stringCache.push_back( copyString(strT.str()));

	std::stringstream strR;
	strR << (seqContext.getReliability()*100);
	_stringCache.push_back( copyString(strR.str()));

	const char* t = _stringCache[_stringCache.size()-2];
	const char* r = _stringCache[_stringCache.size()-1];

	topologyNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_NUMTM, t));
	topologyNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_RELIABILITY, r));

}

void CCTOP::Core::XML::XMLProcessor::writePredictions(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	xml_node<>* predictionsNode = doc.allocate_node(node_element, XML_ELEMENT_PREDICTIONS);
	node->append_node(predictionsNode);

	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& methods = seqContext.getMethodHits();
	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator methodIter = methods.begin();
	while(methodIter != methods.end())
	{
		bool hasMemRegion = false;
		std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = methodIter->second.begin();
		while( topoIter != methodIter->second.end() && !hasMemRegion)
		{
			hasMemRegion = topoIter->loc == LOCALIZATION_MEMBRANE;
			topoIter++;
		}

		if(hasMemRegion)
		{
			xml_node<>* predNode = doc.allocate_node(node_element, XML_ELEMENT_PREDICTION);
			predictionsNode->append_node(predNode);

			predNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_NAME, methodIter->first.c_str()));

			topoIter = methodIter->second.begin();
			while( topoIter != methodIter->second.end() )
			{
				//"S","I","M","O","L"
				if(writableLocalization(topoIter->loc))
				{
					std::stringstream strSStart;
					strSStart << (*topoIter).beg;
					_stringCache.push_back( copyString(strSStart.str()));

					std::stringstream strSStop;
					strSStop << (*topoIter).end;
					_stringCache.push_back( copyString(strSStop.str()));

					const char* strStart = _stringCache[_stringCache.size()-2];
					const char* strStop = _stringCache[_stringCache.size()-1];

					xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_REGION);
					regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
					regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));

					std::string regType;
					regType += Core::localizationToChar((*topoIter).loc);
					_stringCache.push_back( copyString(regType));
					regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));

					predNode->append_node(regNode);
				}

				topoIter++;
			}
		}

		methodIter++;
	}
}

void CCTOP::Core::XML::XMLProcessor::writeConstraints(SequenceContext& seqContext, const MethodContext& methodContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const
{
	std::vector<CCTOP::Core::TopDBHit>& topDBHits = seqContext.getTopDBHits();

	if(topDBHits.size() || seqContext.isNTerminalOutSide() || seqContext.getTOPDOMHits().size())
	{
		xml_node<>* constraintsNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINTS);
		node->append_node(constraintsNode);

		if(seqContext.isNTerminalOutSide())
		{
			xml_node<>* constrNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINT);
			constraintsNode->append_node(constrNode);

			constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCE, VALUE_CONSTRAINTTYPE_SIGNAL));

			if(seqContext.getRemovedSignalRegions().size())
			{
				switch(seqContext.getSignalMode())
				{
				case CCTOP::Core::SIGNALMODE_SIGNALP:
					constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, VALUE_SIGNALMODE_SIGNALP));
					break;
				case CCTOP::Core::SIGNALMODE_TOPDB:
				{
					std::string tmp;
					tmp = VALUE_SIGNALMODE_TOPDB;
					if(seqContext.getTopDBHits().size())
					{
						tmp += "-";
						tmp += seqContext.getTopDBHits().begin()->topDBId;
					}
					_stringCache.push_back( copyString( tmp ));
					constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, _stringCache[_stringCache.size()-1]));

					break;
				}
				case CCTOP::Core::SIGNALMODE_UNIPROT:
					constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, VALUE_SIGNALMODE_UNIPROT));
					break;
				case CCTOP::Core::SIGNALMODE_UNIPROT_EN:
				{
					if(seqContext.getSignalPPos() < 1)
					{
						std::string tmp = VALUE_SIGNALMODE_TOPDB;
						if(seqContext.getTopDBHits().size())
						{
							tmp += "-";
							tmp += seqContext.getTopDBHits().begin()->topDBId;
						}
						_stringCache.push_back( copyString( tmp ));
						constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, _stringCache[_stringCache.size()-1]));
					}else
						constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, VALUE_SIGNALMODE_SIGNALP));
					break;
				}
				case CCTOP::Core::SIGNALMODE_UNDEFINED:
				default:
					constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, VALUE_SIGNALMODE_UNDEFINED));
					break;
				}
			}

			std::stringstream strSStart;
			strSStart << seqContext.getNTerminalIndex();
			_stringCache.push_back( copyString(strSStart.str()));

			const char* strStart = _stringCache[_stringCache.size()-1];

			xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINTREGION);
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStart));

			std::string regType;
			regType +=  Core::localizationToChar(LOCALIZATION_OUTSIDE);
			_stringCache.push_back( copyString(regType));
			regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));

			constrNode->append_node(regNode);

		}

		std::vector<CCTOP::Core::TopDBHit>::const_iterator hitIterator = topDBHits.begin();
		while(hitIterator != topDBHits.end())
		{
			int counter = 0;
			std::vector<CCTOP::Core::ExperimentEntry>::const_iterator expIter = hitIterator->experiments.begin();
			while(expIter != hitIterator->experiments.end())
			{
				if((*expIter).beg <= (*expIter).end && (*expIter).beg > 0
						&& writableLocalization(expIter->loc))
				{
					counter++;
				}
				expIter++;
			}

			if(counter)
			{
				xml_node<>* constrNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINT);
				constraintsNode->append_node(constrNode);
				constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCE, DB_VALUE_CROSSREFTYPE_TOPDB));
				constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, hitIterator->topDBId.c_str()));

				std::vector<CCTOP::Core::ExperimentEntry>::const_iterator expIter = hitIterator->experiments.begin();
				while(expIter != hitIterator->experiments.end())
				{
					if((*expIter).beg <= (*expIter).end && (*expIter).beg > 0
							&& writableLocalization(expIter->loc))
					{
						std::stringstream strSStart;
						strSStart << (*expIter).beg;
						_stringCache.push_back( copyString(strSStart.str()));

						std::stringstream strSStop;
						strSStop << (*expIter).end;
						_stringCache.push_back( copyString(strSStop.str()));

						const char* strStart = _stringCache[_stringCache.size()-2];
						const char* strStop = _stringCache[_stringCache.size()-1];

						std::string regType;
						regType +=  Core::localizationToChar((*expIter).loc);
						_stringCache.push_back( copyString(regType));
						const char* strLoc = _stringCache[_stringCache.size()-1];


						if(expIter->chainIds.size())
						{
							std::vector<std::string>::const_iterator chainIter = expIter->chainIds.begin();
							while(chainIter != expIter->chainIds.end())
							{
								std::string chainId = *chainIter;

								std::string strSums = expIter->pdbId + chainId;
								_stringCache.push_back( copyString(strSums));
								const char* strSum = _stringCache[_stringCache.size()-1];

								xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINTREGION);
								regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
								regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));
								regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, strLoc));
								if(!expIter->id.empty())
									regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SUBID, expIter->id.c_str()));
								if(!chainId.empty())
									regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SUBSOURCE, strSum));
								constrNode->append_node(regNode);

								chainIter++;
							}
						}else
						{
							xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINTREGION);
							regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
							regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));
							regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, strLoc));
							if(!expIter->id.empty())
								regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SUBID, expIter->id.c_str()));
							if(!expIter->ref.empty())
								regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SUBSOURCE, expIter->ref.c_str()));
							constrNode->append_node(regNode);
						}
					}
					expIter++;
				}
			}

			hitIterator++;
		}

		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& topdoms = seqContext.getTOPDOMHits();
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator topdomIter = topdoms.begin();
		while(topdomIter != topdoms.end())
		{
			xml_node<>* constrNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINT);
			constraintsNode->append_node(constrNode);

			constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCE, DB_VALUE_CROSSREFTYPE_TOPDOM));
			constrNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_SOURCEID, topdomIter->first.c_str()));

			std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = topdomIter->second.begin();
			while( topoIter != topdomIter->second.end() )
			{
				std::stringstream strSStart;
				strSStart << (*topoIter).beg;
				_stringCache.push_back( copyString(strSStart.str()));

				std::stringstream strSStop;
				strSStop << (*topoIter).end;
				_stringCache.push_back( copyString(strSStop.str()));

				const char* strStart = _stringCache[_stringCache.size()-2];
				const char* strStop = _stringCache[_stringCache.size()-1];

				xml_node<>* regNode = doc.allocate_node(node_element, XML_ELEMENT_CONSTRAINTREGION);
				regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_FROM, strStart));
				regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TO, strStop));
				std::string regType;
				regType +=  Core::localizationToChar((*topoIter).loc);
				_stringCache.push_back( copyString(regType));
				regNode->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_LOC, _stringCache[_stringCache.size()-1]));


				constrNode->append_node(regNode);

				topoIter++;
			}

			topdomIter++;
		}
	}
}


const char *getAttribute( xml_node<> *node,
		const char *attr_name,
		const char *defval,
		bool mandatory )
{
	xml_attribute<> *attr = node->first_attribute( attr_name );
	if ( !attr ) {
		if ( mandatory )
		{
			std::cerr << "Mandatory attribute (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
		return defval;
	}
	return attr->value();
}

int getAttributeAsInt( xml_node<> *node,
		const char *attr_name,
		int defval,
		bool mandatory )
{

	xml_attribute<> *attr = node->first_attribute( attr_name );
	if ( !attr ) {
		if ( mandatory )
		{
			std::cerr << "Mandatory attribute (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
		return defval;
	}
	return atoi( attr->value() );
}

double getAttributeAsDouble( xml_node<> *node,
		const char *attr_name,
		double defval,
		bool mandatory )
{

	xml_attribute<> *attr = node->first_attribute( attr_name );
	if ( !attr ) {
		if ( mandatory )
		{
			std::cerr << "Mandatory attribute (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
		return defval;
	}
	return atof( attr->value() );
}

bool getAttributeAsBool( xml_node<> *node,
		const char *attr_name,
		bool defval,
		bool mandatory )
{

	xml_attribute<> *attr = node->first_attribute( attr_name );
	if ( !attr ) {
		if ( mandatory )
		{
			std::cerr << "Mandatory attribute (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
		return defval;
	}

	if ( !strcmp( attr->value(), "yes" ) )
		return true;
	if ( !strcmp( attr->value(), "true" ) )
		return true;
	if ( !strcmp( attr->value(), "1" ) )
		return true;
	if ( !strcmp( attr->value(), "no" ) )
		return false;
	if ( !strcmp( attr->value(), "false" ) )
		return false;
	if ( !strcmp( attr->value(), "0" ) )
		return false;
	throw std::string("Invalid boolean");
	return false;
}

void getAttributeAsIntList( xml_node<> *node,
		const char *attr_name,
		std::vector<int>& values,
		int defval,
		bool mandatory)
{
	xml_attribute<> *attr = node->first_attribute( attr_name );
	if ( !attr )
	{
		if ( mandatory )
		{
			std::cerr << "Mandatory attribute (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
		values.push_back( defval );
	}else
	{
		try
		{
			char * pch;
			pch = strtok (attr->value(), " ,.-");
			while (pch != NULL)
			{
				values.push_back( atoi(pch) );
				pch = strtok (NULL, " ,.-");
			}
		}catch(...)
		{
			std::cerr << "Parsing an Integer list failed (" << node->name() << "::" << attr_name << ") is missing!" << std::endl;
			throw std::string("Error");
		}
	}
}

void CCTOP::Core::XML::XMLProcessor::parseSequence(SequenceContext& seqContext, rapidxml::xml_node<>* node) const
{
//	xml_node<>* topNode = node->first_node(XML_ELEMENT_SEQUENCE);
//	if(topNode)
//	{
//		for(xml_node<>* siblingNode = topNode->first_node() ; siblingNode ;siblingNode = siblingNode->next_sibling())
//		{
//			if(!strcmp(siblingNode->name(), XML_ELEMENT_TRANSIT))
//			{
//				int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
//				int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
//
//				seqContext.addTransitRegion(start, stop);
//			}
//
//			if(!strcmp(siblingNode->name(), XML_ELEMENT_SIGNAL))
//			{
//				int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
//				int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
//
//				seqContext.addSignalRegion(start, stop);
//			}
//
//			if(!strcmp(siblingNode->name(), XML_ELEMENT_PROPEPTIDE))
//			{
//				int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
//				int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
//
//				seqContext.addPropeptideRegion(start, stop);
//			}
//		}
//	}

	xml_node<>* nameNode = node->first_node(XML_ELEMENT_NAME);
	if(nameNode)
	{
		seqContext.setName(std::string(nameNode->value()));
	}
}

void CCTOP::Core::XML::XMLProcessor::parseCrossRefs(SequenceContext& seqContext, rapidxml::xml_node<>* node) const
{
	xml_node<>* topNode = node->first_node(XML_ELEMENT_CROSSREF);
	if(topNode)
	{
		for(xml_node<>* crNode = topNode->first_node() ; crNode ;crNode = crNode->next_sibling())
		{
			const char* outherId = getAttribute(crNode, XML_ATTRIBUTE_ID, NULL, true);

			if(!strcmp(crNode->name(), XML_ELEMENT_TOPDB) /*|| !strcmp(crNode->name(), XML_ELEMENT_TOPDOM)
					|| !strcmp(crNode->name(), XML_ELEMENT_PDBTM) || !strcmp(crNode->name(), XML_ELEMENT_MODELTM)*/)
			{
				for(xml_node<>* topdbSiblingNode = crNode->first_node() ; topdbSiblingNode ;topdbSiblingNode = topdbSiblingNode->next_sibling())
				{
					if(!strcmp(topdbSiblingNode->name(), XML_ELEMENT_ALIGNMENT))
					{
						std::string htpSeq;
						std::string refSeq;
						for(xml_node<>* alignmentSiblingNode = topdbSiblingNode->first_node() ; alignmentSiblingNode ;alignmentSiblingNode = alignmentSiblingNode->next_sibling())
						{
							if(!strcmp(alignmentSiblingNode->name(), XML_ELEMENT_HTPSEQ))
							{
								htpSeq = alignmentSiblingNode->value();
							}else
								if(!strcmp(alignmentSiblingNode->name(), XML_ELEMENT_CROSSREFSEQ))
								{
									refSeq = alignmentSiblingNode->value();
								}
						}
//						std::vector<CCTOP::Core::TopologyEntry> topology;
//						std::vector<CCTOP::Core::ExperimentEntry> experiments;
//						seqContext.addTopDBHit(outherId, refSeq, htpSeq, topology, experiments, "", false, -1, -1);
					}/*else
						if(!strcmp(topdbSiblingNode->name(), XML_ELEMENT_CHAIN))
						{
							Wt::Dbo::ptr<TMCRef> tmCRef = _persistanceUtils.createTMCRef(crossRef, xbuilder::commons::xml::getAttribute(topdbSiblingNode, XML_ATTRIBUTE_ID, NULL, true));
							if(!tmCRef.get())
								throw Wt::WException("TMCREF creation failed!");
						}*/
				}
			}else
			{
				if(!strcmp(crNode->name(), XML_ELEMENT_UNIPROT))
				{
					seqContext.setUniprotId(outherId);
					for(xml_node<>* uniSiblingNode = crNode->first_node() ; uniSiblingNode ;uniSiblingNode = uniSiblingNode->next_sibling())
					{
						if(!strcmp(uniSiblingNode->name(), XML_ELEMENT_AC))
						{
							if(uniSiblingNode == crNode->first_node())
								seqContext.setUniprotBlastAc(uniSiblingNode->value());
							else
								seqContext.addUniprotAC(uniSiblingNode->value());
						}
					}
				}else
				{
					/*if(!strcmp(crNode->name(), XML_ELEMENT_SIGNALP))
					{
						std::string parameters;
						std::string results;
						for(xml_node<>* uniSiblingNode = crNode->first_node() ; uniSiblingNode ;uniSiblingNode = uniSiblingNode->next_sibling())
						{
							if(!strcmp(uniSiblingNode->name(), XML_ELEMENT_PARAMETERS))
							{
								parameters = uniSiblingNode->value();
							}else
								if(!strcmp(uniSiblingNode->name(), XML_ELEMENT_RESULTS))
								{
									results = uniSiblingNode->value();
								}
						}
					}*/
				}
			}
		}
	}
}

void CCTOP::Core::XML::XMLProcessor::parseTopologies(SequenceContext& seqContext, rapidxml::xml_node<>* node) const
{
	/*xml_node<>* topNode = node->first_node(XML_ELEMENT_TOPOLOGY);
	if(topNode)
	{
		seqContext.setReliability(getAttributeAsDouble(topNode, XML_ATTRIBUTE_RELIABILITY, 0.0, true));
		std::vector<CCTOP::Core::TopologyEntry> topology;

		int counter = 0;
		for(xml_node<>* siblingNode = topNode->first_node(XML_ELEMENT_REGION) ; siblingNode ;siblingNode = siblingNode->next_sibling(XML_ELEMENT_REGION))
		{
			int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
			int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
			Localization regionLoc = LOCALIZATION_UNKNOWN;
			const char* locStr = getAttribute( siblingNode, XML_ATTRIBUTE_LOC, NULL, true);
			if(locStr)
			{
				regionLoc = Core::parseCharLocalization(*locStr);
			}

			seqContext.addCCTopTopology(start, stop, regionLoc);

			counter++;
		}
	}*/
}

void CCTOP::Core::XML::XMLProcessor::parsePredictions(SequenceContext& seqContext, rapidxml::xml_node<>* node) const
{
	xml_node<>* topNode = node->first_node(XML_ELEMENT_PREDICTIONS);
	if(topNode)
	{
		for(xml_node<>* predictionNode = topNode->first_node(XML_ELEMENT_PREDICTION) ; predictionNode ; predictionNode = predictionNode->next_sibling(XML_ELEMENT_PREDICTION))
		{
			const char* predName = getAttribute(predictionNode, XML_ATTRIBUTE_NAME, NULL, true);

			if(predName && strcmp(predName, CCTOPLIB_METHOD_HMMTOP))
			{
				for(xml_node<>* siblingNode = predictionNode->first_node(XML_ELEMENT_REGION) ; siblingNode ;siblingNode = siblingNode->next_sibling(XML_ELEMENT_REGION))
				{
					int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
					int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
					Localization regionLoc = LOCALIZATION_UNKNOWN;
					const char* locStr = getAttribute( siblingNode, XML_ATTRIBUTE_LOC, NULL, true);
					if(locStr)
					{
						regionLoc = Core::parseCharLocalization(*locStr);
					}

					seqContext.addMethodHit(predName, start, stop, regionLoc);
				}
			}
		}
	}
}

void CCTOP::Core::XML::XMLProcessor::parseConstraints(SequenceContext& seqContext, const MethodContext& methodContext, rapidxml::xml_node<>* node) const
{
	xml_node<>* topNode = node->first_node(XML_ELEMENT_CONSTRAINTS);
	if(topNode)
	{
		for(xml_node<>* constraintNode = topNode->first_node(XML_ELEMENT_CONSTRAINT) ; constraintNode ; constraintNode = constraintNode->next_sibling(XML_ELEMENT_CONSTRAINT))
		{
			std::vector<CCTOP::Core::ExperimentEntry> experiments;

			const char* source = NULL;
			const char* sourceId = NULL;

			rapidxml::xml_attribute<>* sourceAttr = constraintNode->first_attribute(XML_ATTRIBUTE_SOURCE);
			if(sourceAttr) source = sourceAttr->value();
			rapidxml::xml_attribute<>* sourceIdAttr = constraintNode->first_attribute(XML_ATTRIBUTE_SOURCEID);
			if(sourceIdAttr) sourceId = sourceIdAttr->value();

			std::string signalId;
			if(source && sourceId)
			{
//				if(!strcmp(VALUE_CONSTRAINTTYPE_SIGNAL, source))
//				{
//					seqContext.setNTerminalOutSide(true);
//					signalId = sourceId;
//				}else
				{
					seqContext.setNTerminalOutSide(true);

					int counter = 0;
					for(xml_node<>* siblingNode = constraintNode->first_node(XML_ELEMENT_CONSTRAINTREGION) ; siblingNode ;siblingNode = siblingNode->next_sibling(XML_ELEMENT_CONSTRAINTREGION))
					{
						int start = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_FROM, -1, true);
						int stop = getAttributeAsInt( siblingNode, XML_ATTRIBUTE_TO, -1, true);
						const char* subSourcePtr = getAttribute( siblingNode, XML_ATTRIBUTE_SUBSOURCE, NULL, false);
						const char* subIdPtr = getAttribute( siblingNode, XML_ATTRIBUTE_SUBID, NULL, false);
						std::string subSource;
						std::string subId;
						if(subSourcePtr)
							subSource = subSourcePtr;
						if(subIdPtr)
							subId = subIdPtr;

						Localization regionLoc = LOCALIZATION_UNKNOWN;
						const char* locStr = getAttribute( siblingNode, XML_ATTRIBUTE_LOC, NULL, true);
						if(locStr)
						{
							regionLoc = Core::parseCharLocalization(*locStr);
						}

						if(!strcmp("TOPDOM", source))
						{
							seqContext.addTOPDOMHit(sourceId , start, stop, regionLoc);
						}/*else
						{
							ExperimentEntry expEntry;
							expEntry.beg = start;
							expEntry.end = stop;
							expEntry.loc = regionLoc;
							expEntry.id = subId;
							expEntry.pdbtmChain= subSource;
							if(!subSource.empty())
							{
								expEntry.pdbId = subSource.substr(0, subSource.length()-1);
								expEntry.chainId= subSource.substr(subSource.length()-1, 1);
							}
							experiments.push_back(expEntry);
						}*/

						counter++;
					}
				}
			}
			/*
			std::vector<CCTOP::Core::TopDBHit>::iterator topdbIter = seqContext.getTopDBHits().begin();
			while(topdbIter != seqContext.getTopDBHits().end()
					&& topdbIter->topDBId.compare(sourceId))
			{
				topdbIter++;
			}

			if(topdbIter != seqContext.getTopDBHits().end())
				topdbIter->experiments = experiments;*/
		}
	}
}

char* CCTOP::Core::XML::XMLProcessor::copyString(const std::string& str) const
{
	char* ret = NULL;
	if(!str.empty())
	{
		ret = new char[str.length()+1];
		memcpy(ret, str.c_str(), str.length());
		ret[str.length()] = '\0';
	}
	return ret;
}

void CCTOP::Core::XML::XMLProcessor::createXML(SequenceContext& seqContext, const MethodContext& methodContext, std::string& container, const std::string& cctopId, const std::string& copyrightText) const
{
	container.clear();

	xml_document<> doc;
	// xml declaration
	xml_node<>* decl = doc.allocate_node(node_declaration);
	decl->append_attribute(doc.allocate_attribute("version", "1.0"));
	//decl->append_attribute(doc.allocate_attribute("encoding", "utf-8"));
	doc.append_node(decl);

	// root node
	xml_node<>* rootHtp = doc.allocate_node(node_element, XML_ELEMENT_CCTOPITEM);
	rootHtp->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_ID, cctopId.c_str()));
	if(seqContext.isTransmembrane())
		rootHtp->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TRANSMEMBRANE, "yes"));
	else
		rootHtp->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_TRANSMEMBRANE, "no"));
	/*if(protein->getEvidence().get())
		rootHtp->append_attribute(doc.allocate_attribute(XML_ATTRIBUTE_EVIDENCE, protein->getEvidence()->getEnumKey().c_str()));*/
	doc.append_node(rootHtp);

	// child node
	writeCopyright(copyrightText, rootHtp, doc);
	if(!seqContext.getName().empty())
		writeName(seqContext, rootHtp, doc);
	if(seqContext.isTransmembrane())
	{
		writeCrossRef(seqContext, rootHtp, doc);
		writeSequence(seqContext, rootHtp, doc);
		writeTopologies(seqContext, rootHtp, doc);
		writePredictions(seqContext, rootHtp, doc);
		writeConstraints(seqContext, methodContext, rootHtp, doc);
	}
	else
	{
		//writeCrossRef(seqContext, rootHtp, doc);
		writeSequence(seqContext, rootHtp, doc);
	}

	rapidxml::print(std::back_inserter(container), doc);

	std::vector<char*>::iterator iter = _stringCache.begin();
	while(iter != _stringCache.end())
	{
		delete [] *iter;
		iter++;
	}

	_stringCache.clear();
}

void CCTOP::Core::XML::XMLProcessor::parse(SequenceContext& seqContext, const MethodContext& methodContext, const std::string& xmlFile, bool& isTransmemb) const
{
	if(!xmlFile.empty())
	{
		xml_document<> doc;
		std::ifstream theFile(xmlFile.c_str());
		if(theFile.is_open())
		{
			std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
			buffer.push_back('\0');
			doc.parse<0>(&buffer[0]);

			// Find our root node
			xml_node<>* rootNode = doc.first_node(XML_ELEMENT_CCTOPITEM);
			if(rootNode)
			{
				std::string name;
				rapidxml::xml_attribute<>* idAttr = rootNode->first_attribute(XML_ATTRIBUTE_ID);
				if(idAttr)
					name = idAttr->value();

				parseCrossRefs(seqContext, rootNode);
				parseSequence(seqContext, rootNode);
				parseTopologies(seqContext, rootNode);
				parsePredictions(seqContext, rootNode);
				parseConstraints(seqContext, methodContext, rootNode);
			}
			theFile.close();
		}else
		{
			std::cerr << "Can not find file: " << xmlFile << std::endl;
		}
	}
}
