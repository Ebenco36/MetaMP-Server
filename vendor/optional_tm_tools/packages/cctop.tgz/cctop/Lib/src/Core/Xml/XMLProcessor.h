/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * XMLProcessor
 *
 *  Created on: 2014.07.04.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_XML_XMLPROCESSOR_H_
#define CCTOP_CORE_XML_XMLPROCESSOR_H_

#include "../../Utils/Xml/rapidxml.hpp"
#include "../../CCTopLib.h"

namespace CCTOP { namespace Core { namespace XML {

class XMLProcessor
{
protected:
	bool writableLocalization(Localization loc) const;

	void writeCopyright(const std::string& copyRight, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writeName(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writeSequence(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writeCrossRef(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writeTopologies(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writePredictions(SequenceContext& seqContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;
	void writeConstraints(SequenceContext& seqContext, const MethodContext& methodContext, rapidxml::xml_node<>* node, rapidxml::xml_document<>& doc) const;


	void parseSequence(SequenceContext& seqContext, rapidxml::xml_node<>* node) const;
	void parseCrossRefs(SequenceContext& seqContext, rapidxml::xml_node<>* node) const;
	void parseTopologies(SequenceContext& seqContext, rapidxml::xml_node<>* node) const;
	void parsePredictions(SequenceContext& seqContext, rapidxml::xml_node<>* node) const;
	void parseConstraints(SequenceContext& seqContext, const MethodContext& methodContext, rapidxml::xml_node<>* node) const;

	char* copyString(const std::string& str) const;

public:
	static const char* XML_ELEMENT_CCTOPITEM;
	static const char* XML_ELEMENT_COPYRIGHT;
	static const char* XML_ELEMENT_CROSSREF;
	static const char* XML_ELEMENT_UNIPROT;
	static const char* XML_ELEMENT_SIGNALP;
	static const char* XML_ELEMENT_AC;
	static const char* XML_ELEMENT_PARAMETERS;
	static const char* XML_ELEMENT_RESULTS;
	static const char* XML_ELEMENT_RESOLUTION;
	static const char* XML_ELEMENT_METHOD;
	static const char* XML_ELEMENT_CHAINS;
	static const char* XML_ELEMENT_CHAIN;
	static const char* XML_ELEMENT_FRAGMENT;
	static const char* XML_ELEMENT_SIDEDEFINITION;
	static const char* XML_ELEMENT_PDBTM;
	static const char* XML_ELEMENT_MODELTM;
	static const char* XML_ELEMENT_TOPDB;
	static const char* XML_ELEMENT_TOPDOM;
	static const char* XML_ELEMENT_SEQUENCE;
	static const char* XML_ELEMENT_NAME;
	static const char* XML_ELEMENT_TRANSIT;
	static const char* XML_ELEMENT_SIGNAL;
	static const char* XML_ELEMENT_PROPEPTIDE;
	static const char* XML_ELEMENT_NOTE;
	static const char* XML_ELEMENT_SEQ;
	static const char* XML_ELEMENT_TOPOLOGY;
	static const char* XML_ELEMENT_RELIABILITY;
	static const char* XML_ELEMENT_REGION;
	static const char* XML_ELEMENT_CONSTRAINTREGION;
	static const char* XML_ELEMENT_PREDICTIONS;
	static const char* XML_ELEMENT_PREDICTION;
	static const char* XML_ELEMENT_CONSTRAINTS;
	static const char* XML_ELEMENT_CONSTRAINT;
	static const char* XML_ELEMENT_ALIGNMENT;
	static const char* XML_ELEMENT_CROSSREFSEQ;
	static const char* XML_ELEMENT_HTPSEQ;

	static const char* XML_ATTRIBUTE_AC;
	static const char* XML_ATTRIBUTE_TYPE;
	static const char* XML_ATTRIBUTE_TRANSMEMBRANE;
	static const char* XML_ATTRIBUTE_ID;
	static const char* XML_ATTRIBUTE_RELIABILITY;
	static const char* XML_ATTRIBUTE_CHECKSUM;
	static const char* XML_ATTRIBUTE_LENGTH;
	static const char* XML_ATTRIBUTE_TMSEQCOUNT;
	static const char* XML_ATTRIBUTE_NUMTM;
	static const char* XML_ATTRIBUTE_LOC;
	static const char* XML_ATTRIBUTE_NAME;
	static const char* XML_ATTRIBUTE_SOURCE;
	static const char* XML_ATTRIBUTE_SOURCEID;
	static const char* XML_ATTRIBUTE_SUBSOURCE;
	static const char* XML_ATTRIBUTE_SUBID;
	static const char* XML_ATTRIBUTE_FROM;
	static const char* XML_ATTRIBUTE_TO;
	static const char* XML_ATTRIBUTE_EVIDENCE;

	static const char* VALUE_CONSTRAINTTYPE_SIGNAL;


	static const char* VALUE_SIGNALMODE_UNDEFINED;
	static const char* VALUE_SIGNALMODE_TOPDB;
	static const char* VALUE_SIGNALMODE_UNIPROT;
	static const char* VALUE_SIGNALMODE_SIGNALP;


	//static const char* DB_VALUE_METHODTYPE_OBSERVED;
	static const char* DB_VALUE_METHODTYPE_HTP;
	static const char* DB_VALUE_METHODTYPE_SIGNAL;
	static const char* DB_VALUE_METHODTYPE_ENUM_RESERVED;

	static const char* DB_VALUE_CROSSREFTYPE_PDBTM;
	static const char* DB_VALUE_CROSSREFTYPE_PDB;
	static const char* DB_VALUE_CROSSREFTYPE_TOPDOM;
	static const char* DB_VALUE_CROSSREFTYPE_TOPDB;
	static const char* DB_VALUE_CROSSREFTYPE_UNIPROT;
	static const char* DB_VALUE_CROSSREFTYPE_SIGNAL;

	static const char* DB_VALUE_REGIONTYPE_MEMBRANE;
	static const char* DB_VALUE_REGIONTYPE_TRANSIT;
	static const char* DB_VALUE_REGIONTYPE_SIGNAL;
	static const char* DB_VALUE_REGIONTYPE_PROPEPTIDE;
	static const char* DB_VALUE_REGIONTYPE_UNKNOWN;
	static const char* DB_VALUE_REGIONTYPE_INSIDE;
	static const char* DB_VALUE_REGIONTYPE_OUTSIDE;
	static const char* DB_VALUE_REGIONTYPE_RE_ENTRANT;
	static const char* DB_VALUE_REGIONTYPE_MEMREENTRANT;

	static const char* DB_VALUE_STRLEVEL_3D;
	static const char* DB_VALUE_STRLEVEL_EXPERIMENT;
	static const char* DB_VALUE_STRLEVEL_EXISTS;
	static const char* DB_VALUE_STRLEVEL_PREDICTION;

	const CCTopLib&					_lib;
	mutable std::vector<char*>		_stringCache;

	XMLProcessor(const CCTopLib& lib);
	XMLProcessor(const XMLProcessor& copy);
	XMLProcessor& operator=(const XMLProcessor& copy);
	~XMLProcessor();

	void createXML(SequenceContext& seqContext, const MethodContext& methodContext, std::string& container, const std::string& cctopId, const std::string& copyrightText) const;
	void parse(SequenceContext& seqContext, const MethodContext& methodContext, const std::string& xmlFile, bool& isTransmemb) const;
};


}}}


#endif /* CCTOP_CORE_XML_XMLPROCESSOR_H_ */
