/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * SequenceContext.h
 *
 *  Created on: 2014.07.04.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_SEQUENCECONTEXT_H_
#define CCTOP_CORE_SEQUENCECONTEXT_H_

#include "MethodContext.h"
#include "../Utils/Threading/Mutex.h"

#include <string>
#include <map>
#include <vector>

namespace CCTOP { namespace Core
{
struct Region
{
	int begin;
	int end;
};
struct TopDBHit
{
	std::string topDBId;
	std::string crossRefSeq;
	std::string cctopSeq;
	std::string reducedSeq;

	std::vector<CCTOP::Core::TopologyEntry> topology;
	std::vector<CCTOP::Core::ExperimentEntry> experiments;
	int signalBeg;
	int signalEnd;
	bool hasSignalRegion;
};



enum SignalMode
{
	SIGNALMODE_UNDEFINED = 0,
	SIGNALMODE_TOPDB,
	SIGNALMODE_UNIPROT,
	SIGNALMODE_UNIPROT_EN,
	SIGNALMODE_SIGNALP
};

enum TransitMode
{
	TRANSITMODE_UNDEFINED = 0,
	TRANSITMODE_TOPDB,
	TRANSITMODE_UNIPROT,
	TRANSITMODE_EXT
};

/*
 * Collection of attributes belonging to a specified sequence
 *
 * Based on
 * -the TOPDB
 * -the EXTERNAL Application results
 */
class SequenceContext
{
	Utils::Threading::Mutex								_lock;

	ContextState 										_state;
	SignalMode											_signalMode;
	TransitMode											_transitMode;

	std::string											_sequence;
	std::string											_checksum;
	std::string											_sequenceFilePath;
	std::string											_cctopId;
	std::string											_hmmtopParam;

	//Seq without transit regions
	std::string											_reducedSequence;
	//Seq without transit&signal regions
	std::string											_signalReducedSequence;

	//Preprocessor variables
	//UNIPROT - can be changed at transit cut
	std::string											_uniprotBlastAc;
	std::vector< std::string >							_uniprotAcs;
	std::string											_uniprotId;
	bool												_hasUniprotEvidence;
	std::string											_name;
	std::string											_note;
	//TODO hmm too much mutables...
	mutable
	std::vector<Region>									_propeptides;
	mutable
	std::vector<Region>									_transits;
	mutable
	std::vector<Region>									_signals;
	//TOPDB
	mutable
	std::vector<TopDBHit>								_topDBHits;
	//SIGNAL
	int													_singnalPPos;
	bool 												_isNTerminalOutSide;

	//Reduction
	mutable
	std::vector<Region>									_removedTransitRegions;
	mutable
	std::vector<Region>									_removedSignalRegions;
	mutable
	std::map<SignalMode, Region>						_signalRegionMap;

	//Methods
	mutable
	std::map<std::string, std::vector<TopologyEntry> >	_methodHits;
	mutable
	std::map<std::string, std::vector<TopologyEntry> >	_topDOMHits;
	mutable
	std::vector<TopologyEntry>							_cctopTopology;
	mutable
	std::vector<const CCTOP::Core::TopologyEntry*>		_usedLoops;

	double												_reliability;
	double 												_isTransMembrane;
	double												_signalPDScore;
	int													_nterminalIndex;

	mutable
	std::vector<std::string>							_disabledMethods;
	bool												_useTMFilter;

	void undoRegionList(const std::vector<Region>&);
	void removeRegions(const std::vector<Region>& regions);
public:
	SequenceContext();
	SequenceContext(const SequenceContext& copy);
	~SequenceContext();
	SequenceContext& operator=(const SequenceContext& copy);

	void setSignalMode(SignalMode mode);
	void setTransitMode(TransitMode mode);
	void setSignalPPos(int pos);
	void setSignalPDScore(double score);
	SignalMode getSignalMode() const;
	TransitMode getTransitMode() const;
	int getSignalPPos() const;
	double getSignalPDScore();

	void setSequence(const std::string& sequence);
	void setSequenceChecksum(const std::string& checksum);
	void setCCTopID(const std::string& cctopId);
	void setName(const std::string& name);
	void setNote(const std::string& note);
	void setSequenceFilePath(const std::string& sequenceFilePath);
	void setHMMTopParam(const std::string& param);
	void setReducedSequence(const std::string& sequence);
	void setSignalReducedSequence(const std::string& sequence);
	void setUniprotBlastAc(const std::string& uniprotBlastAc);
	void setUniprotId(const std::string& id);
	void addPropeptideRegion(int begin, int end);
	void addTransitRegion(int begin, int end);
	void addSignalRegion(int begin, int end);
	void addTopDBHit(const std::string& topDBId, const std::string& crossRefSeq, const std::string& cctopSeq,
			const std::vector<CCTOP::Core::TopologyEntry>& topology, const std::vector<CCTOP::Core::ExperimentEntry>& experiments, const std::string& reducedSeq,
			bool hasSignalRegion, int signalBeg, int signalEnd);
	void addUniprotAC(const std::string& ac);
	void addRemovedTransitRegions(int beg, int end);
	void addRemovedSignalRegions(int beg, int end);
	void addMethodHit(const std::string& methodId, int beg, int end, Localization loc);
	void addCCTopTopology(int beg, int end, Localization loc);
	void addTOPDOMHit(const std::string& protId, int beg, int end, Localization loc);
	void setNTerminalOutSide(bool isOutSide);
	void addUsedLoopTopology(const CCTOP::Core::TopologyEntry* entry);
	void setReliability(double reliability);
	void addDisabledMethod(const std::string& methodName);
	void setTMFilter(bool filter);
	void setTransmembrane(bool transmembrane);
	void setUniprotEvidence(bool hasEvidence);

	const std::string& getSequence() const;
	const std::string& getCCTopID() const;
	const std::string& getName() const;
	const std::string& getNote() const;
	const std::string& getSequenceChecksum() const;
	const std::string& getSequenceFilePath() const;
	const std::string& getReducedSequence() const;
	const std::string& getHMMTopParam() const;
	const std::string& getSignalReducedSequence() const;
	const std::string& getUniprotBlastAc() const;
	const std::string& getUniprotId() const;
	std::vector<Region>& getPropeptideRegions() const;
	std::vector<Region>& getTransitRegions() const;
	std::vector<Region>& getSignalRegions() const;
	std::map<SignalMode, Region>& getSignalRegionMap() const;
	std::vector<TopDBHit>& getTopDBHits() const;
	bool isNTerminalOutSide() const;
	int getNTerminalIndex() const;
	const std::vector< std::string >& getUniprotACs() const;
	std::vector<Region>& getRemovedTransitRegions() const;
	std::vector<Region>& getRemovedSignalRegions() const;
	std::map<std::string, std::vector<TopologyEntry> >& getMethodHits() const;
	std::map<std::string, std::vector<TopologyEntry> >& getTOPDOMHits() const;
	std::vector<TopologyEntry>& getCCTOPTopology() const;
	bool hasUsedLoopTopology(const CCTOP::Core::TopologyEntry* entry) const;
	double getReliability() const;
	bool isMethodDisabled(const std::string& methodName) const;
	bool useTMFilter() const;
	bool isTransmembrane() const;
	bool hasUniprotEvidence() const;

	void invertTopology();
	void validateTopology();

	void applyRemovedTransitRegions();
	void applyRemovedSignalRegions();

	void undoRemovedTransitRegions();
	void undoRemovedSignalRegions();
};


}}




#endif /* CCTOP_CORE_SEQUENCECONTEXT_H_ */
