/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * TopDBParser.cpp
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#include "TopDBParser.h"

#include <cstring>
#include <iostream>
#include <fstream>
#include <algorithm>

const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_TOPDBS				= "TOPDBS";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_TOPDB				= "TOPDB";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_NAME				= "Name";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_CROSSREF			= "CrossRef";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_UNIPROT				= "UniProt";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_AC					= "AC";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_PDB					= "PDB";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_SIDEDEFINITION		= "SideDefinition";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_CHAINS				= "Chains";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_CHAIN				= "Chain";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_FRAGMENT			= "Fragment";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_SEQUENCE			= "Sequence";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_CLEAVABLE			= "Cleavable";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_SEQ					= "Seq";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_TOPOLOGY			= "Topology";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_REGIONS				= "Regions";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_REGION				= "Region";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_EXPERIMENTS			= "Experiments";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_EXP					= "Exp";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_TYPE				= "Type";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_SUBTYPE				= "Subtype";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_PDBREF				= "pdbRef";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_EXPDATA				= "Expdata";
const char*	CCTOP::Core::External::TopDBParser::XML_ELEMENT_PROBLEM				= "Problem";

const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_ID				= "ID";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_SIDE1				= "Side1";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_BEG				= "Beg";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_BEGIN				= "Begin";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_END				= "End";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_TYPE				= "Type";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_LOC				= "Loc";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_MIN				= "Min";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_MAX				= "Max";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_REF				= "Ref";
const char*	CCTOP::Core::External::TopDBParser::XML_ATTRIBUTE_REF2				= "Ref2";

const char*	CCTOP::Core::External::TopDBParser::XML_VALUE_PDBMTM				= "PDBTM";
const char*	CCTOP::Core::External::TopDBParser::XML_VALUE_STRUCTURE				= "Structure";
const char*	CCTOP::Core::External::TopDBParser::XML_VALUE_YES					= "yes";

CCTOP::Core::External::TopDBParser::TopDBParser()
{}

CCTOP::Core::External::TopDBParser::TopDBParser(const TopDBParser& copy)
{}

CCTOP::Core::External::TopDBParser::~TopDBParser()
{}

CCTOP::Core::External::TopDBParser& CCTOP::Core::External::TopDBParser::operator=(const CCTOP::Core::External::TopDBParser& copy) {return *this;}

bool CCTOP::Core::External::TopDBParser::parseTOPDB(rapidxml::xml_node<>* topDBNode, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const
{
	bool ret = false;

	if(topDBNode)
	{
		//simple attributes
		rapidxml::xml_attribute<>* topdbIdAttr = topDBNode->first_attribute(XML_ATTRIBUTE_ID);
		std::string id = topdbIdAttr->value();
		TopDBEntry* topDBEntry = methodContext.createTopDBEntry(id);
		topDBEntry->setId(id);


		rapidxml::xml_node<>* nameNode = topDBNode->first_node(XML_ELEMENT_NAME);
		if(nameNode)
			topDBEntry->setName(nameNode->value());

		//crossreferences
		rapidxml::xml_node<>* crossRefNode = topDBNode->first_node(XML_ELEMENT_CROSSREF);
		if(crossRefNode)
		{
			for(rapidxml::xml_node<>* crossRefItem = crossRefNode->first_node() ; crossRefItem; crossRefItem = crossRefItem->next_sibling())
			{
				if(!strcmp(XML_ELEMENT_UNIPROT, crossRefItem->name()))
				{
					rapidxml::xml_attribute<>* idAttr = crossRefItem->first_attribute(XML_ATTRIBUTE_ID);
					topDBEntry->setUniProtId(idAttr->value());
					for(rapidxml::xml_node<>* acItem = crossRefItem->first_node(XML_ELEMENT_AC) ; acItem; acItem = acItem->next_sibling(XML_ELEMENT_AC))
					{
						topDBEntry->addUniProtAC(acItem->value());
					}
				}else
					if(!strcmp(XML_ELEMENT_PDB, crossRefItem->name()))
					{
						rapidxml::xml_attribute<>* idAttr = crossRefItem->first_attribute(XML_ATTRIBUTE_ID);
						std::string pdbId = idAttr->value();
						InOrOut pdbLocl = IOO_ALTERNATE;
						std::map< std::string, std::vector<PDBFragment> > chains;

						for(rapidxml::xml_node<>* pdbAttrItem = crossRefItem->first_node() ; pdbAttrItem; pdbAttrItem = pdbAttrItem->next_sibling())
						{
							if(!strcmp(XML_ELEMENT_CHAINS, pdbAttrItem->name()))
							{
								for(rapidxml::xml_node<>* chainItem = pdbAttrItem->first_node(XML_ELEMENT_CHAIN) ; chainItem; chainItem = chainItem->next_sibling(XML_ELEMENT_CHAIN))
								{
									rapidxml::xml_attribute<>* idAttr = chainItem->first_attribute(XML_ATTRIBUTE_ID);
									std::string chainId = idAttr->value();
									std::vector<PDBFragment> frags;

									for(rapidxml::xml_node<>* fragmentItem = chainItem->first_node(XML_ELEMENT_FRAGMENT) ; fragmentItem; fragmentItem = fragmentItem->next_sibling(XML_ELEMENT_FRAGMENT))
									{
										PDBFragment frag;
										rapidxml::xml_attribute<>* begAttr = fragmentItem->first_attribute(XML_ATTRIBUTE_BEGIN);
										if(begAttr)
											frag.beg = atoi(begAttr->value());

										rapidxml::xml_attribute<>* endAttr = fragmentItem->first_attribute(XML_ATTRIBUTE_END);
										if(endAttr)
											frag.end = atoi(endAttr->value());

										frags.push_back(frag);
									}

									chains[chainId] = frags;
								}
							}else
								if(!strcmp(XML_ELEMENT_SIDEDEFINITION, pdbAttrItem->name()))
								{
									rapidxml::xml_attribute<>* side1Attr = pdbAttrItem->first_attribute(XML_ATTRIBUTE_SIDE1);
									if(side1Attr)
									{
										pdbLocl = parseInOrOut(side1Attr->value());
									}
								}
						}

						topDBEntry->addPDBEntry(pdbId, pdbLocl, chains);
					}
			}
		}

		//sequence
		rapidxml::xml_node<>* sequenceNode = topDBNode->first_node(XML_ELEMENT_SEQUENCE);
		if(sequenceNode)
		{
			rapidxml::xml_node<>* cleavableItem = sequenceNode->first_node(XML_ELEMENT_CLEAVABLE);
			if(cleavableItem)
			{
				//Begin="1" End="61" Type="Transit"
				TopologyEntry entry;
				rapidxml::xml_attribute<>* begAttr = cleavableItem->first_attribute(XML_ATTRIBUTE_BEGIN);
				if(begAttr)
					entry.beg = atoi(begAttr->value());

				rapidxml::xml_attribute<>* endAttr = cleavableItem->first_attribute(XML_ATTRIBUTE_END);
				if(endAttr)
					entry.end = atoi(endAttr->value());

				rapidxml::xml_attribute<>* locAttr = cleavableItem->first_attribute(XML_ATTRIBUTE_TYPE);
				if(locAttr)
					entry.loc = parseLocalization(locAttr->value());

				topDBEntry->addTopologyEntry(entry);
			}

			rapidxml::xml_node<>* seqItem = sequenceNode->first_node(XML_ELEMENT_SEQ);
			if(seqItem)
			{
				std::string str = seqItem->value();
				str.erase(std::remove(str.begin(), str.end(), ' '), str.end());
				str.erase(std::remove(str.begin(), str.end(), '\n'), str.end());

				topDBEntry->setAminoSeq(str);
			}
		}
		//Topology
		rapidxml::xml_node<>* topologyNode = topDBNode->first_node(XML_ELEMENT_TOPOLOGY);
		if(topologyNode)
		{
			rapidxml::xml_node<>* regionsNode = topologyNode->first_node(XML_ELEMENT_REGIONS);
			if(regionsNode)
			{
				for(rapidxml::xml_node<>* regionItem = regionsNode->first_node(XML_ELEMENT_REGION) ; regionItem; regionItem = regionItem->next_sibling(XML_ELEMENT_REGION))
				{
					if(ignoreMinMax || (!regionItem->first_attribute(XML_ATTRIBUTE_MIN) && !regionItem->first_attribute(XML_ATTRIBUTE_MAX)))
					{
						TopologyEntry entry;
						rapidxml::xml_attribute<>* begAttr = regionItem->first_attribute(XML_ATTRIBUTE_BEGIN);
						if(begAttr)
							entry.beg = atoi(begAttr->value());

						rapidxml::xml_attribute<>* endAttr = regionItem->first_attribute(XML_ATTRIBUTE_END);
						if(endAttr)
							entry.end = atoi(endAttr->value());

						rapidxml::xml_attribute<>* locAttr = regionItem->first_attribute(XML_ATTRIBUTE_LOC);
						if(locAttr)
							entry.loc = parseLocalization(locAttr->value());

						if(entry.loc == LOCALIZATION_SIGNAL)
						{
							std::vector<CCTOP::Core::TopologyEntry>& entries = topDBEntry->getTopologyEntries();
							std::vector<CCTOP::Core::TopologyEntry>::iterator entryIter = entries.begin();
							while(entryIter != entries.end() && entryIter->loc != LOCALIZATION_TRANSIT)
							{
								entryIter++;
							}

							if(entryIter != entries.end())
							{
								if(entry.beg <= entryIter->beg && entry.end >= entryIter->end)
								{
									entry.beg = entryIter->end;
								}
							}
							if(entry.beg != entry.end)
								topDBEntry->addTopologyEntry(entry);
						}else
							topDBEntry->addTopologyEntry(entry);
					}
				}
			}
		}
		//Experiments
		rapidxml::xml_node<>* experimentsNode = topDBNode->first_node(XML_ELEMENT_EXPERIMENTS);
		if(experimentsNode)
		{
			for(rapidxml::xml_node<>* regionItem = experimentsNode->first_node(XML_ELEMENT_REGION) ; regionItem; regionItem = regionItem->next_sibling(XML_ELEMENT_REGION))
			{
				if(ignoreMinMax || (!regionItem->first_attribute(XML_ATTRIBUTE_MIN) && !regionItem->first_attribute(XML_ATTRIBUTE_MAX)))
				{
					ExperimentEntry entry;
					bool skip = false;
					entry.evidenceLevel = EVIDENCELEVEL_UNDEFINED;

					rapidxml::xml_attribute<>* begAttr = regionItem->first_attribute(XML_ATTRIBUTE_BEGIN);
					if(begAttr)
						entry.beg = atoi(begAttr->value());

					rapidxml::xml_attribute<>* endAttr = regionItem->first_attribute(XML_ATTRIBUTE_END);
					if(endAttr)
						entry.end = atoi(endAttr->value());

					rapidxml::xml_attribute<>* locAttr = regionItem->first_attribute(XML_ATTRIBUTE_LOC);
					if(locAttr)
						entry.loc = parseLocalization(locAttr->value());
					rapidxml::xml_attribute<>* lidAttr = regionItem->first_attribute(XML_ATTRIBUTE_ID);
					entry.id = lidAttr->value();


					bool duplicate = false;
					rapidxml::xml_node<>* expNode = regionItem->first_node(XML_ELEMENT_EXP);
					if(expNode)
					{
						rapidxml::xml_attribute<>* refAttr = expNode->first_attribute(XML_ATTRIBUTE_REF);
						if(refAttr)
							entry.ref = refAttr->value();
						rapidxml::xml_attribute<>* ref2Attr = expNode->first_attribute(XML_ATTRIBUTE_REF2);
						if(ref2Attr)
							entry.ref2 = ref2Attr->value();

						rapidxml::xml_node<>* typeNode = expNode->first_node(XML_ELEMENT_TYPE);
						if(typeNode)
						{
							if(!strcmp(XML_VALUE_STRUCTURE, typeNode->value()))
							{
								entry.evidenceLevel = EVIDENCELEVEL_EXPERIMENT;
							}
						}

						rapidxml::xml_node<>* subTypeNode = expNode->first_node(XML_ELEMENT_SUBTYPE);
						if(subTypeNode)
						{
							if(!strcmp(XML_VALUE_PDBMTM, subTypeNode->value()))
							{
								entry.evidenceLevel = EVIDENCELEVEL_3D_STRUCTURE;
							}else
							{
								entry.evidenceLevel = EVIDENCELEVEL_EXPERIMENT;
							}

						}

						rapidxml::xml_node<>* expdataNode = expNode->first_node(XML_ELEMENT_EXPDATA);
						if(expdataNode)
						{
							rapidxml::xml_node<>* problemNode = expdataNode->first_node(XML_ELEMENT_PROBLEM);
							if(problemNode)
							{
								if(!strcmp(XML_VALUE_YES, problemNode->value()))
								{
									skip = true;
								}
							}
						}

						if(!skip)
						{
							rapidxml::xml_node<>* pdbRefNode = expNode->first_node(XML_ELEMENT_PDBREF);
							if(pdbRefNode)
							{
								rapidxml::xml_attribute<>* pdbIdAttr = pdbRefNode->first_attribute(XML_ATTRIBUTE_ID);
								std::string pdbId = pdbIdAttr->value();
								std::vector<std::string> chainIds;
								rapidxml::xml_node<>* chainsNode = pdbRefNode->first_node(XML_ELEMENT_CHAINS);
								if(chainsNode)
								{
									for(rapidxml::xml_node<>* chainItem = chainsNode->first_node(XML_ELEMENT_CHAIN) ; chainItem; chainItem = chainItem->next_sibling(XML_ELEMENT_CHAIN))
									{
										rapidxml::xml_attribute<>* chainIdAttr = chainItem->first_attribute(XML_ATTRIBUTE_ID);
										std::string chainId = chainIdAttr->value();
										chainIds.push_back(chainId);

										const PDBEntry* pdbEntry = topDBEntry->getPDBEntry(pdbId, chainId);
										if(pdbEntry)
										{
											if(pdbEntry->pdbLocl == IOO_INSIDE)
											{
												if(entry.loc == LOCALIZATION_SIDE1)
												{
													entry.loc = LOCALIZATION_INSIDE;
												}else
												{
													if(entry.loc == LOCALIZATION_SIDE2)
													{
														entry.loc = LOCALIZATION_OUTSIDE;
													}
												}
											}else
												if(pdbEntry->pdbLocl == IOO_OUTSIDE)
												{
													if(entry.loc == LOCALIZATION_SIDE2)
													{
														entry.loc = LOCALIZATION_INSIDE;
													}else
													{
														if(entry.loc == LOCALIZATION_SIDE1)
														{
															entry.loc = LOCALIZATION_OUTSIDE;
														}
													}
												}else
												{
													if(entry.loc == LOCALIZATION_SIDE2 || entry.loc == LOCALIZATION_SIDE1)
													{
														entry.loc = LOCALIZATION_UNKNOWN;
														duplicate = true;
													}
												}
										}
									}
									//if(entry.evidenceLevel == EVIDENCELEVEL_3D_STRUCTURE)
									{
										entry.chainIds = chainIds;
										entry.pdbId = pdbId;
									}
								}
							}
						}
					}

					if(!skip)
					{
						if(duplicationEnabled && duplicate)
						{
							entry.loc = LOCALIZATION_INSIDE;
							topDBEntry->addExperimentEntry(entry);
							entry.loc = LOCALIZATION_OUTSIDE;
							topDBEntry->addExperimentEntry(entry);
						}else
						{
							topDBEntry->addExperimentEntry(entry);
						}
					}
				}
			}
		}
	}

	return ret;
}

bool CCTOP::Core::External::TopDBParser::parseGroupFile(const std::string& xmlFile, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const
{
	bool ret = true;
	if(!xmlFile.empty())
	{
		rapidxml::xml_document<> doc;
		std::ifstream theFile (xmlFile.c_str());
		if(theFile.is_open())
		{
			std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
			buffer.push_back('\0');
			doc.parse<0>(&buffer[0]);

			// Find our root node
			rapidxml::xml_node<>* rootNode = doc.first_node(XML_ELEMENT_TOPDBS);
			if(rootNode)
			{
				for(rapidxml::xml_node<>* topDBNode = rootNode->first_node(XML_ELEMENT_TOPDB) ; topDBNode; topDBNode = topDBNode->next_sibling(XML_ELEMENT_TOPDB))
				{
					ret |= parseTOPDB(topDBNode, methodContext, ignoreMinMax, duplicationEnabled);
				}
			}
			theFile.close();

			ret = true;
		}else
		{
			std::cerr << "Can not find file: " << xmlFile << std::endl;
		}
	}else
	{
		std::cerr << "No fileName spec.: " << xmlFile << std::endl;
	}

	return ret;
}

bool CCTOP::Core::External::TopDBParser::parseFile(const std::string& xmlFile, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const
{
	bool ret = true;
	if(!xmlFile.empty())
	{
		rapidxml::xml_document<> doc;
		std::ifstream theFile (xmlFile.c_str());
		if(theFile.is_open())
		{
			std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
			buffer.push_back('\0');
			doc.parse<0>(&buffer[0]);

			// Find our root node
			rapidxml::xml_node<>* topDBNode = doc.first_node(XML_ELEMENT_TOPDB);
			if(topDBNode)
			{
				ret = parseTOPDB(topDBNode, methodContext, ignoreMinMax, duplicationEnabled);
			}
			theFile.close();

			ret = true;
		}else
		{
			std::cerr << "Can not find file: " << xmlFile << std::endl;
		}
	}else
	{
		std::cerr << "No fileName spec.: " << xmlFile << std::endl;
	}

	return ret;
}


