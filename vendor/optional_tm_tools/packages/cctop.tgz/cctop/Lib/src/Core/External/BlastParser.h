/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * TopDBParser.h
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_EXTERNAL_BLASTPARSER_H_
#define CCTOP_CORE_EXTERNAL_BLASTPARSER_H_

#include "../MethodContext.h"
#include "../SequenceContext.h"

#include <string>
#include <vector>

#include "../../Utils/Xml/rapidxml.hpp"

namespace CCTOP { namespace Core { namespace External
{

class BlastParser
{
protected:
	static const char*	XML_ELEMENT_BLASTOUTPUT;
	static const char*	XML_ELEMENT_BLASTOUTPUT_ITERATIONS;
	static const char*	XML_ELEMENT_ITERATION;
	static const char*	XML_ELEMENT_ITERATION_HITS;
	static const char*	XML_ELEMENT_HIT;
	static const char*	XML_ELEMENT_HIT_DEF;
	static const char*	XML_ELEMENT_HIT_LEN;
	static const char*	XML_ELEMENT_HIT_HSPS;
	static const char*	XML_ELEMENT_HSP;
	static const char*	XML_ELEMENT_HSP_QSEQ;
	static const char*	XML_ELEMENT_HSP_HSEQ;
	static const char*	XML_ELEMENT_HSP_MIDLINE;
	static const char*	XML_ELEMENT_HSP_HIT_FROM;
	static const char*	XML_ELEMENT_HSP_HIT_TO;
	static const char*	XML_ELEMENT_HSP_QUERY_FROM;
	static const char*	XML_ELEMENT_HSP_QUERY_TO;

	static const char*	XML_VALUE_HIT_DEF_DELIMITER;

	bool checkUniProtValues(SequenceContext& seqContext, TopologyEntry& topologyEntry);

	void updatePositions(int beg, int end, int hsp_query_from, int hsp_query_to, int delta, const std::vector<std::string>& elems, int& newBeg, int& newEnd) const;

public:
	BlastParser();
	BlastParser(const BlastParser& copy);
	~BlastParser();
	BlastParser& operator=(const BlastParser& copy);

	bool parseUniProtResults(const std::string& blastXML, SequenceContext& seqContext, int blastLimit) const;

	bool mergeTopDbResults(const std::string& blastXML,	SequenceContext& seqContext, const MethodContext& methodContext) const;
};

}}}




#endif /* CCTOP_CORE_EXTERNAL_BLASTPARSER_H_ */
