/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MethodContext.h
 *
 *  Created on: 2014.07.04.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_METHODCONTEXT_H_
#define CCTOP_CORE_METHODCONTEXT_H_

#include <string>
#include <map>
#include <vector>

namespace CCTOP { namespace Core
{

enum EvidenceLevel
{
	EVIDENCELEVEL_UNDEFINED = 0,
	EVIDENCELEVEL_3D_STRUCTURE,
	EVIDENCELEVEL_EXPERIMENT,
	EVIDENCELEVEL_MODEL,
	EVIDENCELEVEL_EXISTS,
	EVIDENCELEVEL_PREDICTION
};

enum ContextState
{
	CONTEXTSTATE_UNDEFINED = 0,
	CONTEXTSTATE_INITIALIZED,
	CONTEXTSTATE_PREPROCESSED,
	CONTEXTSTATE_EXT_EXECUTED,
	CONTEXTSTATE_FINALIZED
};

enum InOrOut
{
	IOO_INSIDE = 0,
	IOO_OUTSIDE,
	IOO_ALTERNATE
};

enum Localization
{
	LOCALIZATION_MEMBRANE = 0,
	LOCALIZATION_INSIDE,
	LOCALIZATION_OUTSIDE,
	LOCALIZATION_UNKNOWN,
	LOCALIZATION_NOT_INSIDE,
	LOCALIZATION_NOT_OUTSIDE,
	LOCALIZATION_NOT_MEMBRANE,
	LOCALIZATION_SIDE1,
	LOCALIZATION_SIDE2,
	LOCALIZATION_SIGNAL,
	LOCALIZATION_PROPEPTIDE,
	LOCALIZATION_TRANSIT,
	LOCALIZATION_CLEAVABLE,
	LOCALIZATION_MEMBLOOP,
	LOCALIZATION_MEMBINS,
	LOCALIZATION_INTERFACIAL,

	QUASI_LOCALICATION_TRANSIT
};
Localization parseLocalization(const char* local);
Localization parseCharLocalization(char local);
char localizationToChar(Localization loc);
InOrOut parseInOrOut(const char* local);

struct PDBFragment
{
	int beg; int end;
};

struct PDBEntry
{
	std::string id;
	InOrOut pdbLocl;
	std::map< std::string, std::vector<PDBFragment> > chains;
};

struct TopologyEntry
{
	int beg;
	int end;
	Localization loc;
};

struct ExperimentEntry
{
	int beg;
	int end;
	Localization loc;
	std::string id;

	std::string ref;
	std::string ref2;
	std::string pdbId;
	std::vector<std::string> chainIds;
	EvidenceLevel evidenceLevel;
};

class TopDBEntry
{
protected:
	//TOPDB variables
	std::string										_name;
	std::string										_id;
	std::string										_uniProtId;
	std::string										_aminoSequence;

	std::vector<std::string>						_uniProtACs;
	std::map<std::string, std::vector<PDBEntry> >	_pdbEntries;
	mutable
	std::vector<TopologyEntry>						_topologyEntries;
	mutable
	std::vector<ExperimentEntry>					_experimentEntries;


public:
	TopDBEntry();
	TopDBEntry(const TopDBEntry& copy);
	~TopDBEntry();
	TopDBEntry& operator=(const TopDBEntry& copy);

	void setName(const std::string& name);
	void setId(const std::string& id);
	void setUniProtId(const std::string& id);
	void setAminoSeq(const std::string& aminoSequence);

	void addUniProtAC(const std::string& id);
	void addPDBEntry(const std::string& id, InOrOut pdbLocl, const std::map< std::string, std::vector<PDBFragment> >& chains);
	void addTopologyEntry(const TopologyEntry& topEntry);
	void addExperimentEntry(const ExperimentEntry& expEntry);

	const PDBEntry* getPDBEntry(const std::string& pdbId, const std::string& chainId) const;
	std::vector<TopologyEntry>& getTopologyEntries() const;
	std::vector<ExperimentEntry>& getExperimentEntries() const;
};

class MethodContext
{
protected:
	//External Methods
	ContextState 						_state;
	std::map<std::string, TopDBEntry*>	_topDBEntries;

	bool								_activeMembrain;

public:
	MethodContext();
	MethodContext(const MethodContext& copy);
	~MethodContext();
	MethodContext& operator=(const MethodContext& copy);

	void activateMembrain(bool active);
	bool isMembrainActive() const;

	TopDBEntry* createTopDBEntry(const std::string& topDBId);
	TopDBEntry* getTopDBEntry(const std::string& topDBId) const;
};

}}



#endif /* CCTOP_CORE_METHODCONTEXT_H_ */
