/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * SignalParser.h
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_EXTERNAL_SIGNALPARSER_H_
#define CCTOP_CORE_EXTERNAL_SIGNALPARSER_H_

#include "../SequenceContext.h"

#include <string>
#include <vector>


namespace CCTOP { namespace Core { namespace External
{

class SignalParser
{
protected:

public:
	SignalParser();
	SignalParser(const SignalParser& copy);
	~SignalParser();
	SignalParser& operator=(const SignalParser& copy);

	bool parseSignalPResults(const std::string& resulTxt, Core::SequenceContext& seqContext) const;
};

}}}




#endif /* CCTOP_CORE_EXTERNAL_SIGNALPARSER_H_ */
