/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * SignalParser.cpp
 *
 *  Created on: 2014.07.10.
 *      Author: "Istvan Remenyi"
 */

#include "SignalParser.h"

#include "../../Utils/StringUtils.h"

#include <cstdlib>
#include <iostream>
#include <sstream>

CCTOP::Core::External::SignalParser::SignalParser()
{}

CCTOP::Core::External::SignalParser::SignalParser(const SignalParser& copy)
{}

CCTOP::Core::External::SignalParser::~SignalParser()
{}

CCTOP::Core::External::SignalParser& CCTOP::Core::External::SignalParser::operator=(const SignalParser& copy)
{ return *this; }

bool CCTOP::Core::External::SignalParser::parseSignalPResults(const std::string& resultTxt, Core::SequenceContext& seqContext) const
{
	bool ret = true;

	std::istringstream f(resultTxt);
	std::string line;
	std::vector<std::string> vec;
	bool isPrev = false;
	while(std::getline(f, line))
	{
		if(isPrev)
		{
			vec.clear();
			Utils::splitSafe(line, ' ', vec);

			//depending on the seq name existence int the fasta file!
			if(line[0] == ' ')
			{
				if(!vec[8].compare("Y"))
				{
					seqContext.setSignalPPos(atoi(vec[3].c_str()));
					seqContext.setSignalPDScore(atof(vec[9].c_str()));
				}
				else
					seqContext.setSignalPPos(-1);
			}else
			{
				if(!vec[9].compare("Y"))
				{
					seqContext.setSignalPPos(atoi(vec[4].c_str()));
					seqContext.setSignalPDScore(atof(vec[10].c_str()));
				}
				else
					seqContext.setSignalPPos(-1);
			}
		}

		isPrev = line.find("# name") != std::string::npos;
	}

	return ret;
}

