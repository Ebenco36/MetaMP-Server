/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MethodParser.cpp
 *
 *  Created on: 2014.07.15.
 *      Author: "Istvan Remenyi"
 */

#include "MethodParser.h"

#include "../../CCTopLibDefs.h"

#include "../../Utils/Xml/rapidxml.hpp"

#include "../../Utils/StringUtils.h"
#include "../MethodContext.h"

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <algorithm>

static const char* PHILIUS_REGION_NON_CYTOPLASMIC	= "non-cytoplasmic";
static const char* PHILIUS_REGION_CYTOPLASMIC		= "cytoplasmic";
static const char* PHILIUS_REGION_TM_HELIX			= "TM helix";
static const char* PHILIUS_REGION_SIGNAL_PEPTIDE	= "signal-peptide";

static const char* MEMSAT_GLOB_STR					= "This looks like a transmembrane protein.";
static const char* MEMSAT_SIGNAL_PEPTIDE			= "Signal peptide:";
//static const char* MEMSAT_SIGNAL_SCORE				= "Signal score:";
static const char* MEMSAT_TOPOLOGY					= "Topology:";
static const char* MEMSAT_RE_ENTRANT_HELICES		= "Re-entrant helices:";
//static const char* MEMSAT_NOT_DETECTED				= "Not detected.";
static const char* MEMSAT_N_TERMINAL				= "N-terminal:";
static const char* MEMSAT_OUT						= "out";

static int PHILIUS_REGION_NON_CYTOPLASMIC_LEN		= strlen(PHILIUS_REGION_NON_CYTOPLASMIC);
static int PHILIUS_REGION_CYTOPLASMIC_LEN			= strlen(PHILIUS_REGION_CYTOPLASMIC);
static int PHILIUS_REGION_TM_HELIX_LEN				= strlen(PHILIUS_REGION_TM_HELIX);
static int PHILIUS_REGION_SIGNAL_PEPTIDE_LEN		= strlen(PHILIUS_REGION_SIGNAL_PEPTIDE);

//static int MEMSAT_SIGNAL_PEPTIDE_LEN				= strlen(MEMSAT_SIGNAL_PEPTIDE);
//static int MEMSAT_SIGNAL_SCORE_LEN					= strlen(MEMSAT_SIGNAL_SCORE);
static int MEMSAT_TOPOLOGY_LEN						= strlen(MEMSAT_TOPOLOGY);
static int MEMSAT_RE_ENTRANT_HELICES_LEN			= strlen(MEMSAT_RE_ENTRANT_HELICES);
//static int MEMSAT_N_TERMINAL_LEN					= strlen(MEMSAT_N_TERMINAL);


static const char* XML_ELEMENT_HTML					= "html";
static const char* XML_ELEMENT_BODY					= "body";
static const char* XML_ELEMENT_DIV					= "div";
static const char* XML_ELEMENT_FIELDSET				= "fieldset";
static const char* XML_ELEMENT_CENTER				= "center";
static const char* XML_ELEMENT_TABLE				= "table";
static const char* XML_ELEMENT_TR					= "tr";
static const char* XML_ELEMENT_TD					= "td";
static const char* XML_ELEMENT_A					= "a";
static const char* XML_ELEMENT_DL					= "dl";
static const char* XML_ELEMENT_DT					= "dt";
static const char* XML_ELEMENT_DD					= "dd";

static const char* XML_ATTRIBUTE_ID					= "id";
static const char* XML_ATTRIBUTE_CLASS				= "class";

struct TopologySorter {
  bool operator() ( const CCTOP::Core::TopologyEntry& i, const CCTOP::Core::TopologyEntry& j) { return (i.beg < j.beg);}
} gTopoSorter;

CCTOP::Core::External::MethodParser::MethodParser()
{}

CCTOP::Core::External::MethodParser::MethodParser(const MethodParser& copy)
{}

CCTOP::Core::External::MethodParser::~MethodParser()
{}

CCTOP::Core::External::MethodParser& CCTOP::Core::External::MethodParser::operator=(const MethodParser& copy)
{return *this;}

void CCTOP::Core::External::MethodParser::parseTMHMM(const std::string& result, Core::SequenceContext& context) const
{
	std::istringstream f(result);
	std::string line;
	std::stringstream topoStr;
	while(std::getline(f, line))
	{
		if(line.find("?0") != std::string::npos)
		{
			topoStr << line.substr(3);
		}
	}
	line = topoStr.str();

	unsigned int start = 0;
	while(start < line.length())
	{
		unsigned int stop = start;

		while((stop+1) < line.length()
				&& line.at(start) == line.at(stop+1))
		{
			stop++;
		}

		char st = line.at(start);
		CCTOP::Core::Localization loc = parseCharLocalization(st);

		context.addMethodHit(CCTOPLIB_METHOD_TMHMM, start+1, stop+1, loc);

		start = stop+1;
	}
}

void CCTOP::Core::External::MethodParser::parsePhobious(const std::string& result, Core::SequenceContext& context) const
{
	std::cerr << "type:" << CCTOPLIB_METHOD_PHOBIOUS << "  " << result << std::endl;

	std::istringstream f(result);
	std::string line;
	while(std::getline(f, line))
	{
		if(line.find("TM SP") == std::string::npos)
		{
			std::vector<std::string> vec;
			vec.clear();
			Utils::splitSafe(line, ' ', vec);
			line = vec[3];
			/*line = "n4-19c24/25o219-238i250-269o281-302i322-342o372-391i422-439o451-476i";
			line = "n4-15c20/21o36-56i";
			line = "o37-58i70-91o111-133i154-174o201-230i296-321o333-354i";*/
			vec.clear();
			Utils::splitSafe(line, '/', vec);
			if(vec.size()>1)
			{
				line = vec[0];

				int start = line.length()-1;
				if(start > -1)
				{
					while(!isdigit(line.at(start)))
					{
						start--;
					}

					int stop = start;
					while((stop-1) > -1
							&& isdigit(line.at(stop-1)))
					{
						stop--;
					}

					if(stop > -1 && start > -1)
					{
						std::string part = line.substr(stop, start);
						start = 1;
						stop = atoi(part.c_str());
						context.addMethodHit(CCTOPLIB_METHOD_PHOBIOUS, start, stop, CCTOP::Core::LOCALIZATION_SIGNAL);
					}
				}
				line = vec[1];
			}else
			{
				line = vec[0];
			}

			vec.clear();
			Utils::splitSafe(line, '-', vec);
			Localization loc = LOCALIZATION_UNKNOWN;
			int startTop = 0; //+1 to str index!
			int stopTop = 0; //detto :)

			std::vector<std::string>::iterator iter = vec.begin();
			while(iter != vec.end())
			{
				//o37   58i70   91o111  133i154   174o201  230i296   321o333  354i!!
				//21o36   56i
				line = *iter;

				unsigned int startSt = 0;
				if(startSt < line.length())
				{
					//check first char if it's a code
					char stChar = line.at(startSt);
					bool isFirstCharRegion = false;
					if((isFirstCharRegion = !isdigit(stChar)))
					{
						loc = parseCharLocalization(stChar);
						startTop = stopTop+1;
						startSt++;
					}

					//get the first number
					unsigned int stopSt = startSt;
					while((stopSt+1) < line.length()
							&& isdigit(line.at(stopSt+1)))
					{
						stopSt++;
					}
					std::string part = line.substr(startSt, stopSt-startSt+1);
					int firstTopNr = atoi(part.c_str());
					startSt=stopSt+1;

					if(isFirstCharRegion)
					{
						//can be inserted at once
						context.addMethodHit(CCTOPLIB_METHOD_PHOBIOUS, startTop, part.empty() ? context.getSignalReducedSequence().length() : (firstTopNr-1) , loc);
						stopTop = firstTopNr;
					}else
					{
						if(iter != vec.begin())
						{
							//add membrane region
							context.addMethodHit(CCTOPLIB_METHOD_PHOBIOUS, stopTop, firstTopNr, LOCALIZATION_MEMBRANE);
							stopTop = firstTopNr;
						}

						if(startSt < line.length())
						{
							stChar = line.at(startSt);
							bool isFirstCharRegion = false;
							if((isFirstCharRegion = !isdigit(stChar)))
							{
								loc = parseCharLocalization(stChar);
								startTop = stopTop+1;
								startSt++;
							}

							if(startSt < line.length())
							{
								//get the second number
								stopSt = startSt;
								while((stopSt+1) < line.length()
										&& isdigit(line.at(stopSt+1)))
								{
									stopSt++;
								}
								std::string part = line.substr(startSt, stopSt-startSt+1);
								int secondTopNr = atoi(part.c_str());

								context.addMethodHit(CCTOPLIB_METHOD_PHOBIOUS, iter == vec.begin()?firstTopNr:(firstTopNr+1), secondTopNr-1, loc);
								stopTop = secondTopNr;
							}else
							{
								context.addMethodHit(CCTOPLIB_METHOD_PHOBIOUS, iter == vec.begin()?firstTopNr:(firstTopNr+1), context.getSignalReducedSequence().length(), loc);
							}
						}
					}
				}
				iter++;
			}
		}
	}
}

void CCTOP::Core::External::MethodParser::parsePhilius(const std::string& result, Core::SequenceContext& context) const
{
	std::istringstream f(result);
	std::string line;
	std::stringstream topoStr;

	std::cerr << "type:" << CCTOPLIB_METHOD_PHILIUS << "  " << result << std::endl;

	while(std::getline(f, line))
	{
		if(!line.empty())
		{
			char ch = line.at(0);
			if(ch != '#' && ch != '-')
			{
				Localization loc = LOCALIZATION_UNKNOWN;
				size_t pos = 0;
				if((pos = line.find(PHILIUS_REGION_NON_CYTOPLASMIC)) != std::string::npos)
				{
					line = line.c_str() + pos + PHILIUS_REGION_NON_CYTOPLASMIC_LEN;
					loc = LOCALIZATION_OUTSIDE;
				}else
					if((pos = line.find(PHILIUS_REGION_CYTOPLASMIC)) != std::string::npos)
					{
						line = line.c_str() + pos + PHILIUS_REGION_CYTOPLASMIC_LEN;
						loc = LOCALIZATION_INSIDE;
					}else
						if((pos = line.find(PHILIUS_REGION_TM_HELIX)) != std::string::npos)
						{
							line = line.c_str() + pos + PHILIUS_REGION_TM_HELIX_LEN;
							loc = LOCALIZATION_MEMBRANE;
						}else
							if((pos = line.find(PHILIUS_REGION_SIGNAL_PEPTIDE)) != std::string::npos)
							{
								line = line.c_str() + pos + PHILIUS_REGION_SIGNAL_PEPTIDE_LEN;
								loc = LOCALIZATION_SIGNAL;
							}


				std::vector<std::string> vec;
				Utils::splitSafe(line, ' ', vec);
				if(vec.size() > 2)
				{
					int beg = atoi(vec[0].c_str());
					int end = atoi(vec[1].c_str());

					context.addMethodHit(CCTOPLIB_METHOD_PHILIUS, beg, end, loc);
				}
			}
		}
	}
}

std::string CCTOP::Core::External::MethodParser::parseMemBrainInvoke(const std::string& result, Core::SequenceContext& context) const
{
	std::string ret;
	if(!result.empty())
	{
		const char* tempSearchOf = "Result.htm?url=";
		size_t pos = 0;

		if((pos = result.find(tempSearchOf)) != std::string::npos)
		{
			int beg = pos + strlen(tempSearchOf);
			int end = beg;
			while((end+1) < (int)result.length()
					&& result.at(end+1) != ' ')
			{
				end++;
			}
			if(end)
			{
				ret = result.substr(beg, end-beg+1);
			}
		}
	}

	return ret;
}

bool CCTOP::Core::External::MethodParser::parseMemBrain(const std::string& result, Core::SequenceContext& context) const
{
	bool ret = !result.empty() && result.find("You don't have permission to access") == std::string::npos;

	if(ret)
	{
		std::istringstream f(result);
		std::string line;
		std::stringstream topoStr;
		while(std::getline(f, line))
		{
			if(!line.empty())
			{
				size_t pos = 0;
				if(line.at(0) == '#'
						&& (pos = line.find("TMH:")) != std::string::npos)
				{
					line = line.c_str() + pos + 4;
					Utils::replaceStringInPlace(line, " ", "");
					std::vector<std::string> vec;
					Utils::split(line, '-', vec);
					if(vec.size() == 2)
					{
						int beg = atoi(vec[0].c_str());
						int end = atoi(vec[1].c_str());

						context.addMethodHit(CCTOPLIB_METHOD_MEMBRAIN, beg, end, LOCALIZATION_MEMBRANE);
					}
				}
			}
		}
	}
	return ret;
}

inline
char changeChar(char t)
{
	switch (t)
	{
	case 'e':
	case 'E':
	case 'j':
	case 'J':
	case 'i':
		t = 'I';
		break;
	case 'g':
		t = '#';
		break;
	case 'l':
	case 'o':
		t = 'O';
		break;
	case 'r':
	case 'R':
		t = 'L';
		break;
	default:
		break;
	}

	return t;
}

void CCTOP::Core::External::MethodParser::parseTOPCON(const std::string& result, Core::SequenceContext& context, const std::string& type) const
{
	std::cerr << "type:" << type << "  " << result << std::endl;
	if(!result.empty())
	{
		std::istringstream f(result);
		std::string line;
		std::stringstream topoStr;
		while(std::getline(f, line))
		{
			if(!line.empty() && line.at(0) != '>')
			{
				topoStr << line;
			}
		}

		line = topoStr.str();
		const char* temp = line.c_str();

		int currPos = 0;
		int peekPos = 0;
		int lastStartdPos = 0;
		int length = line.length();
		while(currPos < length)
		{
			peekPos = currPos+1;
			if(peekPos == length ||
					changeChar(temp[peekPos]) != changeChar(temp[currPos]))
			{
				Localization loc;
				char l = changeChar(temp[currPos]);

				loc = parseCharLocalization(l);

				context.addMethodHit(type, lastStartdPos+1, currPos+1, loc);

				lastStartdPos = peekPos;
			}
			currPos++;
		}
	}
}

void CCTOP::Core::External::MethodParser::parseScampiMsa(const std::string& result, Core::SequenceContext& context) const
{
	parseTOPCON(result, context, CCTOPLIB_METHOD_SCAMPIMSA);
}

void CCTOP::Core::External::MethodParser::parsePro(const std::string& result, Core::SequenceContext& context) const
{
	parseTOPCON(result, context, CCTOPLIB_METHOD_PRO);
}

void CCTOP::Core::External::MethodParser::parseProDiv(const std::string& result, Core::SequenceContext& context) const
{
	parseTOPCON(result, context, CCTOPLIB_METHOD_PRODIV);
}

void CCTOP::Core::External::MethodParser::parseOctopus(const std::string& result, Core::SequenceContext& context) const
{
	parseTOPCON(result, context, CCTOPLIB_METHOD_OCTOPUS);
}

void CCTOP::Core::External::MethodParser::parseScampi(const std::string& result, Core::SequenceContext& context) const
{
	parseTOPCON(result, context, CCTOPLIB_METHOD_SCAMPI);
}

bool CCTOP::Core::External::MethodParser::parseMemsatGlob(const std::string& result, Core::SequenceContext& context) const
{
	bool ret = false;
	std::istringstream f(result);
	std::string line;
	std::stringstream topoStr;
	while(std::getline(f, line) && !(ret = line.find(MEMSAT_GLOB_STR) != std::string::npos))
	{}

	return ret;
}

void CCTOP::Core::External::MethodParser::parseMemsat(const std::string& result, Core::SequenceContext& context) const
{
	std::istringstream f(result);
	std::string line;
	std::stringstream topoStr;

	std::vector< std::string > vec;
	bool nterminalOut = false;
	//TopologyEntry tempSig;
	std::vector<TopologyEntry> topology;
	while(std::getline(f, line))
	{
		if(line.find(MEMSAT_SIGNAL_PEPTIDE) != std::string::npos)
		{
//			const char* c = line.c_str()+MEMSAT_SIGNAL_PEPTIDE_LEN;
//			while(*c == '\t') c++;
//
//			vec.clear();
//			Utils::split(line, '-', vec);
//			if(vec.size() == 2)
//			{
//				tempSig.beg = atoi(vec[0].c_str());
//				tempSig.end = atoi(vec[1].c_str());
//				tempSig.loc = LOCALIZATION_SIGNAL;
//			}

		}else
			if(line.find(MEMSAT_TOPOLOGY) != std::string::npos)
			{
				const char* c = line.c_str()+MEMSAT_TOPOLOGY_LEN;
				while(*c == '\t') c++;
				line = c;

				vec.clear();
				Utils::split(line, ',', vec);

				std::vector< std::string > tempVec;
				std::vector< std::string >::const_iterator iter = vec.begin();
				while(iter != vec.end())
				{
					tempVec.clear();
					Utils::split(*iter, '-', tempVec);
					if(tempVec.size() == 2)
					{
						TopologyEntry entry;
						entry.beg = atoi(tempVec[0].c_str());
						entry.end = atoi(tempVec[1].c_str());
						entry.loc = LOCALIZATION_MEMBRANE;
						topology.push_back(entry);
					}

					iter++;
				}
			}else
				if(line.find(MEMSAT_RE_ENTRANT_HELICES) != std::string::npos)
				{
					const char* c = line.c_str()+MEMSAT_RE_ENTRANT_HELICES_LEN;
					while(*c == '\t') c++;
					line = c;

					vec.clear();
					Utils::split(line, ',', vec);

					std::vector< std::string > tempVec;
					std::vector< std::string >::const_iterator iter = vec.begin();
					while(iter != vec.end())
					{
						tempVec.clear();
						Utils::split(*iter, '-', tempVec);
						if(tempVec.size() == 2)
						{
							TopologyEntry entry;
							entry.beg = atoi(tempVec[0].c_str());
							entry.end = atoi(tempVec[1].c_str());
							entry.loc = LOCALIZATION_MEMBLOOP;
							topology.push_back(entry);
						}

						iter++;
					}

				}else
					if(line.find(MEMSAT_N_TERMINAL) != std::string::npos)
					{
						//line = line.c_str()+MEMSAT_N_TERMINAL_LEN;
						nterminalOut = line.find(MEMSAT_OUT) != std::string::npos;
					}
	}


	if(topology.size())
	{
		std::sort(topology.begin(), topology.end(), gTopoSorter);
		std::vector< TopologyEntry >::const_iterator iter = topology.begin();
		Localization currIntLoc = nterminalOut ? LOCALIZATION_OUTSIDE : LOCALIZATION_INSIDE;

		int lastEnd = 0;
		while(topology.end() != iter)
		{
			const TopologyEntry& temp = *iter;

			if(temp.beg > 1)
			{
				context.addMethodHit(CCTOPLIB_METHOD_MEMSAT, lastEnd+1, temp.beg-1, currIntLoc);
			}

			context.addMethodHit(CCTOPLIB_METHOD_MEMSAT, temp.beg, temp.end, temp.loc);

			if(temp.loc == LOCALIZATION_MEMBRANE)
			{
				if(currIntLoc == LOCALIZATION_INSIDE)
					currIntLoc = LOCALIZATION_OUTSIDE;
				else
					currIntLoc = LOCALIZATION_INSIDE;
			}

			lastEnd = temp.end;
			iter++;
		}

		if(lastEnd < (int)context.getSignalReducedSequence().length())
			context.addMethodHit(CCTOPLIB_METHOD_MEMSAT, lastEnd+1, context.getSignalReducedSequence().length(), currIntLoc);
	}
}


void CCTOP::Core::External::MethodParser::parseTopDom(const std::string& result, Core::SequenceContext& context, const std::string& resultURL) const
{
	if(!result.empty())
	{
		rapidxml::xml_document<> doc;
		std::stringstream theFile (result.c_str());
		std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
		buffer.push_back('\0');
		doc.parse<0>(&buffer[0]);

		rapidxml::xml_node<>* htmlNode = doc.first_node(XML_ELEMENT_HTML);
		if(htmlNode)
		{
			rapidxml::xml_node<>* bodyNode = htmlNode->first_node(XML_ELEMENT_BODY);
			if(bodyNode)
			{
				rapidxml::xml_node<>* containerNode = bodyNode->first_node(XML_ELEMENT_DIV);
				rapidxml::xml_attribute<>* attr;
				while(containerNode && (attr = containerNode->first_attribute(XML_ATTRIBUTE_ID))
						&& strcmp(attr->value(), "container"))
				{
					containerNode = containerNode->next_sibling(XML_ELEMENT_DIV);
				}

				if(containerNode)
				{
					rapidxml::xml_node<>* mainNode = containerNode->first_node(XML_ELEMENT_DIV);
					while(mainNode && (attr = mainNode->first_attribute(XML_ATTRIBUTE_ID))
							&& strcmp(attr->value(), "main"))
					{
						mainNode = mainNode->next_sibling(XML_ELEMENT_DIV);
					}

					if(mainNode)
					{
						rapidxml::xml_node<>* fieldSetNode = mainNode->first_node(XML_ELEMENT_FIELDSET);
						if(fieldSetNode && strcmp(fieldSetNode->value(), "No any conserved domains or motifs have been found on query sequence."))
						{
							rapidxml::xml_node<>* centerNode = fieldSetNode->first_node(XML_ELEMENT_CENTER);
							if(centerNode) centerNode = centerNode->next_sibling(XML_ELEMENT_CENTER);
							rapidxml::xml_node<>* tableNode = centerNode ? centerNode->first_node(XML_ELEMENT_TABLE) : NULL;
							rapidxml::xml_node<>* trNode = tableNode ? tableNode->first_node(XML_ELEMENT_TR) : NULL;
							rapidxml::xml_attribute<>* attr = NULL;
							while(trNode)
							{
								if((attr = trNode->first_attribute(XML_ATTRIBUTE_CLASS))
										&& strcmp(attr->value(), "lh"))
								{
									std::string topdomId;
									rapidxml::xml_node<>* tdNode = trNode->first_node(XML_ELEMENT_TD);
									int counter = 0;
									TopologyEntry tp;
									while(tdNode)
									{
										if(counter<2)
										{
											if(!counter)
											{
												rapidxml::xml_node<>* aNode = tdNode->first_node(XML_ELEMENT_A);
												if(aNode)
													topdomId = aNode->value();
											}else
											{
												tp.beg = atoi(tdNode->value());
											}
										}else
										{
											if(counter == 2)
											{
												tp.end = atoi(tdNode->value());
											}else
											{
												rapidxml::xml_node<>* divNode = tdNode->first_node(XML_ELEMENT_DIV);
												if(divNode)
													tp.loc = Core::parseLocalization(divNode->value());
											}
										}

										tdNode = tdNode->next_sibling(XML_ELEMENT_TD);
										counter++;
									}

									if(parseTopDomSub(resultURL, topdomId))
									{
										context.addTOPDOMHit(topdomId, tp.beg, tp.end, tp.loc);
									}

								}
								trNode = trNode->next_sibling(XML_ELEMENT_TR);
							}
						}
					}
				}
			}
		}
	}
}

bool CCTOP::Core::External::MethodParser::parseTopDomSub(const std::string& resultURL, const std::string& topdomId) const
{
	bool ret = false;
	std::string cmd(resultURL);
	Utils::replaceStringInPlace(cmd, "$ITEM$", topdomId);
	std::string result = Utils::executeCommand(cmd.c_str());

	/*if(result.find("Home</a></li>") == std::string::npos)
		Utils::replaceStringInPlace(result, "<li ><a href=\"?m=home\">Home</a>", "<li ><a href=\"?m=home\">Home</a></li>");*/


	rapidxml::xml_document<> doc;
	std::stringstream theFile (result.c_str());
	std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
	buffer.push_back('\0');
	doc.parse<0>(&buffer[0]);

	rapidxml::xml_node<>* htmlNode = doc.first_node(XML_ELEMENT_HTML);
	if(htmlNode)
	{
		rapidxml::xml_node<>* bodyNode = htmlNode->first_node(XML_ELEMENT_BODY);
		if(bodyNode)
		{
			rapidxml::xml_node<>* containerNode = bodyNode->first_node(XML_ELEMENT_DIV);
			rapidxml::xml_attribute<>* attr;
			while(containerNode && (attr = containerNode->first_attribute(XML_ATTRIBUTE_ID))
					&& strcmp(attr->value(), "container"))
			{
				containerNode = containerNode->next_sibling(XML_ELEMENT_DIV);
			}

			if(containerNode)
			{
				rapidxml::xml_node<>* mainNode = containerNode->first_node(XML_ELEMENT_DIV);
				while(mainNode && (attr = mainNode->first_attribute(XML_ATTRIBUTE_ID))
						&& strcmp(attr->value(), "main"))
				{
					mainNode = mainNode->next_sibling(XML_ELEMENT_DIV);
				}

				if(mainNode)
				{
					rapidxml::xml_node<>* fieldSetNode = mainNode->first_node(XML_ELEMENT_DIV);
					while(fieldSetNode && (attr = fieldSetNode->first_attribute(XML_ATTRIBUTE_ID))
							&& strcmp(attr->value(), "tabbedfieldset"))
					{
						fieldSetNode = fieldSetNode->next_sibling(XML_ELEMENT_DIV);
					}

					if(fieldSetNode)
					{
						rapidxml::xml_node<>* tabbNode = fieldSetNode->first_node(XML_ELEMENT_DIV);
						while(tabbNode && (attr = tabbNode->first_attribute(XML_ATTRIBUTE_ID))
								&& strcmp(attr->value(), "tabb"))
						{
							tabbNode = tabbNode->next_sibling(XML_ELEMENT_DIV);
						}

						if(tabbNode)
						{
							rapidxml::xml_node<>* dlNode = tabbNode->first_node(XML_ELEMENT_DL);
							if(dlNode)
							{
								rapidxml::xml_node<>* dtNode = dlNode->first_node(XML_ELEMENT_DT);
								rapidxml::xml_node<>* ddNode = dlNode->first_node(XML_ELEMENT_DD);

								while(dtNode && ddNode && dtNode->value()
										&& strcmp(dtNode->value(), "Supported"))
								{
									dtNode = dtNode->next_sibling(XML_ELEMENT_DT);
									ddNode = ddNode->next_sibling(XML_ELEMENT_DD);
								}

								if(dtNode && ddNode)
								{
									std::vector<std::string> vec;
									Utils::splitSafe(ddNode->value(), '/', vec);

									if(vec.size() == 2)
									{
										int first = atoi(vec[0].c_str());
										int sec = atoi(vec[1].c_str());
										ret = (!sec && first > 15) || (sec && ((double)first/(double)sec > 15.0));
									}
								}
							}
						}
					}
				}
			}
		}
	}

	return ret;
}
