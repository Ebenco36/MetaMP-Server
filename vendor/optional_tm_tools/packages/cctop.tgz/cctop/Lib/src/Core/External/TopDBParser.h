/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * TopDBParser.h
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_EXTERNAL_TOPDBPARSER_H_
#define CCTOP_CORE_EXTERNAL_TOPDBPARSER_H_

#include "../MethodContext.h"

#include <string>
#include <vector>

#include "../../Utils/Xml/rapidxml.hpp"


namespace CCTOP { namespace Core { namespace External
{

class TopDBParser
{
protected:
	static const char*	XML_ELEMENT_TOPDBS;
	static const char*	XML_ELEMENT_TOPDB;
	static const char*	XML_ELEMENT_NAME;
	static const char*	XML_ELEMENT_CROSSREF;
	static const char*	XML_ELEMENT_UNIPROT;
	static const char*	XML_ELEMENT_AC;
	static const char*	XML_ELEMENT_PDB;
	static const char*	XML_ELEMENT_SIDEDEFINITION;
	static const char*	XML_ELEMENT_CHAINS;
	static const char*	XML_ELEMENT_CHAIN;
	static const char*	XML_ELEMENT_FRAGMENT;
	static const char*	XML_ELEMENT_SEQUENCE;
	static const char*	XML_ELEMENT_CLEAVABLE;
	static const char*	XML_ELEMENT_SEQ;
	static const char*	XML_ELEMENT_TOPOLOGY;
	static const char*	XML_ELEMENT_REGIONS;
	static const char*	XML_ELEMENT_REGION;
	static const char*	XML_ELEMENT_EXPERIMENTS;
	static const char*	XML_ELEMENT_EXP;
	static const char*	XML_ELEMENT_TYPE;
	static const char*	XML_ELEMENT_SUBTYPE;
	static const char*	XML_ELEMENT_PDBREF;
	static const char*	XML_ELEMENT_EXPDATA;
	static const char*	XML_ELEMENT_PROBLEM;

	static const char*	XML_ATTRIBUTE_ID;
	static const char*	XML_ATTRIBUTE_SIDE1;
	static const char*	XML_ATTRIBUTE_BEG;
	static const char*	XML_ATTRIBUTE_BEGIN;
	static const char*	XML_ATTRIBUTE_END;
	static const char*	XML_ATTRIBUTE_TYPE;
	static const char*	XML_ATTRIBUTE_LOC;
	static const char*	XML_ATTRIBUTE_MIN;
	static const char*	XML_ATTRIBUTE_MAX;
	static const char*	XML_ATTRIBUTE_REF;
	static const char*	XML_ATTRIBUTE_REF2;


	static const char* XML_VALUE_PDBMTM;
	static const char* XML_VALUE_STRUCTURE;
	static const char* XML_VALUE_YES;

	bool parseTOPDB(rapidxml::xml_node<>* topDBNode, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const;

public:
	TopDBParser();
	TopDBParser(const TopDBParser& copy);
	~TopDBParser();
	TopDBParser& operator=(const TopDBParser& copy);

	bool parseGroupFile(const std::string& xmlFile, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const;
	bool parseFile(const std::string& xmlFile, Core::MethodContext& methodContext, bool ignoreMinMax, bool duplicationEnabled) const;
};

}}}




#endif /* CCTOP_CORE_EXTERNAL_TOPDBPARSER_H_ */
