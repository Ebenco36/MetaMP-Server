/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * BlastParser.cpp
 *
 *  Created on: 2014.07.08.
 *      Author: "Istvan Remenyi"
 */

#include "BlastParser.h"

#include "../../Utils/Xml/rapidxml.hpp"
#include "../../Utils/StringUtils.h"
#include "../../Utils/CalcUtils.h"
#include "../MethodContext.h"

#include <algorithm>
#include <sstream>
#include <iostream>

const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_BLASTOUTPUT				= "BlastOutput";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_BLASTOUTPUT_ITERATIONS	= "BlastOutput_iterations";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_ITERATION				= "Iteration";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_ITERATION_HITS			= "Iteration_hits";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HIT						= "Hit";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HIT_DEF					= "Hit_def";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HIT_LEN					= "Hit_len";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HIT_HSPS				= "Hit_hsps";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP						= "Hsp";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_QSEQ				= "Hsp_qseq";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_HSEQ				= "Hsp_hseq";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_MIDLINE				= "Hsp_midline";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_HIT_FROM			= "Hsp_hit-from";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_HIT_TO				= "Hsp_hit-to";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_QUERY_FROM			= "Hsp_query-from";
const char*	CCTOP::Core::External::BlastParser::XML_ELEMENT_HSP_QUERY_TO			= "Hsp_query-to";


const char*	CCTOP::Core::External::BlastParser::XML_VALUE_HIT_DEF_DELIMITER			= "|";

static const double HSEQRATE_ACCEPT_MIN		= 0.8;
static const double HSEQRATE_ACCEPT_MAX 	= 1.01;
static const double MIDLINE_ACCEPT_LIMIT 	= 0.6;

CCTOP::Core::External::BlastParser::BlastParser()
{}

CCTOP::Core::External::BlastParser::BlastParser(const BlastParser& copy)
{}

CCTOP::Core::External::BlastParser::~BlastParser()
{}

void CCTOP::Core::External::BlastParser::updatePositions(int beg, int end, int hsp_query_from, int hsp_query_to, int delta, const std::vector<std::string>& elems, int& newBeg, int& newEnd) const
{
	//1.exp contains querypart
	if(beg <= hsp_query_from
			&& end >= hsp_query_to)
	{
		newEnd += delta;
	}else
		//2.overlap right
		if(beg <= hsp_query_from
				&& end <= hsp_query_to
				&& end >= hsp_query_from)
		{
			int begDelta = 0;
			int currStrIndex = 0;
			std::vector<std::string>::const_iterator strIter = elems.begin();
			while(strIter != elems.end())
			{
				if(strIter->length() == 0)
				{
					if(beg >= (hsp_query_from + currStrIndex))
					{
						begDelta++;
					}
					currStrIndex++;
				}else
				{
					currStrIndex += strIter->length();
				}
				strIter++;
			}
			newBeg += begDelta;
			newEnd += delta;
		}else
			//3.overlap left
			if(beg >= hsp_query_from
					&& end >= hsp_query_to
					&& beg <= hsp_query_to)
			{
				int endDelta = 0;
				int currStrIndex = 0;
				std::vector<std::string>::const_iterator strIter = elems.begin();
				while(strIter != elems.end())
				{
					if(strIter->length() == 0)
					{
						if(end <= (hsp_query_from + currStrIndex))
						{
							endDelta++;
						}
						currStrIndex++;
					}else
					{
						currStrIndex += strIter->length();
					}
					strIter++;
				}
				newEnd += endDelta;
			}else
				//4.querypart contains exp
				if(beg >= hsp_query_from
						&& end <= hsp_query_to)
				{
					int begDelta = 0;
					int endDelta = 0;
					int currStrIndex = 0;
					std::vector<std::string>::const_iterator strIter = elems.begin();
					while(strIter != elems.end())
					{
						if(strIter->length() == 0)
						{
							if(beg > (hsp_query_from + currStrIndex))
							{
								begDelta++;
							}
							if(end <= (hsp_query_from + currStrIndex))
							{
								endDelta++;
							}
							currStrIndex++;
						}else
						{
							currStrIndex += strIter->length();
						}
						strIter++;
					}
					newBeg += begDelta;
					newEnd += endDelta;

				}else
					//5.querypart before exp
					if(hsp_query_to <= beg)
					{
						newBeg += delta;
						newEnd += delta;
					}
}

CCTOP::Core::External::BlastParser& CCTOP::Core::External::BlastParser::operator=(const BlastParser& copy)
{return *this;}

bool CCTOP::Core::External::BlastParser::parseUniProtResults(const std::string& blastXML, SequenceContext& seqContext, int blastLimit) const
{
	bool ret = false;
	rapidxml::xml_document<> doc;
	doc.parse<0>(const_cast<char*>(blastXML.c_str()));

	rapidxml::xml_node<>* blastOutputNode = doc.first_node(XML_ELEMENT_BLASTOUTPUT);
	if(blastOutputNode)
	{
		rapidxml::xml_node<>* blastOutputIterationsNode = blastOutputNode->first_node(XML_ELEMENT_BLASTOUTPUT_ITERATIONS);
		if(blastOutputIterationsNode)
		{
			for(rapidxml::xml_node<>* iterationItem = blastOutputIterationsNode->first_node(XML_ELEMENT_ITERATION) ; !ret && iterationItem; iterationItem = iterationItem->next_sibling(XML_ELEMENT_ITERATION))
			{
				rapidxml::xml_node<>* iterationHitsNode = iterationItem->first_node(XML_ELEMENT_ITERATION_HITS);
				if(iterationHitsNode)
				{
					//Just the first result!
					rapidxml::xml_node<>* hitItem = iterationHitsNode->first_node(XML_ELEMENT_HIT);
					if(hitItem)
					{
						std::string hitDef;
						rapidxml::xml_node<>* hitDefNode = hitItem->first_node(XML_ELEMENT_HIT_DEF);
						if(hitDefNode)
							hitDef = hitDefNode->value();

						rapidxml::xml_node<>* hitHspsNOde = hitItem->first_node(XML_ELEMENT_HIT_HSPS);
						for(rapidxml::xml_node<>* hspNode = hitHspsNOde->first_node(XML_ELEMENT_HSP) ; hspNode; hspNode = hspNode->next_sibling(XML_ELEMENT_HSP))
						{
							std::string hspHseq;
							//std::string hspQseq;
							rapidxml::xml_node<>* hspHseqNode = hspNode->first_node(XML_ELEMENT_HSP_HSEQ);
							if(hspHseqNode)
								hspHseq = hspHseqNode->value();
							/*rapidxml::xml_node<>* hspQseqNode = hspNode->first_node(XML_ELEMENT_HSP_QSEQ);
							if(hspQseqNode)
								hspQseq = hspQseqNode->value();*/

							std::cerr << "HSPHSEQ: " << hspHseq << std::endl;
							std::cerr << "SEQ    : " << seqContext.getSequence() << std::endl;
							int length = std::min(seqContext.getSequence().length(), hspHseq.length());
							int eqCount = 0;
							for(int l=0;l<length;l++)
							{
								if(seqContext.getSequence()[l] == hspHseq[l])
								{
									eqCount++;
								}
							}

							//GET HIT
							/*int comp = 0;
							if(!(comp = strcmp(seqContext.getSequence().c_str(), hspHseq.c_str())))*/
							if(abs((int)seqContext.getSequence().length() - eqCount) < blastLimit)
							{
								ret = true;
								std::vector<std::string> results;
								Utils::split(hitDef, *XML_VALUE_HIT_DEF_DELIMITER, results);
								seqContext.setUniprotBlastAc(results.at(1));
							}
						}
					}
				}
			}
		}
	}

	return ret;
}

inline
bool isSegmentEmpty(const char* tempCCTOPStr, int beg, int end)
{
	bool ret = tempCCTOPStr && beg > 0 && end >= beg;

	int index = 0;
	while(ret && (beg+index) <= end)
	{
		ret &= tempCCTOPStr[beg-1+index] == '-';
		index++;
	}

	return ret;
}

bool CCTOP::Core::External::BlastParser::mergeTopDbResults(const std::string& blastXML, SequenceContext& seqContext,
		const MethodContext& methodContext) const
{
	bool ret = true;
	rapidxml::xml_document<> doc;
	doc.parse<0>(const_cast<char*>(blastXML.c_str()));

	rapidxml::xml_node<>* blastOutputNode = doc.first_node(XML_ELEMENT_BLASTOUTPUT);
	if(blastOutputNode)
	{
		rapidxml::xml_node<>* blastOutputIterationsNode = blastOutputNode->first_node(XML_ELEMENT_BLASTOUTPUT_ITERATIONS);
		if(blastOutputIterationsNode)
		{
			for(rapidxml::xml_node<>* iterationItem = blastOutputIterationsNode->first_node(XML_ELEMENT_ITERATION) ; iterationItem; iterationItem = iterationItem->next_sibling(XML_ELEMENT_ITERATION))
			{
				rapidxml::xml_node<>* iterationHitsNode = iterationItem->first_node(XML_ELEMENT_ITERATION_HITS);
				if(iterationHitsNode)
				{
					for(rapidxml::xml_node<>* hitItem = iterationHitsNode->first_node(XML_ELEMENT_HIT) ; hitItem; hitItem = hitItem->next_sibling(XML_ELEMENT_HIT))
					{
						std::string hitDef;
						rapidxml::xml_node<>* hitDefNode = hitItem->first_node(XML_ELEMENT_HIT_DEF);
						if(hitDefNode)
							hitDef = hitDefNode->value();

						std::cout << "TopDB hitdef: " << hitDef << std::endl;
						rapidxml::xml_node<>* hitHspsNOde = hitItem->first_node(XML_ELEMENT_HIT_HSPS);
						if(hitHspsNOde)
						{
							int sumHspHSeq= 0;
							bool midlineCheck = true;

							//PreCheck -> 2 conditions
							for(rapidxml::xml_node<>* hspNode = hitHspsNOde->first_node(XML_ELEMENT_HSP) ; hspNode; hspNode = hspNode->next_sibling(XML_ELEMENT_HSP))
							{
								std::string hspHseq;
								rapidxml::xml_node<>* hspHseqNode = hspNode->first_node(XML_ELEMENT_HSP_HSEQ);
								if(hspHseqNode)
									hspHseq = hspHseqNode->value();

								std::string hspMidline;
								rapidxml::xml_node<>* hspMidlineNode = hspNode->first_node(XML_ELEMENT_HSP_MIDLINE);
								if(hspMidlineNode)
									hspMidline = hspMidlineNode->value();

								sumHspHSeq += hspHseq.length();

								//2.condition
								int midlineSpCount = std::count(hspMidline.begin(), hspMidline.end(), ' ');
								midlineCheck &= ((double)midlineSpCount/hspMidline.length()) <= MIDLINE_ACCEPT_LIMIT;

								std::cout << "TODBMidline: " << midlineSpCount << " / " << hspMidline.length() << " :: " << midlineCheck << std::endl;
							}

							//1.condition
							if(midlineCheck)
							{
								double hseqRate = (double)sumHspHSeq / (double)seqContext.getSequence().length();
								std::cout << "hseqRate: " << sumHspHSeq << " / " << seqContext.getSequence().length() << " = " << hseqRate << std::endl;

								if(hseqRate > HSEQRATE_ACCEPT_MIN && hseqRate < HSEQRATE_ACCEPT_MAX)
								{
									//Check the Membrane Regions
									bool everyMRegionCovered = true;
									TopDBEntry* topdbEntry = methodContext.getTopDBEntry(hitDef);
									if(topdbEntry)
									{
										const std::vector<TopologyEntry>& topoEntries = topdbEntry->getTopologyEntries();
										std::vector<TopologyEntry>::const_iterator iter = topoEntries.begin();
										while(everyMRegionCovered && iter != topoEntries.end())
										{
											//Check the Membrane Region Coverage
											if(iter->loc == LOCALIZATION_MEMBRANE)
											{
												bool covered = false;
												for(rapidxml::xml_node<>* hspNode = hitHspsNOde->first_node(XML_ELEMENT_HSP) ; !covered && hspNode; hspNode = hspNode->next_sibling(XML_ELEMENT_HSP))
												{
													int hsp_hit_from = 0;
													int hsp_hit_to = 0;

													rapidxml::xml_node<>* hspHitFromNode = hspNode->first_node(XML_ELEMENT_HSP_HIT_FROM);
													if(hspHitFromNode)
														hsp_hit_from = atoi(hspHitFromNode->value());
													rapidxml::xml_node<>* hspHitToNode = hspNode->first_node(XML_ELEMENT_HSP_HIT_TO);
													if(hspHitToNode)
														hsp_hit_to = atoi(hspHitToNode->value());

													covered = iter->beg >= hsp_hit_from && iter->end <= hsp_hit_to;
												}
												everyMRegionCovered &= covered;
											}
											iter++;
										}
										//do the important job :) - fill the alignments
										if(everyMRegionCovered)
										{
											std::stringstream crossRefSeq;
											std::stringstream cctopSeq;

											bool hasSignalRegion = false;
											{
												std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topdbEntry->getTopologyEntries().begin();
												while(topoIter != topdbEntry->getTopologyEntries().end())
												{
													if(topoIter->loc == LOCALIZATION_SIGNAL)
													{
														hasSignalRegion = true;
													}
													topoIter++;
												}
											}

											std::vector<CCTOP::Core::TopologyEntry> topologiesCopy = topdbEntry->getTopologyEntries();
											std::vector<CCTOP::Core::ExperimentEntry> experimentsCopy = topdbEntry->getExperimentEntries();

											{
											std::cerr << "Copy Topology:" << std::endl;
											std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topologiesCopy.begin();
											while(topoIter != topologiesCopy.end())
											{
												std::cerr << topoIter->beg << "-" << topoIter->end << ":" << Core::localizationToChar(topoIter->loc) << std::endl;

												topoIter++;
											}
											std::cerr << "Copy Experiments:" << std::endl;
											std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experimentsCopy.begin();
											while(expIter != experimentsCopy.end())
											{
												std::cerr << expIter->beg << "-" << expIter->end << ":" << Core::localizationToChar(expIter->loc) << std::endl;

												expIter++;
											}
											}

											std::vector<CCTOP::Core::TopologyEntry> topos;
											std::vector<CCTOP::Core::ExperimentEntry> exps;
											int lastEnd = 1;
											for(rapidxml::xml_node<>* hspNode = hitHspsNOde->first_node(XML_ELEMENT_HSP);hspNode; hspNode = hspNode->next_sibling(XML_ELEMENT_HSP))
											{
												int hsp_query_from = 0;
												int hsp_query_to = 0;
												int hsp_hit_from = 0;
												int hsp_hit_to = 0;
												std::string hspHseq;
												std::string hspQseq;

												rapidxml::xml_node<>* hspQueryFromNode = hspNode->first_node(XML_ELEMENT_HSP_QUERY_FROM);
												if(hspQueryFromNode)
													hsp_query_from = atoi(hspQueryFromNode->value());
												rapidxml::xml_node<>* hspQueryToNode = hspNode->first_node(XML_ELEMENT_HSP_QUERY_TO);
												if(hspQueryToNode)
													hsp_query_to = atoi(hspQueryToNode->value());

												rapidxml::xml_node<>* hsphitFromNode = hspNode->first_node(XML_ELEMENT_HSP_HIT_FROM);
												if(hsphitFromNode)
													hsp_hit_from = atoi(hsphitFromNode->value());
												rapidxml::xml_node<>* hspHitToNode = hspNode->first_node(XML_ELEMENT_HSP_HIT_TO);
												if(hspHitToNode)
													hsp_hit_to = atoi(hspHitToNode->value());

												rapidxml::xml_node<>* hspHseqNode = hspNode->first_node(XML_ELEMENT_HSP_HSEQ);
												if(hspHseqNode)
													hspHseq = hspHseqNode->value();
												rapidxml::xml_node<>* hspQseqNode = hspNode->first_node(XML_ELEMENT_HSP_QSEQ);
												if(hspQseqNode)
													hspQseq = hspQseqNode->value();

												if(hspNode == hitHspsNOde->first_node(XML_ELEMENT_HSP))
												{
													if(hsp_query_from > 1)
													{
														for(int i=0; i< (hsp_query_from-1); i++)
															crossRefSeq << "-";
														cctopSeq << seqContext.getSequence().substr(0, hsp_query_from - 1);
													}
												}else
												{
													if(lastEnd != hsp_query_from+1)
													{
														for(int i=lastEnd-1; i< (hsp_query_from-1); i++)
															crossRefSeq << "-";
														cctopSeq << seqContext.getSequence().substr(lastEnd-1, lastEnd - hsp_query_from - 1);
													}
												}

												crossRefSeq << hspHseq;
												cctopSeq << hspQseq;

												lastEnd = hsp_query_to;


												std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experimentsCopy.begin();
												while(expIter != experimentsCopy.end())
												{
													if(expIter->beg <= hsp_hit_to
															&& expIter->end >= hsp_hit_from)
													{
														int realHitIndex = hsp_hit_from-1;
														int realQueryIndex = hsp_query_from-1;

														int qBeg = -1;
														int qEnd = -1;
														/*int seqBeg = -1;
														int seqEnd = -1;*/

														for(int seqIndex=0;seqIndex < (int)hspHseq.length();seqIndex++)
														{
															if(hspQseq[seqIndex] != '-')
																realQueryIndex++;

															if(hspHseq[seqIndex] != '-')
															{
																realHitIndex++;
																if(expIter->beg == realHitIndex)
																{
																	qBeg = realQueryIndex;
//																	seqBeg = seqIndex;
																}
																if(expIter->end == realHitIndex)
																{
																	qEnd = realQueryIndex;
//																	seqEnd = seqIndex;
																}
															}
														}


														if(qBeg == -1)
															qBeg = hsp_query_from;
														if(qEnd == -1)
															qEnd = realQueryIndex;

														{
															CCTOP::Core::ExperimentEntry newEntry = *expIter;
															newEntry.beg = qBeg;
															newEntry.end = qEnd;
															newEntry.chainIds = expIter->chainIds;
															exps.push_back(newEntry);
														}
													}
													expIter++;
												}

												std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topologiesCopy.begin();
												while(topoIter != topologiesCopy.end())
												{
													if(topoIter->beg <= hsp_hit_to
															&& topoIter->end >= hsp_hit_from)
													{
														int realHitIndex = hsp_hit_from-1;
														int realQueryIndex = hsp_query_from-1;

														int qBeg = -1;
														int qEnd = -1;
														/*int seqBeg = -1;
														int seqEnd = -1;*/

														for(int seqIndex=0;seqIndex < (int)hspHseq.length();seqIndex++)
														{
															if(hspQseq[seqIndex] != '-')
																realQueryIndex++;

															if(hspHseq[seqIndex] != '-')
															{
																realHitIndex++;
																if(topoIter->beg == realHitIndex)
																{
																	qBeg = realQueryIndex;
																	if(hspQseq[seqIndex] == '-')
																		qBeg++;
																	//seqBeg = seqIndex;
																}
																if(topoIter->end == realHitIndex)
																{
																	qEnd = realQueryIndex;
																	//seqEnd = seqIndex;
																}
															}

															if(qEnd == -1 && seqIndex == (int)hspHseq.length()-1)
															{
																qEnd = realQueryIndex;
															}
														}

														if(qBeg == -1)
															qBeg = hsp_query_from;
														if(qEnd == -1)
															qEnd = realQueryIndex;
														{
															CCTOP::Core::TopologyEntry newEntry = *topoIter;
															newEntry.beg = qBeg;
															newEntry.end = qEnd;
															topos.push_back(newEntry);
														}
													}
													topoIter++;
												}
											}
											experimentsCopy = exps;
											topologiesCopy = topos;

											if(lastEnd < (int)seqContext.getSequence().length()) //note: position has +1, so '<=' -> '<'!!
											{
												int limit = seqContext.getSequence().length() + 1 - lastEnd;
												for(int i=0; i< limit; i++)
													crossRefSeq << "-";
												cctopSeq << seqContext.getSequence().substr(lastEnd - 1);
											}

											//Check for Signal in modified Topology
											int signalBeg = -1;
											int signalEnd = -1;
											std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topologiesCopy.begin();
											while(topoIter != topologiesCopy.end())
											{
												if(topoIter->loc == LOCALIZATION_SIGNAL
														&& signalEnd < topoIter->end)
												{
													signalBeg = topoIter->beg;
													signalEnd = topoIter->end;
												}
												topoIter++;
											}

											{
											std::cerr << "Updated Topology:" << std::endl;
											std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topologiesCopy.begin();
											while(topoIter != topologiesCopy.end())
											{
												std::cerr << topoIter->beg << "-" << topoIter->end << ":" << Core::localizationToChar(topoIter->loc) << std::endl;

												topoIter++;
											}
											std::cerr << "Updated Experiments:" << std::endl;
											std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experimentsCopy.begin();
											while(expIter != experimentsCopy.end())
											{
												std::cerr << expIter->beg << "-" << expIter->end << ":" << Core::localizationToChar(expIter->loc) << std::endl;

												expIter++;
											}
											}

											//remove transit region
											std::stringstream reducedSeq;
											{
												std::string cctop = seqContext.getSequence();
												int lastTrEnd = -1;
												std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = topologiesCopy.begin();
												while(topoIter != topologiesCopy.end())
												{
													if(topoIter->loc == LOCALIZATION_TRANSIT)
													{
														if(lastTrEnd == -1)
														{
															reducedSeq << cctop.substr(0, topoIter->beg-1);
														}else
														{
															reducedSeq << cctop.substr(lastTrEnd, lastTrEnd - topoIter->beg - 1);
														}

														lastTrEnd = topoIter->end;
													}
													topoIter++;
												}
												if(lastTrEnd != -1)
												{
													reducedSeq << cctop.substr(lastTrEnd);
												}else
												{
													reducedSeq << cctop;
												}
											}

											seqContext.addTopDBHit(hitDef, crossRefSeq.str(), cctopSeq.str(), topologiesCopy, experimentsCopy, reducedSeq.str(), hasSignalRegion, signalBeg, signalEnd);
										}
									}
								}else
								{
									std::cerr << "HspHSeq length check failed: " << hitDef << " sum=" <<  sumHspHSeq << " length= " << seqContext.getSequence().length() << std::endl;
								}
							}else
							{
								std::cerr << hitDef << " midline check failed" << std::endl;
							}
						}
					}
				}
			}
		}
	}

	return ret;
}
