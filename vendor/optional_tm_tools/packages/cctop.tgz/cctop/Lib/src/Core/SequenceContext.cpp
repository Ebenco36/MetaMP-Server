/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * SequenceContext.cpp
 *
 *  Created on: 2014.07.04.
 *      Author: "Istvan Remenyi"
 */

#include "SequenceContext.h"
#include "../CCTopLibDefs.h"
#include "../Utils/CalcUtils.h"
#include "../Utils/StringUtils.h"

#include <iostream>

CCTOP::Core::SequenceContext::SequenceContext()
: _state(CONTEXTSTATE_UNDEFINED), _signalMode(SIGNALMODE_UNDEFINED), _transitMode(TRANSITMODE_UNDEFINED), _hasUniprotEvidence(false), _singnalPPos(-1), _isNTerminalOutSide(false), _reliability(0.0), _isTransMembrane(false), _signalPDScore(0), _nterminalIndex(1),
  _useTMFilter(false)
{}

CCTOP::Core::SequenceContext::SequenceContext(const SequenceContext& copy)
: _state(CONTEXTSTATE_UNDEFINED), _signalMode(SIGNALMODE_UNDEFINED), _transitMode(TRANSITMODE_UNDEFINED), _hasUniprotEvidence(false), _singnalPPos(-1), _isNTerminalOutSide(false), _reliability(0.0), _isTransMembrane(false), _signalPDScore(0), _nterminalIndex(1),
  _useTMFilter(false)
{}

CCTOP::Core::SequenceContext::~SequenceContext()
{}

void CCTOP::Core::SequenceContext::setSignalMode(SignalMode mode)
{
	_signalMode = mode;
}

void CCTOP::Core::SequenceContext::setTransitMode(TransitMode mode)
{
	_transitMode = mode;
}

void CCTOP::Core::SequenceContext::setSignalPPos(int pos)
{
	_singnalPPos = pos;
}

void CCTOP::Core::SequenceContext::setSignalPDScore(double score)
{
	_signalPDScore = score;
}

CCTOP::Core::SignalMode CCTOP::Core::SequenceContext::getSignalMode() const
{
	return _signalMode;
}

CCTOP::Core::TransitMode CCTOP::Core::SequenceContext::getTransitMode() const
{
	return _transitMode;
}

int CCTOP::Core::SequenceContext::getSignalPPos() const
{
	return _singnalPPos;
}

double CCTOP::Core::SequenceContext::getSignalPDScore()
{
	return _signalPDScore;
}

CCTOP::Core::SequenceContext& CCTOP::Core::SequenceContext::operator=(const SequenceContext& copy)
{
	_state = CONTEXTSTATE_UNDEFINED;
	return *this;
}

void CCTOP::Core::SequenceContext::setSequence(const std::string& sequence)
{
	_sequence = sequence;
}

void CCTOP::Core::SequenceContext::setSequenceChecksum(const std::string& checksum)
{
	_checksum = checksum;
}

void CCTOP::Core::SequenceContext::setCCTopID(const std::string& cctopId)
{
	_cctopId = cctopId;
}

void CCTOP::Core::SequenceContext::setName(const std::string& name)
{
	_name = name;
	CCTOP::Utils::replaceStringInPlace(_name, "\n", "");
	CCTOP::Utils::replaceStringInPlace(_name, ";", "");
}

void CCTOP::Core::SequenceContext::setNote(const std::string& note)
{
	_note = note;
}

void CCTOP::Core::SequenceContext::setSequenceFilePath(const std::string& sequenceFilePath)
{
	_sequenceFilePath = sequenceFilePath;
}

void CCTOP::Core::SequenceContext::setHMMTopParam(const std::string& param)
{
	_hmmtopParam = param;
}

void CCTOP::Core::SequenceContext::setReducedSequence(const std::string& sequence)
{
	_reducedSequence = sequence;
}

void CCTOP::Core::SequenceContext::setSignalReducedSequence(const std::string& sequence)
{
	_signalReducedSequence = sequence;
}

void CCTOP::Core::SequenceContext::setUniprotBlastAc(const std::string& uniprotBlastAc)
{
	_uniprotBlastAc = uniprotBlastAc;
}

void CCTOP::Core::SequenceContext::setUniprotId(const std::string& id)
{
	_uniprotId = id;
}

void CCTOP::Core::SequenceContext::addPropeptideRegion(int begin, int end)
{
	Region reg;
	reg.begin = begin;
	reg.end = end;
	_propeptides.push_back(reg);
}

void CCTOP::Core::SequenceContext::addTransitRegion(int begin, int end)
{
	Region reg;
	reg.begin = begin;
	reg.end = end;
	_transits.push_back(reg);
}

void CCTOP::Core::SequenceContext::addSignalRegion(int begin, int end)
{
	Region reg;
	reg.begin = begin;
	reg.end = end;
	_signals.push_back(reg);
}

void CCTOP::Core::SequenceContext::addTopDBHit(const std::string& topDBId, const std::string& crossRefSeq, const std::string& cctopSeq,
		const std::vector<CCTOP::Core::TopologyEntry>& topology, const std::vector<CCTOP::Core::ExperimentEntry>& experiments, const std::string& reducedSeq, bool hasSignalRegion, int signalBeg, int signalEnd)
{
	TopDBHit hit;
	hit.topDBId = topDBId;
	hit.crossRefSeq = crossRefSeq;
	hit.cctopSeq = cctopSeq;
	//could be faster if topdbhit is first added to the hits, and then experiments assigned to the reference
	hit.topology = topology;
	hit.experiments = experiments;
	hit.signalBeg = signalBeg;
	hit.signalEnd = signalEnd;
	hit.reducedSeq = reducedSeq;
	hit.hasSignalRegion = hasSignalRegion;

	_topDBHits.push_back(hit);
}

void CCTOP::Core::SequenceContext::addUniprotAC(const std::string& ac)
{
	if(ac.compare(_uniprotBlastAc))
	{
		std::vector< std::string >::iterator iter = _uniprotAcs.begin();
		while(iter != _uniprotAcs.end() && ac.compare(*iter))
		{
			iter++;
		}

		if(iter == _uniprotAcs.end())
			_uniprotAcs.push_back(ac);
	}
}

void CCTOP::Core::SequenceContext::addRemovedTransitRegions(int beg, int end)
{
	Region r;
	r.begin = beg;
	r.end = end;

	std::cerr << "Adding transit region: " << beg << " - " << end << std::endl;

	_removedTransitRegions.push_back(r);
}

void CCTOP::Core::SequenceContext::addRemovedSignalRegions(int beg, int end)
{
	Region r;
	r.begin = beg;
	r.end = end;

	std::cerr << "Adding signal region: " << beg << " - " << end << std::endl;

	_removedSignalRegions.push_back(r);
}


void CCTOP::Core::SequenceContext::addMethodHit(const std::string& methodId, int beg, int end, Localization loc)
{
	_lock.lock();

	TopologyEntry entry;

	entry.beg = beg;
	entry.end = end;
	entry.loc = loc;

	std::cerr << methodId << " " << beg << " - " << end << ": " << localizationToChar(loc) << std::endl;

	std::map<std::string, std::vector<TopologyEntry> >::iterator iter = _methodHits.find(methodId);
	if(iter != _methodHits.end())
	{
		iter->second.push_back(entry);
	}else
	{
		std::vector<TopologyEntry> vec;
		vec.push_back(entry);
		_methodHits[methodId] = vec;
	}

	_lock.unlock();
}

void CCTOP::Core::SequenceContext::addCCTopTopology(int beg, int end, Localization loc)
{
	TopologyEntry entry;

	entry.beg = beg;
	entry.end = end;
	entry.loc = loc;

	std::cerr << "CCTOP Topology: " << " " << beg << " - " << end << ": " << localizationToChar(loc) << std::endl;

	_cctopTopology.push_back(entry);
}

void CCTOP::Core::SequenceContext::addTOPDOMHit(const std::string& protId, int beg, int end, Localization loc)
{
	TopologyEntry entry;

	entry.beg = beg;
	entry.end = end;
	entry.loc = loc;

	std::cerr << "TOPDOM:: " << protId << " " << beg << " - " << end << ": " << localizationToChar(loc) << std::endl;


	std::map<std::string, std::vector<TopologyEntry> >::iterator iter = _topDOMHits.find(protId);
	if(iter != _topDOMHits.end())
	{
		iter->second.push_back(entry);
	}else
	{
		std::vector<TopologyEntry> vec;
		vec.push_back(entry);
		_topDOMHits[protId] = vec;
	}
}

void CCTOP::Core::SequenceContext::setNTerminalOutSide(bool isOutSide)
{
	_isNTerminalOutSide = isOutSide;
}

void CCTOP::Core::SequenceContext::addUsedLoopTopology(const CCTOP::Core::TopologyEntry* entry)
{
	if(entry)
		_usedLoops.push_back(entry);
}

void CCTOP::Core::SequenceContext::setReliability(double reliability)
{
	_reliability = reliability;
}

void CCTOP::Core::SequenceContext::addDisabledMethod(const std::string& methodName)
{
	std::vector<std::string>::const_iterator iter = _disabledMethods.begin();
	while(iter != _disabledMethods.end()
			&& iter->compare(methodName))
	{
		iter++;
	}

	if(iter == _disabledMethods.end())
		_disabledMethods.push_back(methodName);
}

void CCTOP::Core::SequenceContext::setTMFilter(bool filter)
{
	_useTMFilter = filter;
}

void CCTOP::Core::SequenceContext::setTransmembrane(bool transmembrane)
{
	_isTransMembrane = transmembrane;
}

void CCTOP::Core::SequenceContext::setUniprotEvidence(bool hasEvidence)
{
	_hasUniprotEvidence = hasEvidence;
}

const std::string& CCTOP::Core::SequenceContext::getSequence() const
{
	return _sequence;
}

const std::string& CCTOP::Core::SequenceContext::getCCTopID() const
{
	return _cctopId;
}

const std::string& CCTOP::Core::SequenceContext::getName() const
{
	return _name;
}

const std::string& CCTOP::Core::SequenceContext::getNote() const
{
	return _note;
}

const std::string& CCTOP::Core::SequenceContext::getSequenceChecksum() const
{
	return _checksum;
}

const std::string& CCTOP::Core::SequenceContext::getSequenceFilePath() const
{
	return _sequenceFilePath;
}

const std::string& CCTOP::Core::SequenceContext::getReducedSequence() const
{
	return _reducedSequence;
}

const std::string& CCTOP::Core::SequenceContext::getHMMTopParam() const
{
	return _hmmtopParam;
}

const std::string& CCTOP::Core::SequenceContext::getSignalReducedSequence() const
{
	return _signalReducedSequence;
}

const std::string& CCTOP::Core::SequenceContext::getUniprotBlastAc() const
{
	return _uniprotBlastAc;
}

const std::string& CCTOP::Core::SequenceContext::getUniprotId() const
{
	return _uniprotId;
}

std::vector<CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getPropeptideRegions() const
{
	return _propeptides;
}

std::vector<CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getTransitRegions() const
{
	return _transits;
}

std::vector<CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getSignalRegions() const
{
	return _signals;
}
std::map<CCTOP::Core::SignalMode, CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getSignalRegionMap() const
{
	return _signalRegionMap;
}

std::vector<CCTOP::Core::TopDBHit>& CCTOP::Core::SequenceContext::getTopDBHits() const
{
	return _topDBHits;
}

bool CCTOP::Core::SequenceContext::isNTerminalOutSide() const
{
	return _isNTerminalOutSide;
}

int CCTOP::Core::SequenceContext::getNTerminalIndex() const
{
	return _nterminalIndex;
}

const std::vector< std::string >& CCTOP::Core::SequenceContext::getUniprotACs() const
{
	return _uniprotAcs;
}

std::vector<CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getRemovedTransitRegions() const
{
	return _removedTransitRegions;
}

std::vector<CCTOP::Core::Region>& CCTOP::Core::SequenceContext::getRemovedSignalRegions() const
{
	return _removedSignalRegions;
}

std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& CCTOP::Core::SequenceContext::getMethodHits() const
{
	return _methodHits;
}

std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& CCTOP::Core::SequenceContext::getTOPDOMHits() const
{
	return _topDOMHits;
}

std::vector<CCTOP::Core::TopologyEntry>& CCTOP::Core::SequenceContext::getCCTOPTopology() const
{
	return _cctopTopology;
}

bool CCTOP::Core::SequenceContext::hasUsedLoopTopology(const CCTOP::Core::TopologyEntry* entry) const
{
	bool ret = false;

	std::vector<const CCTOP::Core::TopologyEntry*>::const_iterator iter = _usedLoops.begin();
	while(iter != _usedLoops.end() && !ret)
	{
		ret = (*iter) == entry;

		iter++;
	}

	return ret;
}

double CCTOP::Core::SequenceContext::getReliability() const
{
	return _reliability;
}

bool CCTOP::Core::SequenceContext::isMethodDisabled(const std::string& methodName) const
{
	bool ret = false;

	std::vector<std::string>::const_iterator iter = _disabledMethods.begin();
	while(iter != _disabledMethods.end()
			&& iter->compare(methodName))
	{
		iter++;
	}
	ret = iter != _disabledMethods.end();

	return ret;
}

bool CCTOP::Core::SequenceContext::useTMFilter() const
{
	return _useTMFilter;
}

bool CCTOP::Core::SequenceContext::isTransmembrane() const
{
	return _isTransMembrane;
}

bool CCTOP::Core::SequenceContext::hasUniprotEvidence() const
{
	return _hasUniprotEvidence;
}

void CCTOP::Core::SequenceContext::invertTopology()
{
	std::vector<TopologyEntry>::iterator iter = _cctopTopology.begin();
	while(iter != _cctopTopology.end())
	{
		if(iter->loc == LOCALIZATION_INSIDE)
			iter->loc = LOCALIZATION_OUTSIDE;
		else
			if(iter->loc == LOCALIZATION_OUTSIDE)
				iter->loc = LOCALIZATION_INSIDE;

		iter++;
	}
}

void CCTOP::Core::SequenceContext::validateTopology()
{
	if(_cctopTopology.size())
	{
		//1. statement
		bool hasIOMismatch = false;
		bool hasInvertIOMismatch = false;

		for(int t = 1; t <= (int)_signalReducedSequence.length(); t++)
		{
			std::vector<TopologyEntry>::iterator topoIter = _cctopTopology.begin();
			while(topoIter != _cctopTopology.end()
					&& (topoIter->beg > t || topoIter->end < t))
			{
				topoIter++;
			}
			if(topoIter != _cctopTopology.end())
			{
				if(_topDBHits.size())
				{
					std::vector<CCTOP::Core::TopDBHit>::iterator topDBIter = _topDBHits.begin();
					while(topDBIter != _topDBHits.end()
							&& (!hasIOMismatch || !hasInvertIOMismatch))
					{
						TopDBHit& entry = *topDBIter;
						std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
						std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experiments.begin();
						while(expIter != experiments.end()
								&& (expIter->beg > t || expIter->end < t))
						{
							expIter++;
						}
						if(expIter != experiments.end())
						{
							hasIOMismatch |= (topoIter->loc == LOCALIZATION_INSIDE && expIter->loc == LOCALIZATION_OUTSIDE)
									|| (topoIter->loc == LOCALIZATION_OUTSIDE && expIter->loc == LOCALIZATION_INSIDE);

							Localization loc = topoIter->loc == LOCALIZATION_INSIDE ? LOCALIZATION_OUTSIDE :
														( topoIter->loc == LOCALIZATION_OUTSIDE ? LOCALIZATION_INSIDE :
																topoIter->loc);

							hasInvertIOMismatch |= (loc == LOCALIZATION_INSIDE && expIter->loc == LOCALIZATION_OUTSIDE)
									|| (loc == LOCALIZATION_OUTSIDE && expIter->loc == LOCALIZATION_INSIDE);
						}

						topDBIter++;
					}
				}

			}else
			{
				std::cerr << "validation failed - leaked topology at pos: " << t << std::endl;
			}
		}

		//1,2. condition check
		if((hasIOMismatch && !hasInvertIOMismatch)
				|| (getReducedSequence().length() != getSignalReducedSequence().length()
						&& _cctopTopology.begin()->loc == LOCALIZATION_INSIDE))
		{
			invertTopology();
		}

		//3. statement
		bool hasChanged = true;
		while(hasChanged)
		{
			hasChanged = false;
			std::vector<TopologyEntry> deletableLoops;
			std::vector<TopologyEntry>::iterator topoIter = _cctopTopology.begin();
			std::vector<TopologyEntry>::iterator prevTopoIter = _cctopTopology.begin();
			while(topoIter != _cctopTopology.end())
			{
				if(topoIter->loc == LOCALIZATION_MEMBRANE)
				{
					_isTransMembrane = true;
				}
				if(topoIter->loc == LOCALIZATION_MEMBLOOP)
				{
					bool hasEvidence = false;
					std::vector<CCTOP::Core::TopDBHit>::iterator topDBIter = _topDBHits.begin();
					//check in expriments
					while(topDBIter != _topDBHits.end() && !hasEvidence)
					{
						TopDBHit& entry = *topDBIter;
						std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
						std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experiments.begin();
						while(expIter != experiments.end() && !hasEvidence)
						{

							hasEvidence =
									(topoIter->loc == expIter->loc) &&
									//1.contains exp
									((topoIter->beg <= expIter->beg
											&& topoIter->end >= expIter->end)
											//2.overlap right
											|| (topoIter->beg <= expIter->beg
													&& topoIter->end <= expIter->end
													&& topoIter->end >= expIter->beg)
													//3.overlap left
													|| (topoIter->beg >= expIter->beg
															&& topoIter->end >= expIter->end
															&& topoIter->beg <= expIter->end)
															//4.exp contains
															|| (topoIter->beg >= expIter->beg
																	&& topoIter->end <= expIter->end));
							expIter++;
						}

						topDBIter++;
					}

					//check methods
					if(!hasEvidence)
					{
						std::map<std::string, std::vector<TopologyEntry> >::iterator methodIter = _methodHits.begin();
						while(methodIter != _methodHits.end() && !hasEvidence)
						{
							if(strcmp(CCTOPLIB_METHOD_HMMTOP, methodIter->first.c_str()))
							{
								std::vector<TopologyEntry>::iterator methodTopoIter = methodIter->second.begin();
								while(methodTopoIter != methodIter->second.end() && !hasEvidence)
								{
									hasEvidence =
											//1.contains exp
											(topoIter->loc == methodTopoIter->loc) &&
											((topoIter->beg <= methodTopoIter->beg
													&& topoIter->end >= methodTopoIter->end)
													//2.overlap right
													|| (topoIter->beg <= methodTopoIter->beg
															&& topoIter->end <= methodTopoIter->end
															&& topoIter->end >= methodTopoIter->beg)
															//3.overlap left
															|| (topoIter->beg >= methodTopoIter->beg
																	&& topoIter->end >= methodTopoIter->end
																	&& topoIter->beg <= methodTopoIter->end)
																	//4.exp contains
																	|| (topoIter->beg >= methodTopoIter->beg
																			&& topoIter->end <= methodTopoIter->end));

									methodTopoIter++;
								}
							}
							methodIter++;
						}
					}

					if(!hasEvidence)
					{
						deletableLoops.push_back(*topoIter);
						std::vector<TopologyEntry>::iterator nextTopoIter = topoIter;
						nextTopoIter++;

						if(nextTopoIter == _cctopTopology.end())
						{
							prevTopoIter->end = topoIter->end;
						}else
						{
							deletableLoops.push_back(*nextTopoIter);
							prevTopoIter->end = nextTopoIter->end;
						}
						hasChanged = true;

						//delete it from topology
						std::vector<TopologyEntry>::iterator deletableIter = deletableLoops.begin();
						while(deletableIter != deletableLoops.end())
						{
							std::vector<TopologyEntry>::iterator topoIter = _cctopTopology.begin();
							while(topoIter != _cctopTopology.end()
									&& (deletableIter->beg != topoIter->beg
											|| deletableIter->end != topoIter->end
											|| deletableIter->loc != topoIter->loc))
							{
								topoIter++;
							}

							if(topoIter != _cctopTopology.end())
							{
								_cctopTopology.erase(topoIter);
							}

							deletableIter++;
						}
						break;
					}
				}

				prevTopoIter = topoIter;
				topoIter++;
			}
		}
	}
}


void CCTOP::Core::SequenceContext::applyRemovedTransitRegions()
{
	removeRegions(_removedTransitRegions);
}

void CCTOP::Core::SequenceContext::applyRemovedSignalRegions()
{
	removeRegions(_removedSignalRegions);
}

void CCTOP::Core::SequenceContext::removeRegions(const std::vector<Region>& regions)
{
	std::vector<Core::Region>::const_iterator theIterator = regions.begin();
	while(theIterator != regions.end())
	{
		int sigBeg = theIterator->begin;
		int sigEnd = theIterator->end;

		std::vector<CCTOP::Core::TopDBHit>::iterator iter = _topDBHits.begin();
		while(iter != _topDBHits.end())
		{
			std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = iter->experiments.begin();
			int expIndex = 0;
			while(expIter != iter->experiments.end())
			{
				int newBeg = expIter->beg;
				int newEnd = expIter->end;

				Utils::removeRegion(newBeg, newEnd, sigBeg, sigEnd);

				expIter->beg = newBeg;
				expIter->end = newEnd;

				expIter++;
				expIndex++;
			}

			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = iter->topology.begin();
			while(topoIter != iter->topology.end())
			{
				int newBeg = topoIter->beg;
				int newEnd = topoIter->end;

				Utils::removeRegion(newBeg, newEnd, sigBeg, sigEnd);

				topoIter->beg = newBeg;
				topoIter->end = newEnd;

				topoIter++;
			}
			iter++;
		}

		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter = _methodHits.begin();
		while(methodIter != _methodHits.end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = methodIter->second.begin();
			while( topoIter != methodIter->second.end() )
			{
				int newBeg = topoIter->beg;
				int newEnd = topoIter->end;

				Utils::removeRegion(newBeg, newEnd, sigBeg, sigEnd);

				topoIter->beg = newBeg;
				topoIter->end = newEnd;

				topoIter++;
			}

			methodIter++;
		}

		{
			std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter = _topDOMHits.begin();
			while(methodIter != _topDOMHits.end())
			{
				std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = methodIter->second.begin();
				while( topoIter != methodIter->second.end() )
				{
					int newBeg = topoIter->beg;
					int newEnd = topoIter->end;

					Utils::removeRegion(newBeg, newEnd, sigBeg, sigEnd);

					topoIter->beg = newBeg;
					topoIter->end = newEnd;

					topoIter++;
				}

				methodIter++;
			}
		}

		theIterator++;
	}
}

void CCTOP::Core::SequenceContext::undoRemovedTransitRegions()
{
	undoRegionList(_removedTransitRegions);
}

void CCTOP::Core::SequenceContext::undoRemovedSignalRegions()
{
	undoRegionList(_removedSignalRegions);
}

void CCTOP::Core::SequenceContext::undoRegionList(const std::vector<Region>& regions)
{
	std::vector<Core::Region>::const_iterator theIterator = regions.begin();
	while(theIterator != regions.end())
	{
		int sigBeg = theIterator->begin;
		int sigEnd = theIterator->end;

		int dummy = 0;
		Utils::insertRegion(_nterminalIndex, dummy, sigBeg, sigEnd);

		std::vector<CCTOP::Core::TopDBHit>::iterator iter = _topDBHits.begin();
		while(iter != _topDBHits.end())
		{
			std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = iter->experiments.begin();
			int expIndex = 0;
			while(expIter != iter->experiments.end())
			{
				int newBeg = expIter->beg;
				int newEnd = expIter->end;

				Utils::insertRegion(newBeg, newEnd, sigBeg, sigEnd);

				expIter->beg = newBeg;
				expIter->end = newEnd;

				expIter++;
				expIndex++;
			}

			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = iter->topology.begin();
			while(topoIter != iter->topology.end())
			{
				int newBeg = topoIter->beg;
				int newEnd = topoIter->end;

				Utils::insertRegion(newBeg, newEnd, sigBeg, sigEnd);

				topoIter->beg = newBeg;
				topoIter->end = newEnd;

				topoIter++;
			}

			iter++;
		}


		std::vector<CCTOP::Core::TopologyEntry>::iterator cctopIter = _cctopTopology.begin();
		while(cctopIter != _cctopTopology.end())
		{
			int newBeg = cctopIter->beg;
			int newEnd = cctopIter->end;

			Utils::insertRegion(newBeg, newEnd, sigBeg, sigEnd);

			cctopIter->beg = newBeg;
			cctopIter->end = newEnd;

			cctopIter++;
		}

		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter = _methodHits.begin();
		while(methodIter != _methodHits.end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = methodIter->second.begin();
			while( topoIter != methodIter->second.end() )
			{
				int newBeg = topoIter->beg;
				int newEnd = topoIter->end;

				Utils::insertRegion(newBeg, newEnd, sigBeg, sigEnd);

				topoIter->beg = newBeg;
				topoIter->end = newEnd;

				topoIter++;
			}

			methodIter++;
		}

		{
			std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter = _topDOMHits.begin();
			while(methodIter != _topDOMHits.end())
			{
				std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = methodIter->second.begin();
				while( topoIter != methodIter->second.end() )
				{
					int newBeg = topoIter->beg;
					int newEnd = topoIter->end;

					Utils::insertRegion(newBeg, newEnd, sigBeg, sigEnd);

					topoIter->beg = newBeg;
					topoIter->end = newEnd;

					topoIter++;
				}

				methodIter++;
			}
		}

		theIterator++;
	}
}
