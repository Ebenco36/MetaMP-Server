/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * HMMTopLink.h
 *
 *  Created on: 2014.07.31.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CORE_EXTERNAL_HMMTOPLINK_H_
#define CCTOP_CORE_EXTERNAL_HMMTOPLINK_H_

#include "../MethodContext.h"
#include "../SequenceContext.h"

#include <string>
#include <vector>

#include "../../Utils/Xml/rapidxml.hpp"

struct _gthmm ;

namespace CCTOP {
class CCTopLib;
namespace Core { namespace External
{

class HMMTopLink
{
protected:
	void safeConstraint(SequenceContext& seqContext, _gthmm* hmm, const std::vector<CCTOP::Core::TopologyEntry>& methodTopology, const std::vector<CCTOP::Core::TopDBHit>&  topDBHits) const;
	void experimentWeighting(SequenceContext& seqContext, _gthmm* hmm) const;
	void methodWeighting(const CCTopLib& lib,SequenceContext& seqContext, _gthmm* hmm) const;
	bool hasLoop(const  CCTopLib& lib, SequenceContext& seqContext) const;

public:
	HMMTopLink();
	HMMTopLink(const HMMTopLink& copy);
	~HMMTopLink();
	HMMTopLink& operator=(const HMMTopLink& copy);


	void callHMMTOP(const CCTopLib& lib, const MethodContext& methodContext, SequenceContext& seqContext, bool isExperiment) const;
};

}}}




#endif /* CCTOP_CORE_EXTERNAL_HMMTOPLINK_H_ */
