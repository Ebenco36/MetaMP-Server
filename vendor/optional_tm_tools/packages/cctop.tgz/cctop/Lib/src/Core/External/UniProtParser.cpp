/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * UniProtParser.cpp
 *
 *  Created on: 2014.07.07.
 *      Author: "Istvan Remenyi"
 */

#include "UniProtParser.h"

#include "../../Utils/StringUtils.h"

#include <cstdlib>
#include <iostream>
#include <sstream>

CCTOP::Core::External::UniProtParser::UniProtParser()
{

}

CCTOP::Core::External::UniProtParser::UniProtParser(const UniProtParser& copy)
{}

CCTOP::Core::External::UniProtParser::~UniProtParser()
{}

CCTOP::Core::External::UniProtParser& CCTOP::Core::External::UniProtParser::operator=(const UniProtParser& copy)
{
	return *this;
}

bool CCTOP::Core::External::UniProtParser::parseUniProtPropeptideResults(const std::string& resultList, Core::SequenceContext& seqContext) const
{
	bool ret = false;

	std::istringstream f(resultList);
	std::string line;
	std::vector<std::string> vec;
	while (std::getline(f, line))
	{
		vec.clear();
		Utils::splitSafe(line, ' ', vec);

		//seqContext.addPropeptideRegion(atoi(vec[2].c_str()), atoi(vec[3].c_str()));
		int beg = atoi(vec[2].c_str());
		int end = atoi(vec[3].c_str());
		if(beg > 0 && end > 0)
			seqContext.addPropeptideRegion(beg, end);
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniProtTransitResults(const std::string& resultList, Core::SequenceContext& seqContext) const
{
	bool ret = false;

	std::istringstream f(resultList);
	std::string line;
	std::vector<std::string> vec;
	while (std::getline(f, line))
	{
		vec.clear();
		Utils::splitSafe(line, ' ', vec);

		if(strcmp("?",vec[2].c_str()) && (strcmp("?",vec[3].c_str())))
		{
			int beg = atoi(vec[2].c_str());
			int end = atoi(vec[3].c_str());
			if(beg > 0 && end > 0)
				seqContext.addTransitRegion(beg, end);
		}
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniProtSignalResults(const std::string& resultList, Core::SequenceContext& seqContext) const
{
	bool ret = false;

	std::istringstream f(resultList);
	std::string line;
	std::vector<std::string> vec;
	while (std::getline(f, line))
	{
		vec.clear();
		Utils::splitSafe(line, ' ', vec);

		//seqContext.addSignalRegion(atoi(vec[2].c_str()), atoi(vec[3].c_str()));
		int beg = atoi(vec[2].c_str());
		int end = atoi(vec[3].c_str());
		if(beg > 0 && end > 0)
			seqContext.addSignalRegion(beg, end);
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniprotName(const std::string& result, SequenceContext& seqContext) const
{
	bool ret = true;

	if(!result.empty())
	{
		std::vector<std::string> vec;
		vec.clear();
		Utils::splitSafe(result, '=', vec);
		if(vec.size() > 1)
		{
			seqContext.setName(vec[1]);
		}
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniprotACs(const std::string& result, Core::SequenceContext& seqContext) const
{
	//AC   P34998; B4DIE9; Q13008; Q4QRJ1; Q9UK64;
	bool ret = true;

	if(!result.empty())
	{
		std::vector<std::string> vec;
		vec.clear();
		Utils::splitSafe(result, ' ', vec);
		if(vec.size() > 1)
		{
			std::vector<std::string>::iterator iter = vec.begin();
			iter++;
			while(iter != vec.end())
			{
				if(vec.size() > 2)
				{
					CCTOP::Utils::replaceStringInPlace(*iter, "\n", "");
					CCTOP::Utils::replaceStringInPlace(*iter, ";", "");
					seqContext.addUniprotAC((*iter));
				}else
				{
					CCTOP::Utils::replaceStringInPlace(*iter, "\n", "");
					CCTOP::Utils::replaceStringInPlace(*iter, ";", "");
					seqContext.addUniprotAC(*iter);
				}
				iter++;
			}
		}
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniprotId(const std::string& result, Core::SequenceContext& seqContext) const
{
	//ID   STS_HUMAN               Reviewed;         583 AA.
	bool ret = true;

	if(!result.empty())
	{
		std::vector<std::string> vec;
		vec.clear();
		Utils::splitSafe(result, ' ', vec);
		if(vec.size() > 1)
		{
			seqContext.setUniprotId(vec[1]);
		}
	}

	return ret;
}

bool CCTOP::Core::External::UniProtParser::parseUniprotEvidence(const std::string& result, Core::SequenceContext& seqContext) const
{
	//PE   1: Evidence at protein level;
	bool ret = true;

	if(!result.empty()
			&& result.find("Evidence at protein leve") != std::string::npos)
	{
		seqContext.setUniprotEvidence(true);
	}

	return ret;
}
