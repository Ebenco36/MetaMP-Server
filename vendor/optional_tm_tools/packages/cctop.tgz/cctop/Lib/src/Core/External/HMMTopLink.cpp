/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * BlastParser.cpp
 *
 *  Created on: 2014.07.31.
 *      Author: "Istvan Remenyi"
 */

#include "HMMTopLink.h"

#include "../../CCTopLib.h"
#include "../../CCTopLibDefs.h"
#include "../MethodContext.h"

#include "../../Utils/Xml/rapidxml.hpp"
#include "../../Utils/StringUtils.h"
#include "../../Utils/CalcUtils.h"

#include <algorithm>
#include <sstream>
#include <iostream>

extern "C" {
#include <omp.h>
#include <hmmtop.h>
}


static const char* HMMTOP_ALPHABETH = "ACDEFGHIKLMNPQRSTVWY-#";


CCTOP::Core::External::HMMTopLink::HMMTopLink()
{}

CCTOP::Core::External::HMMTopLink::HMMTopLink(const HMMTopLink& copy)
{}

CCTOP::Core::External::HMMTopLink::~HMMTopLink()
{}

CCTOP::Core::External::HMMTopLink& CCTOP::Core::External::HMMTopLink::operator=(const HMMTopLink& copy)
{ return *this; }

void CCTOP::Core::External::HMMTopLink::safeConstraint(SequenceContext& seqContext, _gthmm* hmm, const std::vector<CCTOP::Core::TopologyEntry>& methodTopology, const std::vector<CCTOP::Core::TopDBHit>&  topDBHits) const
{
	if(seqContext.isNTerminalOutSide())
		gtHmmSetConstraint(hmm, 0, 0, Core::localizationToChar(LOCALIZATION_OUTSIDE), 1.0);

	std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = methodTopology.begin();
	while( topoIter != methodTopology.end() )
	{
		if(topoIter->loc == LOCALIZATION_MEMBLOOP)
		{
			bool mismatch = false;
			std::vector<CCTOP::Core::TopDBHit>::const_iterator topDBIter = topDBHits.begin();
			while(topDBIter != topDBHits.end() && !mismatch)
			{
				const TopDBHit& entry = *topDBIter;
				const std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
				std::vector<CCTOP::Core::ExperimentEntry>::const_iterator expIter = experiments.begin();
				while(expIter != experiments.end() && !mismatch)
				{
					const ExperimentEntry& expEntry = *expIter;

					//1.contains exp
					if((topoIter->beg <= expEntry.beg
							&& topoIter->end >= expEntry.end)
							//2.overlap right
							|| (topoIter->beg <= expEntry.beg
									&& topoIter->end <= expEntry.end
									&& topoIter->end >= expEntry.beg)
									//3.overlap left
									|| (topoIter->beg >= expEntry.beg
											&& topoIter->end >= expEntry.end
											&& topoIter->beg <= expEntry.end)
											//4.exp contains
											|| (topoIter->beg >= expEntry.beg
													&& topoIter->end <= expEntry.end))
					{
						mismatch = topoIter->loc != expEntry.loc;
					}

					expIter++;
				}

				topDBIter++;
			}

			if(!mismatch)
			{
				gtHmmSetConstraint(hmm, topoIter->beg-1, topoIter->end-1, Core::localizationToChar(topoIter->loc), 1.0);
				seqContext.addUsedLoopTopology(&(*topoIter));
			}
		}
		topoIter++;
	}
}

void CCTOP::Core::External::HMMTopLink::experimentWeighting(SequenceContext& seqContext, _gthmm* hmm) const
{
	std::vector<CCTOP::Core::TopDBHit>&  topDBHits = seqContext.getTopDBHits();
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
	{
		if(topDBHits.size())
		{
			std::vector<CCTOP::Core::TopDBHit>::iterator topDBIter = topDBHits.begin();
			while(topDBIter != topDBHits.end())
			{
				TopDBHit& entry = *topDBIter;
				std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
				std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experiments.begin();
				while(expIter != experiments.end())
				{
					ExperimentEntry& expEntry = *expIter;
					if(expEntry.beg <= expEntry.end && expEntry.beg > 0)
					{
						if(expEntry.loc == LOCALIZATION_OUTSIDE || expEntry.loc == LOCALIZATION_INSIDE
								|| expEntry.loc == LOCALIZATION_MEMBRANE || expEntry.loc == LOCALIZATION_MEMBLOOP)
						{
							if(expEntry.chainIds.size())
							{
								std::vector< std::string >::const_iterator chIter = expEntry.chainIds.begin();
								while(chIter != expEntry.chainIds.end())
								{
									gtHmmSetConstraint(hmm, expEntry.beg-1, expEntry.end-1, Core::localizationToChar(expEntry.loc), 1.0);

									chIter++;
								}
							}else
							{
								gtHmmSetConstraint(hmm, expEntry.beg-1, expEntry.end-1, Core::localizationToChar(expEntry.loc), 1.0);
							}
						}
					}
					expIter++;
				}

				topDBIter++;
			}
		}
	}

	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& methods = seqContext.getMethodHits();
	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter;
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_OCTOPUS)
			&& (methodIter = methods.find(CCTOPLIB_METHOD_OCTOPUS)) != methods.end())
	{
		safeConstraint(seqContext, hmm, methodIter->second, topDBHits);
	}

	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_MEMSAT)
			&& (methodIter = methods.find(CCTOPLIB_METHOD_MEMSAT)) != methods.end())
	{
		safeConstraint(seqContext, hmm, methodIter->second, topDBHits);
	}
}

void CCTOP::Core::External::HMMTopLink::methodWeighting(const CCTopLib& lib,SequenceContext& seqContext, _gthmm* hmm) const
{
	if(seqContext.isNTerminalOutSide())
		gtHmmSetConstraint(hmm, 0, 0, Core::localizationToChar(LOCALIZATION_OUTSIDE), 20.0);

	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
	{
		std::vector<CCTOP::Core::TopDBHit>&  topDBHits = seqContext.getTopDBHits();
		if(topDBHits.size())
		{
			std::vector<CCTOP::Core::TopDBHit>::iterator topDBIter = topDBHits.begin();
			while(topDBIter != topDBHits.end())
			{
				TopDBHit& entry = *topDBIter;
				std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
				std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experiments.begin();
				while(expIter != experiments.end())
				{
					ExperimentEntry& expEntry = *expIter;
					if(expEntry.beg <= expEntry.end && expEntry.beg > 0)
					{
						if(expEntry.loc == LOCALIZATION_OUTSIDE || expEntry.loc == LOCALIZATION_INSIDE
								|| expEntry.loc == LOCALIZATION_MEMBRANE || expEntry.loc == LOCALIZATION_MEMBLOOP)
						{
							if(expEntry.chainIds.size())
							{
								std::vector< std::string >::const_iterator chIter = expEntry.chainIds.begin();
								while(chIter != expEntry.chainIds.end())
								{
									gtHmmSetConstraint(hmm, expEntry.beg-1, expEntry.end-1, Core::localizationToChar(expEntry.loc), 20.0);

									chIter++;
								}
							}else
							{
								gtHmmSetConstraint(hmm, expEntry.beg-1, expEntry.end-1, Core::localizationToChar(expEntry.loc), 20.0);
							}
						}
					}
					expIter++;
				}

				topDBIter++;
			}
		}
	}

	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDOM))
	{
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& topdoms = seqContext.getTOPDOMHits();
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator topdomIter = topdoms.begin();
		while(topdomIter != topdoms.end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = topdomIter->second.begin();
			while( topoIter != topdomIter->second.end() )
			{
				if(topoIter->loc == LOCALIZATION_OUTSIDE || topoIter->loc == LOCALIZATION_INSIDE
						|| topoIter->loc == LOCALIZATION_MEMBRANE || topoIter->loc == LOCALIZATION_MEMBLOOP)
				{
					gtHmmSetConstraint(hmm, topoIter->beg-1, topoIter->end-1, Core::localizationToChar(topoIter->loc), 20.0);
				}

				topoIter++;
			}

			topdomIter++;
		}
	}

	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& methods = seqContext.getMethodHits();
	std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator methodIter = methods.begin();
	while(methodIter != methods.end())
	{
		if(!seqContext.isMethodDisabled(methodIter->first))
		{
			double ioWeigth = lib.getWeight(methodIter->first, "IO");
			double lmWeigth = lib.getWeight(methodIter->first, "LM");

			std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = methodIter->second.begin();
			while( topoIter != methodIter->second.end() )
			{
				if((topoIter->loc == LOCALIZATION_OUTSIDE || topoIter->loc == LOCALIZATION_INSIDE
						|| topoIter->loc == LOCALIZATION_MEMBRANE || topoIter->loc == LOCALIZATION_MEMBLOOP)
						&& !seqContext.hasUsedLoopTopology(&(*topoIter)))
				{
					gtHmmSetConstraint(hmm, topoIter->beg-1, topoIter->end-1, Core::localizationToChar(topoIter->loc),
							(topoIter->loc == LOCALIZATION_OUTSIDE || topoIter->loc == LOCALIZATION_INSIDE) ? ioWeigth : lmWeigth);
				}

				topoIter++;
			}
		}

		methodIter++;
	}
}




bool CCTOP::Core::External::HMMTopLink::hasLoop(const CCTopLib& lib,SequenceContext& seqContext) const
{
	bool hasLoop = false;

	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
	{
		std::vector<CCTOP::Core::TopDBHit>&  topDBHits = seqContext.getTopDBHits();
		if(topDBHits.size())
		{
			std::vector<CCTOP::Core::TopDBHit>::iterator topDBIter = topDBHits.begin();
			while(!hasLoop && topDBIter != topDBHits.end())
			{
				TopDBHit& entry = *topDBIter;
				std::vector<CCTOP::Core::ExperimentEntry>& experiments = entry.experiments;
				std::vector<CCTOP::Core::ExperimentEntry>::iterator expIter = experiments.begin();
				while(!hasLoop && expIter != experiments.end())
				{
					ExperimentEntry& expEntry = *expIter;
					if(expEntry.beg <= expEntry.end && expEntry.beg > 0)
					{
						if(expEntry.loc == LOCALIZATION_MEMBLOOP)
							hasLoop = true;
					}
					expIter++;
				}

				topDBIter++;
			}
		}
	}


	if(!hasLoop && !seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDOM))
	{
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& topdoms = seqContext.getTOPDOMHits();
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator topdomIter = topdoms.begin();
		while(!hasLoop && topdomIter != topdoms.end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = topdomIter->second.begin();
			while(!hasLoop && topoIter != topdomIter->second.end() )
			{
				if(topoIter->loc == LOCALIZATION_MEMBLOOP)
				{
					hasLoop = true;
				}
				topoIter++;
			}
			topdomIter++;
		}
	}

	if(!hasLoop)
	{
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& methods = seqContext.getMethodHits();
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::const_iterator methodIter = methods.begin();
		while(!hasLoop && methodIter != methods.end())
		{
			if(!seqContext.isMethodDisabled(methodIter->first))
			{
				std::vector<CCTOP::Core::TopologyEntry>::const_iterator topoIter = methodIter->second.begin();
				while( !hasLoop && topoIter != methodIter->second.end() )
				{
					if(topoIter->loc == LOCALIZATION_MEMBLOOP)
						hasLoop = true;

					topoIter++;
				}
			}
			methodIter++;
		}
	}

	return hasLoop;
}


void CCTOP::Core::External::HMMTopLink::callHMMTOP(const CCTopLib& lib, const MethodContext& methodContext, SequenceContext& seqContext, bool isExperiment) const
{
	std::string alphabet = lib.getLibParam("HMMTOP_ALPHABET");
	if(alphabet.empty())
		alphabet = HMMTOP_ALPHABETH;


	std::string tempSeq = seqContext.getSignalReducedSequence();
	for(unsigned int tempIndex = 0; tempIndex < tempSeq.length(); tempIndex++)
	{
		bool found = false;
		for(unsigned int alphaIndex = 0; alphaIndex < alphabet.size() && !found; alphaIndex++)
		{
			found=alphabet[alphaIndex] == tempSeq[tempIndex];
		}

		if(!found)
		{
			tempSeq[tempIndex] = '#';
		}
	}




	const char *topdb=NULL;
	const char *learn=NULL;
	const char *repsum=NULL;
	int topdb_minmax=0;
	const char *base_model=NULL;
	const char *bestpathmode=NULL;
	const char *recode=NULL;
	double ps=10000;
	double bias=lib.getAdditionalParam("HMMTOP_BIAS");

	std::string htCmd = seqContext.getHMMTopParam();
	if(htCmd.empty())
		htCmd = lib.getLibParam("HMMTOP_CMD");

	std::vector<std::string> cmdArgs;
	Utils::splitSafe(htCmd, ' ', cmdArgs);

	for(unsigned int i = 0; i<cmdArgs.size();i++)
	{
		if (!strcmp(cmdArgs[i].c_str(),"-bpm"))
			bestpathmode=cmdArgs[++i].c_str();
		if (!strncmp(cmdArgs[i].c_str(),"-bpm=",5))
			bestpathmode=&cmdArgs[i].c_str()[5];
		if (!strncmp(cmdArgs[i].c_str(),"--best_path_mode=",17))
			bestpathmode=&cmdArgs[i].c_str()[17];

		if (!strcmp(cmdArgs[i].c_str(),"-ps"))
			ps=atof(cmdArgs[++i].c_str());
		if (!strncmp(cmdArgs[i].c_str(),"-ps=",4))
			ps=atof(&cmdArgs[i].c_str()[4]);
		if (!strncmp(cmdArgs[i].c_str(),"--pseudo_size=",14))
			ps=atof(&cmdArgs[i].c_str()[14]);

		if (!strcmp(cmdArgs[i].c_str(),"-rs"))
			repsum=cmdArgs[++i].c_str();
		if (!strncmp(cmdArgs[i].c_str(),"--report_sum=",13))
			repsum=&cmdArgs[i].c_str()[13];


		if (!strcmp(cmdArgs[i].c_str(),"-topdb"))
			topdb=cmdArgs[++i].c_str();
		if (!strncmp(cmdArgs[i].c_str(),"-topdb=",7))
			topdb=&cmdArgs[i].c_str()[7];

		if (!strcmp(cmdArgs[i].c_str(),"-learn"))
			learn=cmdArgs[++i].c_str();
		if (!strncmp(cmdArgs[i].c_str(),"-learn=",7))
			learn=&cmdArgs[i].c_str()[7];

		if (!strcmp(cmdArgs[i].c_str(),"-topdb_minmax_problem"))
			topdb_minmax=1;

		if (!strcmp(cmdArgs[i].c_str(),"-model"))
			base_model=cmdArgs[++i].c_str();
		if (!strncmp(cmdArgs[i].c_str(),"-model=",7))
			base_model=&cmdArgs[i].c_str()[7];

		if (!strcmp(cmdArgs[i].c_str(),"-recode"))
			recode=cmdArgs[++i].c_str();

		if (!strcmp(cmdArgs[i].c_str(),"-bias"))
			bias=atof(cmdArgs[++i].c_str());
		if (!strncmp(cmdArgs[i].c_str(),"--bias=",7))
			bias=atof(&cmdArgs[i].c_str()[7]);
	}


	gthmm hmm = gtHmmNew();
	std::string model = base_model == NULL ? lib.getLibParam("HMMTOP_MODEL") : base_model;
	gtHmmReadModel (hmm->model, model.c_str());
	gtHmmSetEAlphabet (hmm->model, alphabet.c_str());
	if(hasLoop(lib, seqContext))
	{
		std::string plug = lib.getLibParam("HMMTOP_PLUG");
		gtHmmPlugByFileName(hmm->model,  plug.c_str());
	}

	gtHmmBuild (hmm->model);
	gtHmmSetPseudoSize (hmm->model, ps);
	gtHmmClear (hmm->model, HSUM);
	gtSeqSetAlphabet(hmm->inp, alphabet.c_str());

	gtSeqAddRaw(hmm->inp, tempSeq.c_str());
	gtSeqSetSeq(hmm->inp);

	hmm->len=hmm->inp->len;

	gtHmmAllocMemory (hmm);

	if(isExperiment)
		experimentWeighting(seqContext, hmm);
	else
		methodWeighting(lib, seqContext, hmm);

	if (topdb!=NULL)
		gtHmmSetConstraintsByTopdb (hmm, topdb, hmm->inp->name, topdb_minmax);
	if (learn!=NULL)
		gtHmmSetConstraintsFrom (hmm, learn, hmm->inp->name, 4);

	std::string param = lib.getLibParam("HMMTOP_BLAST_PARAMS");

	if(!param.empty())
	{
		std::string db = lib.getLibParam("HMMTOP_BLAST_DB");
		std::string cmd = lib.getLibParam("HMMTOP_BLAST_CMD");

		int argc = 7;
		const char* argv[] =
		{
				"hmmtop",
				htCmd.c_str(),
				"-blast_db_path",
				db.c_str(),
				"-blast_cmd_path",
				cmd.c_str(),
				"-blast",
				param.c_str(),
				NULL
		};

		gtHmmBlast (hmm, argc, const_cast<char**>(argv));
	}

	hmm->bias = bias;//0.01;
	if (recode!=NULL)
		gtHmmRecode (hmm->model, recode);
	gtHmmFinalizeConstraint(hmm);
	gtHmmBaumWelch (hmm, 0);
	if (bestpathmode!=NULL) {
		if (!strcasecmp(bestpathmode,"viterbi"))
			gtHmmViterbi (hmm);
		else if (!strcasecmp(bestpathmode,"vit"))
			gtHmmViterbi (hmm);
		else if (!strcasecmp(bestpathmode,"1best"))
			gtHmmFirstBest (hmm);
		else if (!strcasecmp(bestpathmode,"onebest"))
			gtHmmFirstBest (hmm);
		else if (!strcasecmp(bestpathmode,"pv"))
			gtHmmPosteriorViterbi (hmm);
		else if (!strcasecmp(bestpathmode,"oad"))
			gtHmmOptimalAccuracyDecoding (hmm);
		else
			gtHmmViterbi (hmm);
	}else
		gtHmmViterbi (hmm);
	if (repsum!=NULL)
		gtHmmSumUp (hmm->model);


	int i = 0;
	int j = 0;
	int nt = 0;
	for (; i<hmm->len ; )
	{
		for (j = i; ( j<hmm->len
				&& hmm->out->seq[i] == hmm->out->seq[j] ); j++);
		if(isExperiment)
		{
			seqContext.addMethodHit(CCTOPLIB_METHOD_HMMTOP, i+1, j, parseCharLocalization(hmm->out->seq[i]));
		}else
		{
			seqContext.addCCTopTopology(i+1, j, parseCharLocalization(hmm->out->seq[i]));
		}
		if (hmm->out->seq[i]=='M')
			nt++;
		if (hmm->out->seq[i]=='N')
			nt--;
		i=j;
	}

	gtHmmCalculateReliability( hmm );

	if(!isExperiment)
		seqContext.setReliability(hmm->RELI);

	gtHmmFree(hmm);
}
