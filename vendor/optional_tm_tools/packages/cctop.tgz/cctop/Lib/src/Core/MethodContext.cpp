/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * TopDBEntry.cpp
 *
 *  Created on: 2014.07.09.
 *      Author: "Istvan Remenyi"
 */

#include "MethodContext.h"

#include <cstring>
#include <iostream>

CCTOP::Core::Localization CCTOP::Core::parseLocalization(const char* local)
{
	CCTOP::Core::Localization ret = LOCALIZATION_UNKNOWN;
	if(local)
	{
		if(!strcmp("Membrane", local))
		{
			ret = LOCALIZATION_MEMBRANE;
		}else
			if(!strcmp("Inside", local))
			{
				ret = LOCALIZATION_INSIDE;
			}else
				if(!strcmp("Outside", local))
				{
					ret = LOCALIZATION_OUTSIDE;
				}else
					if(!strcmp("Unknown", local))
					{
						ret = LOCALIZATION_UNKNOWN;
					}else
						if(!strcmp("Not Inside", local))
						{
							ret = LOCALIZATION_NOT_INSIDE;
						}else
							if(!strcmp("Not Outside", local))
							{
								ret = LOCALIZATION_NOT_OUTSIDE;
							}else
								if(!strcmp("Not Membrane", local))
								{
									ret = LOCALIZATION_NOT_MEMBRANE;
								}else
									if(!strcmp("Side1", local))
									{
										ret = LOCALIZATION_SIDE1;
									}else
										if(!strcmp("Side2", local))
										{
											ret = LOCALIZATION_SIDE2;
										}else
											if(!strcmp("Signal", local))
											{
												ret = LOCALIZATION_SIGNAL;
											}else
												if(!strcmp("Propeptide", local) || !strcmp("Propep", local))
												{
													ret = LOCALIZATION_PROPEPTIDE;
												}else
													if(!strcmp("Transit", local))
													{
														ret = LOCALIZATION_TRANSIT;
													}else
														if(!strcmp("Cleavable", local))
														{
															ret = LOCALIZATION_CLEAVABLE;
														}else
															if(!strcmp("Membloop", local))
															{
																ret = LOCALIZATION_MEMBLOOP;
															}else
																if(!strcmp("Membins", local))
																{
																	ret = LOCALIZATION_MEMBINS;
																}else
																	if(!strcmp("Interfacial", local))
																	{
																		ret = LOCALIZATION_INTERFACIAL;
																	}
	}
	return ret;
}

CCTOP::Core::Localization CCTOP::Core::parseCharLocalization(char local)
{
	CCTOP::Core::Localization loc = CCTOP::Core::LOCALIZATION_UNKNOWN;
	switch (local)
	{
	case 'o':
	case 'O':
		loc = CCTOP::Core::LOCALIZATION_OUTSIDE;
		break;
	case 'i':
	case 'I':
		loc = CCTOP::Core::LOCALIZATION_INSIDE;
		break;
	case 'M':
	case 'm':
	case '-':
		loc = CCTOP::Core::LOCALIZATION_MEMBRANE;
		break;
	case 'L':
	case 'l':
	case 'r':
	case 'R':
		loc = CCTOP::Core::LOCALIZATION_MEMBLOOP;
		break;
	case 'S':
	case 's':
		loc = CCTOP::Core::LOCALIZATION_SIGNAL;
		break;
	case 'T':
	case 't':
		loc = CCTOP::Core::LOCALIZATION_TRANSIT;
		break;
	case 'P':
	case 'p':
		loc = CCTOP::Core::LOCALIZATION_PROPEPTIDE;
		break;
	case 'F':
	case 'f':
		loc = CCTOP::Core::LOCALIZATION_INTERFACIAL;
		break;
	case '#':
		loc = CCTOP::Core::LOCALIZATION_UNKNOWN;
		break;
	default:
		std::cerr << "parseCharLocalization() error!! Undefined char (" << local << ")!" << std::endl;
		break;
	}
	return loc;
}

char CCTOP::Core::localizationToChar(Localization loc)
{
	char ret = '?';

	switch (loc)
	{
	case LOCALIZATION_OUTSIDE:
		ret = 'O';
		break;
	case LOCALIZATION_INSIDE:
		ret = 'I';
		break;
	case LOCALIZATION_MEMBRANE:
		ret = 'M';
		break;
	case LOCALIZATION_MEMBLOOP:
		ret = 'L';
		break;
	case LOCALIZATION_UNKNOWN:
		ret = '#';
		break;
	case LOCALIZATION_SIGNAL:
		ret = 'S';
		break;
	case LOCALIZATION_TRANSIT:
		ret = 'T';
		break;
	case LOCALIZATION_PROPEPTIDE:
		ret = 'P';
		break;
	case LOCALIZATION_INTERFACIAL:
		ret = 'F';
		break;
	default:
		std::cerr << "localizationToChar() error!! Undefined Localization (" << loc << ")!" << std::endl;
		break;
	}

	return ret;
}

CCTOP::Core::InOrOut CCTOP::Core::parseInOrOut(const char* local)
{
	InOrOut ret = IOO_ALTERNATE;

	if(!strcmp("Inside", local))
		ret = IOO_INSIDE;
	else
		if(!strcmp("Outside", local))
			ret = IOO_OUTSIDE;
		else
			if(!strcmp("Alternate", local))
				ret = IOO_ALTERNATE;

	return ret;
}

CCTOP::Core::TopDBEntry::TopDBEntry()
{}

CCTOP::Core::TopDBEntry::TopDBEntry(const TopDBEntry& copy)
{}

CCTOP::Core::TopDBEntry::~TopDBEntry()
{}

CCTOP::Core::TopDBEntry& CCTOP::Core::TopDBEntry::operator=(const TopDBEntry& copy)
{
	return *this;
}

void CCTOP::Core::TopDBEntry::setName(const std::string& name)
{
	_name = name;
}

void CCTOP::Core::TopDBEntry::setId(const std::string& id)
{
	_id = id;
}

void CCTOP::Core::TopDBEntry::setUniProtId(const std::string& id)
{
	_uniProtId = id;
}

void CCTOP::Core::TopDBEntry::setAminoSeq(const std::string& aminoSequence)
{
	_aminoSequence = aminoSequence;
}

void CCTOP::Core::TopDBEntry::addUniProtAC(const std::string& id)
{
	_uniProtACs.push_back(id);
}

void CCTOP::Core::TopDBEntry::addPDBEntry(const std::string& id, InOrOut pdbLocl, const std::map< std::string, std::vector<PDBFragment> >& chains)
{
	PDBEntry entry;

	entry.id = id;
	entry.pdbLocl = pdbLocl;
	entry.chains = chains;

	std::map<std::string, std::vector<PDBEntry> >::iterator iter = _pdbEntries.find(id);
	if(iter == _pdbEntries.end())
	{
		std::vector<PDBEntry> vec;
		vec.push_back(entry);
		_pdbEntries[id] = vec;
	}else
	{
		iter->second.push_back(entry);
	}

}

void CCTOP::Core::TopDBEntry::addTopologyEntry(const TopologyEntry& topEntry)
{
//	std::cerr << "Add topology: " << topEntry.beg << " - " << topEntry.end << std::endl;

	std::vector<TopologyEntry>::iterator iter = _topologyEntries.begin();
	bool has = false;
	while(iter != _topologyEntries.end()
			&& !(has = (topEntry.beg == iter->beg
					&& topEntry.end == iter->end
					&& topEntry.loc == iter->loc)))
	{
		iter++;
	}
	if(!has)
	{
		_topologyEntries.push_back(topEntry);
	}
}

void CCTOP::Core::TopDBEntry::addExperimentEntry(const ExperimentEntry& topEntry)
{
	_experimentEntries.push_back(topEntry);
}

const CCTOP::Core::PDBEntry* CCTOP::Core::TopDBEntry::getPDBEntry(const std::string& pdbId, const std::string& chainId) const
{
	const CCTOP::Core::PDBEntry* ret = NULL;

	std::map<std::string, std::vector<PDBEntry> >::const_iterator iter = _pdbEntries.find(pdbId);
	if(iter != _pdbEntries.end())
	{
		std::vector<PDBEntry>::const_iterator eIter = iter->second.begin();
		while(!ret && eIter != iter->second.end())
		{
			std::map< std::string, std::vector<PDBFragment> >::const_iterator chainIter = eIter->chains.find(chainId);
			if(chainIter != eIter->chains.end())
			{
				ret = &*eIter;
			}

			eIter++;
		}
	}

	return ret;
}

std::vector<CCTOP::Core::TopologyEntry>& CCTOP::Core::TopDBEntry::getTopologyEntries() const
{
	return _topologyEntries;
}

std::vector<CCTOP::Core::ExperimentEntry>& CCTOP::Core::TopDBEntry::getExperimentEntries() const
{
	return _experimentEntries;
}

CCTOP::Core::MethodContext::MethodContext() : _activeMembrain(false)
{
	_state = CONTEXTSTATE_UNDEFINED;
}

CCTOP::Core::MethodContext::MethodContext(const MethodContext& copy) : _activeMembrain(false)
{
	_state = CONTEXTSTATE_UNDEFINED;
}

CCTOP::Core::MethodContext::~MethodContext()
{
	std::map<std::string, TopDBEntry*>::iterator iter = _topDBEntries.begin();
	while(iter != _topDBEntries.end())
	{
		delete iter->second;
		iter++;
	}
}

CCTOP::Core::MethodContext& CCTOP::Core::MethodContext::operator=(const MethodContext& copy)
{
	return *this;
}


void CCTOP::Core::MethodContext::activateMembrain(bool active)
{
	_activeMembrain = active;
}

bool CCTOP::Core::MethodContext::isMembrainActive() const
{
	return _activeMembrain;
}


CCTOP::Core::TopDBEntry* CCTOP::Core::MethodContext::createTopDBEntry(const std::string& topDBId)
{
	CCTOP::Core::TopDBEntry* ret = NULL;

	std::map<std::string, TopDBEntry*>::iterator iter = _topDBEntries.find(topDBId);
	if(iter != _topDBEntries.end())
	{
		ret = iter->second;
	}else
	{
		ret = new TopDBEntry();
		ret->setId(topDBId);
		_topDBEntries[topDBId] = ret;
	}

	return ret;
}


CCTOP::Core::TopDBEntry* CCTOP::Core::MethodContext::getTopDBEntry(const std::string& topDBId) const
{
	CCTOP::Core::TopDBEntry* ret = NULL;

	std::map<std::string, TopDBEntry*>::const_iterator iter = _topDBEntries.find(topDBId);
	if(iter != _topDBEntries.end())
	{
		ret = iter->second;
	}

	return ret;
}
