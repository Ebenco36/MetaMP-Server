/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CCTopLib.h
 *
 *  Created on: 2014.07.04.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CCTOPLIB_H_
#define CCTOP_CCTOPLIB_H_

#include "Core/MethodContext.h"
#include "Core/SequenceContext.h"

#include "Core/External/BlastParser.h"
#include "Core/External/SignalParser.h"
#include "Core/External/MethodParser.h"
#include "Core/External/TopDBParser.h"
#include "Core/External/UniProtParser.h"
#include "Core/External/HMMTopLink.h"

#include <map>
#include <cstdio>
#include <sstream>

namespace CCTOP {

class CCTopLib
{
protected:
	Core::MethodContext				_methodContext;

	Core::External::BlastParser 	_blastParser;
	Core::External::MethodParser 	_methodParser;
	Core::External::SignalParser	_signalParser;
	Core::External::TopDBParser		_topDBParser;
	Core::External::UniProtParser	_uniProtParser;
	Core::External::HMMTopLink		_hmmTopLink;

	std::map<std::string, std::string>		_libParams;
	std::map<std::string, double>			_additionalParams;
	std::map<std::string, std::map<std::string, double> > _weights;

	void preProcessFile(Core::SequenceContext& seqContext) const;

	void blastUniProt(Core::SequenceContext& seqContext) const;
	void blastAndMergeTopDB(Core::SequenceContext& seqContext) const;

	void propeptideUPSearch(Core::SequenceContext& seqContext) const;
	void transitUPSearch(Core::SequenceContext& seqContext) const;
	void signalUPSearch(Core::SequenceContext& seqContext) const;

	void transitRegionReduction(Core::SequenceContext& seqContext) const;
	void signalRegionReduction(Core::SequenceContext& seqContext) const;

public:

	std::string getLibParam(const std::string& key) const;
	double getAdditionalParam(const std::string& key) const;
	double getWeight(const std::string& key, const std::string& type) const;

	void methodCallTMHMM(Core::SequenceContext& seqContext) const;
	void methodCallPhobious(Core::SequenceContext& seqContext) const;
	void methodCallPhilius(Core::SequenceContext& seqContext) const;
	void methodCallMemBrain(Core::SequenceContext& seqContext) const;
	void methodCallTOPCONS(Core::SequenceContext& seqContext) const;
	void methodCallScampi(Core::SequenceContext& seqContext) const;
	void methodCallMemsat(Core::SequenceContext& seqContext) const;
	void methodCallTopDom(Core::SequenceContext& seqContext) const;

	void methodCallScampiMsa(Core::SequenceContext& seqContext, const std::string& tmpDir) const;
	void methodCallProAndProDiv(Core::SequenceContext& seqContext, const std::string& tmpDir) const;
	void methodCallOctopus(Core::SequenceContext& seqContext, const std::string& tmpDir) const;
	void methodCallScampi(Core::SequenceContext& seqContext, const std::string& tmpDir) const;


	CCTopLib();
	CCTopLib(const CCTopLib& copy);
	~CCTopLib();
	CCTopLib& operator=(const CCTopLib& copy);
	Core::MethodContext& getMethodContext();

	bool loadParams(const std::string& paramFile);
	void initialize(bool ignoreMinMax, bool duplicationEnabled);
	void hackMemBrain(const std::string& incomingHash, std::string& textId) const;

	void preProcess(Core::SequenceContext& seqContext) const;
	void process(Core::SequenceContext& seqContext, std::string& result) const;
	void update(Core::SequenceContext& seqContext, const std::string& oldResultFile, std::string& result) const;
	bool tmFilter(Core::SequenceContext& seqContext) const;
};

}

#endif /* CCTOP_CCTOPLIB_H_ */
