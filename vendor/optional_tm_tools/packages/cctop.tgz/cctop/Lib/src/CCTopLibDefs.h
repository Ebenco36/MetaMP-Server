/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CCTopLibDefs.h
 *
 *  Created on: 2014.07.03.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOPLIBDEFS_H_
#define CCTOPLIBDEFS_H_

#define CCTOPLIB_VERSION 1


#define CCTOPLIB_METHOD_OCTOPUS		"Octopus"
#define CCTOPLIB_METHOD_MEMSAT		"Memsat"


#define CCTOPLIB_METHOD_HMMTOP		"HMMTOP"
#define CCTOPLIB_METHOD_SCAMPIMSA	"ScampiMsa"
#define CCTOPLIB_METHOD_PRO			"Pro"
#define CCTOPLIB_METHOD_PRODIV		"Prodiv"
#define CCTOPLIB_METHOD_SCAMPI		"Scampi"
#define CCTOPLIB_METHOD_MEMBRAIN	"MemBrain"
#define CCTOPLIB_METHOD_PHILIUS		"Philius"
#define CCTOPLIB_METHOD_PHOBIOUS	"Phobius"
#define CCTOPLIB_METHOD_TMHMM		"TMHMM"
#define CCTOPLIB_METHOD_TOPDOM		"TOPDOM"
#define CCTOPLIB_METHOD_TOPDB		"TOPDB"

#endif /* CCTOPLIBDEFS_H_ */
