/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CacheManager.cpp
 *
 *  Created on: 2014.07.01.
 *      Author: "Istvan Remenyi"
 */

#include "CacheManager.h"

#include "../Utils/Hash/md5.h"

#include <algorithm>
#include <fstream>
#include <sstream>

#include <dirent.h>
#include <unistd.h>
#include <cstring>
#include <sys/types.h>
#include <sys/stat.h>


const char* CCTOP::Cache::CacheManager::PATTERN_INPUT		= "input_";
const char* CCTOP::Cache::CacheManager::PATTERN_RESULT		= "result_";
const int	CCTOP::Cache::CacheManager::PATTERN_INPUT_LEN	= strlen(CCTOP::Cache::CacheManager::PATTERN_INPUT);
const int 	CCTOP::Cache::CacheManager::PATTERN_RESULT_LEN	= strlen(CCTOP::Cache::CacheManager::PATTERN_RESULT);

CCTOP::Cache::CacheManager CCTOP::Cache::CacheManager::_cacheManager("");

CCTOP::Cache::CacheManager::CacheManager()
: _rootFolder("")
{}

CCTOP::Cache::CacheManager::CacheManager(const std::string& cacheDir)
: _rootFolder(cacheDir)
{
	struct stat fileInfo;
	if(!stat(cacheDir.c_str(), &fileInfo))
	{
		if ((fileInfo.st_mode & S_IFMT) != S_IFDIR)
		{
			_rootFolder = ".";
			std::cerr << "Invalid cachedir: " << cacheDir << ". Using \".\" instead." << std::endl;
		}
	}
}

CCTOP::Cache::CacheManager::CacheManager(const CacheManager& copy)
: _rootFolder(copy._rootFolder)
{}

CCTOP::Cache::CacheManager::~CacheManager()
{}

CCTOP::Cache::CacheManager& CCTOP::Cache::CacheManager::operator=(const CacheManager& copy)
{
	_rootFolder = copy._rootFolder;
	return *this;
}

CCTOP::Cache::CacheManager& CCTOP::Cache::CacheManager::instance()
{
	return _cacheManager;
}

void CCTOP::Cache::CacheManager::setRootFolder(const std::string& folder)
{
	_rootFolder = folder;
}

std::string CCTOP::Cache::CacheManager::generateChecksumForStream(FILE* file) const
{
	//MD5 checksum for streams
	MD5 md5Context(file);
	char* temp = md5Context.hex_digest();
	std::string ret(temp);
	delete[] temp;
	return ret;
}

//std::string CCTOP::Cache::CacheManager::generateChecksumForStream(std::basic_ifstream<unsigned char>& stream) const
//{
//	//MD5 checksum for streams
//	MD5 md5Context(stream);
//	char* temp = md5Context.hex_digest();
//	std::string ret(temp);
//	delete[] temp;
//	return ret;
//}

bool CCTOP::Cache::CacheManager::equalFiles(std::ifstream& in1, std::ifstream& in2) const
{
	std::ifstream::pos_type size1, size2;

	size1 = in1.seekg(0, std::ifstream::end).tellg();
	in1.seekg(0, std::ifstream::beg);

	size2 = in2.seekg(0, std::ifstream::end).tellg();
	in2.seekg(0, std::ifstream::beg);

	bool ret = false;
	if((ret = size1 == size2))
	{
		static const size_t BLOCKSIZE = 4096;
		size_t remaining = size1;

		while(remaining && ret)
		{
			char buffer1[BLOCKSIZE], buffer2[BLOCKSIZE];
			size_t size = std::min(BLOCKSIZE, remaining);

			in1.read(buffer1, size);
			in2.read(buffer2, size);

			ret &= !memcmp(buffer1, buffer2, size);

		remaining -= size;
		}
	}
	return ret;
}

bool CCTOP::Cache::CacheManager::copyFiles(std::ifstream& in, std::ofstream& out) const
{
	out << in.rdbuf();
	return true;
}

bool CCTOP::Cache::CacheManager::waitForChecksumLock(const std::string& checksum) const
{
	bool ret = false;

	while(!ret)
	{
		_lock.lock();

		std::vector<std::string>::iterator iter;
		if((iter = std::find(_lockedChecksums.begin(), _lockedChecksums.end(), checksum)) == _lockedChecksums.end())
		{
			_lockedChecksums.push_back(checksum);
			ret = true;
		}
		_lock.unlock();

		if(!ret)
		{
			sleep(1);
		}
	}

	return ret;
}

void CCTOP::Cache::CacheManager::removeChecksumLock(const std::string& checksum) const
{
	_lock.lock();

	std::vector<std::string>::iterator iter;
	while((iter = std::find(_lockedChecksums.begin(), _lockedChecksums.end(), checksum)) != _lockedChecksums.end())
	{
		_lockedChecksums.erase(iter);
	}

	_lock.unlock();
}

bool CCTOP::Cache::CacheManager::isChecksumLocked(const std::string& checksum) const
{
	bool ret = false;

	_lock.lock();

	ret = std::find(_lockedChecksums.begin(), _lockedChecksums.end(), checksum) != _lockedChecksums.end();

	_lock.unlock();

	return ret;
}


bool CCTOP::Cache::CacheManager::generateNewEntry(const std::string& checksum, std::string& cInputPath, std::string& cResultPath) const
{
	bool ret = false;

	if(!checksum.empty())
	{
		std::string folder = _rootFolder + "/" + checksum;
		//check folder existence
		if(access( folder.c_str(), R_OK|W_OK ) == -1)
		{
			mkdir(folder.c_str(), 0777);
		}

		//check for empty index
		int index = 0;
		std::string indexAsStr;
		while(!ret && index >= 0)
		{
			index++;

			std::stringstream sstream;
			sstream << index;
			cInputPath = _rootFolder + "/" + checksum + "/" + PATTERN_INPUT + sstream.str();
			if((ret = access( cInputPath.c_str(), R_OK|W_OK ) == -1))
				indexAsStr = sstream.str();
		}

		if(ret)
		{
			cResultPath = _rootFolder + "/" + checksum + "/" + PATTERN_RESULT + indexAsStr;
		}
	}else
		std::cerr << "Checksum failed!" << std::endl;

	return ret;
}


bool CCTOP::Cache::CacheManager::isExists(const std::string& inputPath, const std::string& checksum, std::string& cInputPath, std::string& cResultPath) const
{
	bool ret = false;
	cInputPath = "";

	std::ifstream stream(inputPath.c_str());
	if(stream.is_open())
	{
		if(!checksum.empty())
		{
			std::string folder = _rootFolder + "/" + checksum;

			//check folder existence
			struct stat fileInfo;
			if(!stat(folder.c_str(), &fileInfo))
			{
				if (S_ISDIR(fileInfo.st_mode))
				{
					//check every file content in folder, checksum could be same for more seqs!
					struct dirent* entry;
					DIR* dir;
					dir = opendir(folder.c_str());
					if(dir)
					{
						struct stat st;
						while (!ret && ((entry = readdir (dir)) != NULL))
						{
							//inputs
							if(!strncmp(entry->d_name, PATTERN_INPUT, PATTERN_INPUT_LEN))
							{
								stat(entry->d_name, &st);
								if(!S_ISDIR(st.st_mode))
								{
//									std::cout << "\tChecking File: " << entry->d_name << std::endl;
									stream.seekg(0); // rewind

									cInputPath = folder + "/" + entry->d_name;
									std::ifstream resStream(cInputPath.c_str());
									if(resStream.is_open() && equalFiles(stream, resStream))
									{
										cResultPath = folder + "/" + PATTERN_RESULT + (entry->d_name + PATTERN_INPUT_LEN);
										ret = (!stat(cInputPath.c_str(), &fileInfo));
//										std::cout << "\tResult File: " << cInputPath << std::endl;
									}
									resStream.close();
								}
							}
						}
						closedir(dir);
					}
				}else
				{
					std::cerr << "The checksum folder exits \"" << folder << "\", but it is a file." << std::endl;
				}
			}
		}else
			std::cerr << "Checksum failed!" << std::endl;
	}else
		std::cerr << "Input file \"" << inputPath << "\" does not exist!" << std::endl;

	stream.close();
	return ret;
}

bool CCTOP::Cache::CacheManager::cacheContent(const std::string& inputPath, const std::string& resultPath, std::string& cInputPath, std::string& cResultPath) const
{
	bool ret = false;

	//Check for the existence

	FILE* pFile = fopen (inputPath.c_str(), "r");
	if (pFile)
	{
		std::string checksum = generateChecksumForStream(pFile);

		waitForChecksumLock(checksum);

		if(!isExists(inputPath, checksum, cInputPath, cResultPath))
		{
			if((ret = generateNewEntry(checksum, cInputPath, cResultPath)))
			{
				std::ifstream inIStream(inputPath.c_str());
				std::ofstream outIStream(cInputPath.c_str());

				if(inIStream.is_open()
						&& outIStream.is_open())
				{
					ret = copyFiles(inIStream, outIStream);
				}

				if(ret)
				{
					std::ifstream inRStream(resultPath.c_str());
					std::ofstream outRStream(cResultPath.c_str());

					if(inRStream.is_open()
							&& outRStream.is_open())
					{
						ret = copyFiles(inRStream, outRStream);
					}


					inRStream.close();
					outRStream.close();
				}

				inIStream.close();
				outIStream.close();
			}
		}
		removeChecksumLock(checksum);
		fclose (pFile);
	}

	return ret;
}

bool CCTOP::Cache::CacheManager::updateContent(const std::string& inputPath, const std::string& resultPath, std::string& cInputPath, std::string& cResultPath, const std::string& checksum) const
{
	bool ret = false;

	//Check for the existence
	FILE* pFile = fopen (inputPath.c_str(), "r");
	if (pFile)
	{
		waitForChecksumLock(checksum);

		if(!isExists(inputPath, checksum, cInputPath, cResultPath))
		{
			generateNewEntry(checksum, cInputPath, cResultPath);
		}

		std::ifstream inIStream(inputPath.c_str());
		std::ofstream outIStream(cInputPath.c_str());

		if(inIStream.is_open() && outIStream.is_open())
		{
			ret = copyFiles(inIStream, outIStream);
		}

		if(ret)
		{
			std::ifstream inRStream(resultPath.c_str());
			std::ofstream outRStream(cResultPath.c_str());

			if(inRStream.is_open() && outRStream.is_open())
			{
				ret = copyFiles(inRStream, outRStream);
			}

			inRStream.close();
			outRStream.close();
		}

		inIStream.close();
		outIStream.close();

		removeChecksumLock(checksum);
		fclose (pFile);
	}

	return ret;
}

bool CCTOP::Cache::CacheManager::serveContent(const std::string& inputPath, const std::string& resultPath, std::string& checksum) const
{
	bool ret = false;

	FILE* pFile = fopen (inputPath.c_str(), "r");
	if (pFile)
	{
		std::string checksum = generateChecksumForStream(pFile);

		waitForChecksumLock(checksum);

		//Check for the existence
		std::string cInputPath;
		std::string cResultPath;
		ret = isExists(inputPath, checksum, cInputPath, cResultPath);

		if(ret)
		{
			std::ifstream inRStream(cResultPath.c_str());
			std::ofstream outRStream(resultPath.c_str());

			if(inRStream.is_open()
					&& outRStream.is_open())
			{
				ret = copyFiles(inRStream, outRStream);
			}

			inRStream.close();
			outRStream.close();
		}

		removeChecksumLock(checksum);
		fclose (pFile);
	}


	return ret;
}

bool CCTOP::Cache::CacheManager::removeContent(const std::string& inputPath, std::string& checksum) const
{
	bool ret = false;

	std::ifstream stream(inputPath.c_str());
	if(stream.is_open())
	{
		if(!checksum.empty())
		{
			std::string folder = _rootFolder + "/" + checksum;

			//check folder existence
			struct stat fileInfo;
			if(!stat(folder.c_str(), &fileInfo))
			{
				if (S_ISDIR(fileInfo.st_mode))
				{
					//check every file content in folder, checksum could be same for more seqs!
					struct dirent* entry;
					DIR* dir;
					dir = opendir(folder.c_str());
					if(dir)
					{
						struct stat st;
						while (!ret && ((entry = readdir (dir)) != NULL))
						{
							//inputs
							if(!strncmp(entry->d_name, PATTERN_INPUT, PATTERN_INPUT_LEN))
							{
								stat(entry->d_name, &st);
								if(!S_ISDIR(st.st_mode))
								{
									stream.seekg(0); // rewind

									std::string cInputPath = folder + "/" + entry->d_name;
									std::ifstream resStream(cInputPath.c_str());
									if(resStream.is_open() && equalFiles(stream, resStream))
									{
										resStream.close();
										remove(cInputPath.c_str());
										ret = true;

										std::string cResultPath = folder + "/" + PATTERN_RESULT + (entry->d_name + PATTERN_INPUT_LEN);
										if(!stat(cResultPath.c_str(), &fileInfo))
										{
											remove(cResultPath.c_str());
										}
									}
								}
							}
						}
						closedir(dir);
					}
				}else
				{
					std::cerr << "The checksum folder exits \"" << folder << "\", but it is a file." << std::endl;
				}
			}
		}else
			std::cerr << "Checksum failed!" << std::endl;
	}else
		std::cerr << "Input file \"" << inputPath << "\" does not exist!" << std::endl;

	stream.close();
	return ret;
}

bool CCTOP::Cache::CacheManager::lockChecksum(const std::string& checksum) const
{
	bool ret = true;
	if(!checksum.empty())
	{
		waitForChecksumLock(checksum);

		std::string folder = _rootFolder + "/" + checksum;
		//check folder existence
		if(access( folder.c_str(), R_OK|W_OK ) == -1)
		{
			mkdir(folder.c_str(), 0777);
		}

		std::string lockFolder = _rootFolder + "/" + checksum + "/.lock";
		//wait folder
		while(access( lockFolder.c_str(), R_OK|W_OK ) != -1)
		{
			sleep(20);
		}
		//recheck - just in case :)
		if(access( folder.c_str(), R_OK|W_OK ) == -1)
		{
			mkdir(folder.c_str(), 0777);
		}
		mkdir(lockFolder.c_str(), 0777);

		removeChecksumLock(checksum);
	}

	return ret;
}

bool CCTOP::Cache::CacheManager::unlockChecksum(const std::string& checksum) const
{
	bool ret = true;
	if(!checksum.empty())
	{
		waitForChecksumLock(checksum);

		std::string folder = _rootFolder + "/" + checksum;
		//check folder existence
		if(access( folder.c_str(), R_OK|W_OK ) != -1)
		{
			folder = _rootFolder + "/" + checksum + "/.lock";
			if(access( folder.c_str(), R_OK|W_OK ) != -1)
				rmdir(folder.c_str());
		}

		removeChecksumLock(checksum);
	}

	return ret;
}
