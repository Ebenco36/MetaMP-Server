/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CacheManager.h
 *
 *  Created on: 2014.07.01.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_CACHE_FOLDERMANAGER_H_
#define CCTOP_CACHE_FOLDERMANAGER_H_

#include "../Utils/Threading/Mutex.h"

#include <string>
#include <vector>

namespace CCTOP { namespace Cache {


class CacheManager
{
protected:
	static const char*	PATTERN_INPUT;
	static const char*	PATTERN_RESULT;
	static const int	PATTERN_INPUT_LEN;
	static const int	PATTERN_RESULT_LEN;

	static CacheManager				_cacheManager;

	std::string						_rootFolder;
	mutable
	CCTOP::Utils::Threading::Mutex	_lock;
	mutable
	std::vector<std::string>		_lockedChecksums;

	CacheManager();
	CacheManager(const std::string& cacheDir);
	CacheManager(const CacheManager& copy);
	~CacheManager();
	CacheManager& operator=(const CacheManager& copy);


	bool equalFiles(std::ifstream& in1, std::ifstream& in2) const;
	bool copyFiles(std::ifstream& in, std::ofstream& out) const;

	bool waitForChecksumLock(const std::string& checksum) const;
	void removeChecksumLock(const std::string& checksum) const;
	bool isChecksumLocked(const std::string& checksum) const;

	bool generateNewEntry(const std::string& checksum, std::string& cInputPath, std::string& cResultPath) const;

public:
	static CacheManager& instance();

	void setRootFolder(const std::string& string);

	std::string generateChecksumForStream(FILE* stream) const;
//	std::string generateChecksumForStream(std::basic_ifstream<unsigned char>& stream) const;
	//check the existence
	bool isExists(const std::string& inputPath, const std::string& checksum, std::string& cInputPath, std::string& cResultPath) const;
	//create cache entry, and return path to the contents
	bool cacheContent(const std::string& inputPath, const std::string& resultPath, std::string& cInputPath, std::string& cResultPath) const;
	//updazta cache entry, and return path to the contents
	bool updateContent(const std::string& inputPath, const std::string& resultPath, std::string& cInputPath, std::string& cResultPath, const std::string& checksum) const;
	//copy content to a given place (resultpath)
	bool serveContent(const std::string& inputPath, const std::string& resultPath, std::string& checksum) const;
	//copy content to a given place (resultpath)
	bool removeContent(const std::string& inputPath, std::string& checksum) const;
	//lock the folder
	bool lockChecksum(const std::string& checksum) const;
	//unlock the folder
	bool unlockChecksum(const std::string& checksum) const;
};


}}


#endif /* CCTOP_CACHE_FOLDERMANAGER_H_ */
