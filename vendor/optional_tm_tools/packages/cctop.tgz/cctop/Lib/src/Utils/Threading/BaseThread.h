/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * BaseThread.h
 *
 *  Created on: Aug 8, 2013
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_UTILS_THREADING_BASETHREAD_H_
#define CCTOP_UTILS_THREADING_BASETHREAD_H_

#include <pthread.h>

#include "Mutex.h"

namespace CCTOP { namespace Utils { namespace Threading {


enum ThreadState
{
	THREADSTATE_INITIALIZED,
	THREADSTATE_RUNNING,
	THREADSTATE_IDLE,
	THREADSTATE_PAUSED,
	THREADSTATE_FORCED,
	THREADSTATE_STOPPED
};


/* BaseThread: class
 *  A POSIX based thread implementation
 */
class BaseThread
{
protected:
	pthread_t 	_threadId;
	ThreadState	_status;
	Mutex		_threadLock;

	static void* callThreadMemberFunction(void *arg);

	virtual void* run();
public:
	BaseThread();
	virtual ~BaseThread();

	virtual void start();
	virtual void stop();

	virtual void join(void** returnValue);
	virtual void detach();
};

}}} //namespace Core::Utils::Threading

#endif /* CCTOP_UTILS_THREADING_BASETHREAD_H_ */
