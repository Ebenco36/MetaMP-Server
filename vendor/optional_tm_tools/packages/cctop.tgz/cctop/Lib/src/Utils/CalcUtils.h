/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CalcUtils.h
 *
 *  Created on: 2014.07.14.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_UTILS_CALCUTILS_H_
#define CCTOP_UTILS_CALCUTILS_H_


namespace CCTOP { namespace Utils {




inline
void removeRegion(int& beg, int& end, int remFrom, int remTo)
{
    int delta = remTo - remFrom + 1;
	//1.exp contains querypart
	if(beg <= remFrom
			&& end >= remTo)
	{
		end -= delta;
	}else
		//2.overlap right
		if(beg <= remFrom
				&& end <= remTo
				&& end >= remFrom)
		{
			end -= end-remFrom+1;
		}else
			//3.overlap left
			if(beg >= remFrom
					&& end >= remTo
					&& beg <= remTo)
			{
				beg = remFrom;
				end -= delta;
			}else
				//4.querypart contains exp
				if(beg >= remFrom
						&& end <= remTo)
				{
					beg = -1;
					end = -1;
				}else
					//5.querypart before exp
					if(remTo <= beg)
					{
						beg -= delta;
						end -= delta;
					}
}

inline
void addRegion(int& beg, int& end, int addFrom, int addTo)
{
	int delta = addTo - addFrom + 1;
	//1.exp contains queryparts
	if(beg <= addFrom
			&& end >= addTo)
	{
	}else
		//2.overlap right
		if(beg <= addFrom
				&& end <= addTo
				&& end >= addFrom)
		{
			end = addTo;
		}else
			//3.overlap left
			if(beg >= addFrom
					&& end >= addTo
					&& beg <= addTo)
			{
				beg = addFrom;
			}else
				//4.querypart contains exp
				if(beg >= addFrom
						&& end <= addTo)
				{
					beg = addFrom;
					end = addTo;
				}else
					//5.querypart before exp
					if(addTo <= beg)
					{
						beg += delta;
						end += delta;
					}
}

inline
void insertRegion(int& beg, int& end, int addFrom, int addTo)
{
	int delta = addTo - addFrom + 1;

	if(beg >= addFrom)
	{
		beg += delta;
		end += delta;
	}
}

}}

#endif /* CCTOP_UTILS_CALCUTILS_H_ */
