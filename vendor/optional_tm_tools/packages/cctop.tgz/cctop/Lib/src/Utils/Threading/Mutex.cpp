/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Mutex.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: "Istvan Remenyi"
 */

#include "Mutex.h"


CCTOP::Utils::Threading::Mutex::Mutex()
{
	pthread_mutex_init (&_mLock, NULL);
}

CCTOP::Utils::Threading::Mutex::Mutex(const Mutex& copy)
{}

CCTOP::Utils::Threading::Mutex::~Mutex()
{
	pthread_mutex_destroy (&_mLock);
}

CCTOP::Utils::Threading::Mutex& CCTOP::Utils::Threading::Mutex::operator=(const CCTOP::Utils::Threading::Mutex& copy)
{
	return *this;
}

void CCTOP::Utils::Threading::Mutex::lock()
{
	pthread_mutex_lock (&_mLock);
}

void CCTOP::Utils::Threading::Mutex::unlock()
{
	pthread_mutex_unlock (&_mLock);
}
