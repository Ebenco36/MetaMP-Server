/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * BaseThread.cpp
 *
 *  Created on: Aug 8, 2013
 *      Author: "Istvan Remenyi"
 */

#include "BaseThread.h"

#include <cstdio>
#include <cstring>
#include <iostream>
#include <pthread.h>



void* CCTOP::Utils::Threading::BaseThread::callThreadMemberFunction(void *arg)
{
	return ((CCTOP::Utils::Threading::BaseThread*)arg)->run();
}

CCTOP::Utils::Threading::BaseThread::BaseThread()
: _threadId(0), _status(THREADSTATE_STOPPED)
{}

CCTOP::Utils::Threading::BaseThread::~BaseThread()
{
	stop();
}

void* CCTOP::Utils::Threading::BaseThread::run()
{
	_status = THREADSTATE_STOPPED;
	return NULL;
}

void CCTOP::Utils::Threading::BaseThread::start()
{
	_threadLock.lock();
	if(!_threadId)
	{
		_status = THREADSTATE_INITIALIZED;
		int err = pthread_create(&_threadId, NULL, &callThreadMemberFunction, this);
		if (err != 0)
		{
			_threadId = 0;
			std::cout << "can't create thread :" << std::strerror(err) << std::endl;
			_status = THREADSTATE_STOPPED;
		}
	}
	_threadLock.unlock();
}

void CCTOP::Utils::Threading::BaseThread::stop()
{
	_threadLock.lock();
	if(_status != THREADSTATE_STOPPED) _status = THREADSTATE_STOPPED;
	_threadLock.unlock();
}

void CCTOP::Utils::Threading::BaseThread::join(void** returnValue)
{
	if (_threadId)
	{
		pthread_join(_threadId, returnValue);
		_threadId = 0;
		_status = THREADSTATE_STOPPED;
	}
}

void CCTOP::Utils::Threading::BaseThread::detach()
{
	if (_threadId)
	{
		pthread_detach(_threadId);
		_threadId = 0;
		_status = THREADSTATE_STOPPED;
	}
}
