/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Mutex.h
 *
 *  Created on: Aug 13, 2013
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_UTILS_THREADING_MUTEX_H_
#define CCTOP_UTILS_THREADING_MUTEX_H_

#include <pthread.h>

namespace CCTOP { namespace Utils { namespace Threading {

/* Mutex : class
 *	Implementation of exc. mech.
 */
class Mutex
{
protected:
	pthread_mutex_t	_mLock;

public:
	Mutex();
	Mutex(const Mutex& copy);
	~Mutex();
	Mutex& operator=(const Mutex& copy);


	void lock();
	void unlock();
};

}}} // namespace Core::Utils::Threading

#endif /* CCTOP_UTILS_THREADING_MUTEX_H_ */
