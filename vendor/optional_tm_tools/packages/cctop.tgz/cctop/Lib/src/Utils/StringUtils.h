/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * StringUtils.h
 *
 *  Created on: 2014.07.08.
 *      Author: "Istvan Remenyi"
 */

#ifndef CCTOP_UTILS_STRINGUTILS_H_
#define CCTOP_UTILS_STRINGUTILS_H_

#include <string>
#include <cstring>
#include <sstream>
#include <fstream>

namespace CCTOP { namespace Utils {

/*class StringUtils
{
protected:

	StringUtils(){}
	StringUtils(const StringUtils& copy){}
	~StringUtils(){}
	StringUtils& operator=(const StringUtils& copy){return *this;}

public:
};*/

inline std::string replaceString(std::string subject, const std::string& search,
		const std::string& replace)
{
	size_t pos = 0;
	while ((pos = subject.find(search, pos)) != std::string::npos)
	{
		subject.replace(pos, search.length(), replace);
		pos += replace.length();
	}
	return subject;
}

inline void replaceStringInPlace(std::string& subject, const std::string& search,
		const std::string& replace)
{
	size_t pos = 0;
	while ((pos = subject.find(search, pos)) != std::string::npos)
	{
		subject.replace(pos, search.length(), replace);
		pos += replace.length();
	}
}

inline void saveFile(const std::string& fileName, const std::string& content)
{
	std::ofstream ostr(fileName.c_str());
	if(ostr.is_open())
	{
		ostr << content;
		ostr.close();
	}
}

inline void loadFile(const std::string& fileName, std::string& content)
{
	std::ifstream istr(fileName.c_str());
	if(istr.is_open())
	{
		std::stringstream str;
		std::string line;
		while ( getline (istr,line) )
		{
			str << line << std::endl;
		}
		istr.close();
		content = str.str();
	}
}

inline void loadFirstLine(const std::string& fileName, std::string& content)
{
	std::ifstream istr(fileName.c_str());
	if(istr.is_open())
	{
		std::stringstream str;
		std::string line;
		if( getline (istr,line) )
		{
			str << line;
		}
		istr.close();
		content = str.str();
	}
}

inline void copyFile(const std::string& inputPath, const std::string& outputPath)
{
	std::ifstream inIStream(inputPath.c_str());
	std::ofstream outIStream(outputPath.c_str());

	if(inIStream.is_open()
			&& outIStream.is_open())
	{
		outIStream << inIStream.rdbuf();
	}
	inIStream.close();
	outIStream.close();
}

inline std::vector<std::string>& split(const std::string &s, char delim,
		std::vector<std::string> &elems)
{
	std::stringstream ss(s);
	std::string item;
	while (std::getline(ss, item, delim))
	{
		elems.push_back(item);
	}
	return elems;
}

inline std::vector<std::string>& splitSafe(const std::string &s, char delim,
		std::vector<std::string> &elems)
{
	std::stringstream ss(s);
	std::string item;
	while (std::getline(ss, item, delim))
	{
		if(item.length() && (item.length() > 1 || item[0] != delim))
			elems.push_back(item);
	}
	return elems;
}

inline int indexOfFirstNthValid(const std::string& str, char invalid, int n)
{
	int index = 0;
	while((int)str.length() > index && n>0)
	{
		if(str.at(index) != invalid)
		{
			n--;
		}
		index++;
	}

	return n==0 ? index : -1;
}

inline std::string executeCommand(const char* cmd)
{
	FILE* pipe = popen(cmd, "r");
	std::string result;
	if (pipe)
	{
		std::stringstream str;

		char buffer[128];
		buffer[127] = '\0';
		while(!feof(pipe))
		{
			if(fgets(buffer, 127, pipe) != NULL)
				str << buffer;
		}
		pclose(pipe);

		result = str.str();
	}
	return result;
}

}}


#endif /* CCTOP_UTILS_STRINGUTILS_H_ */
