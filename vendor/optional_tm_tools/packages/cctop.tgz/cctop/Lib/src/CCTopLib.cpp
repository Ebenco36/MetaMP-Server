/*
 * CCTOP c++ library for consensus based topology prediction
 * Copyright (C) 2014  Institute of Enzymology, Hungarian Academy of Sciences
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * CCTopLib.cpp
 *
 *  Created on: 2014.07.08.
 *      Author: "Istvan Remenyi"
 */

#include "CCTopLib.h"
#include "CCTopLibDefs.h"
#include "Utils/CalcUtils.h"
#include "Utils/StringUtils.h"
#include "Utils/Xml/rapidxml.hpp"
#include "Core/External/BlastParser.h"
#include "Core/Threads/MembrainThread.h"
#include "Core/Threads/TopConsThread.h"
#include "Core/Threads/PhiliusThread.h"
#include "Core/Threads/PrecheckThreads.h"
#include "Core/Xml/XMLProcessor.h"

#include <sys/stat.h>
#include <iostream>
#include <unistd.h>

//COMMAND PATTERN KEYS
static const char* COMMAND_VARIABLE_EMAIL				= "$EMAIL$";
static const char* COMMAND_VARIABLE_SEQUENCE			= "$SEQUENCE$";
static const char* COMMAND_VARIABLE_SEQFILE				= "$SEQUENCE_FILE$";
static const char* COMMAND_VARIABLE_AC					= "$AC$";
static const char* COMMAND_VARIABLE_CHECKSUM			= "$CHECKSUM$";
static const char* COMMAND_VARIABLE_SPEC_ID				= "$SPEC_ID$";
static const char* COMMAND_VARIABLE_OUTPUT				= "$OUTPUT$";
static const char* COMMAND_VARIABLE_TOPCONS_DIR			= "$TOPCONS_DIR$";
static const char* COMMAND_VARIABLE_MODHMM_DIR			= "$MODHMM_DIR$";
static const char* COMMAND_VARIABLE_TEMP_TOPCON_FOLDER	= "$TEMP_TOPCON_FOLDER$";
static const char* COMMAND_VARIABLE_BLAST_BINARY_FOLDER	= "$BLAST_BINARY_FOLDER$";
static const char* COMMAND_VARIABLE_BLAST_SEQ_FILE		= "$BLAST_SEQ_FILE$";
static const char* COMMAND_VARIABLE_FASTA_LIST			= "$FASTA_LIST$";
static const char* COMMAND_VARIABLE_FASTA_DIR			= "$FASTA_DIR$";
static const char* COMMAND_VARIABLE_MAKEMAT_PATH		= "$MAKEMAT_PATH$";
static const char* COMMAND_VARIABLE_FOLDER				= "$FOLDER$";
static const char* COMMAND_VARIABLE_MEMSAT_TEMP_DIR		= "$MEMSAT_TEMP_DIR$";
static const char* COMMAND_VARIABLE_ID					= "$ID$";
static const char* COMMAND_VARIABLE_CACHE_FOLDER		= "$CACHE_FOLDER$";

//PARAMTER XML
static const char* XML_ELEMENT_CCTOP					= "CCTOP";
static const char* XML_ELEMENT_LIBRARYPARAMS			= "LibraryParams";
static const char* XML_ELEMENT_PARAM					= "Param";
static const char* XML_ELEMENT_WEIGHTS					= "Weights";
static const char* XML_ELEMENT_WEIGHT					= "Weight";
static const char* XML_ELEMENT_ADDITIONALPARAMS			= "AdditionalParams";

static const char* XML_ATTRIBUTE_KEY 					= "key";
static const char* XML_ATTRIBUTE_VALUE					= "value";
static const char* XML_ATTRIBUTE_TYPE					= "type";
static const char* XML_VALUE_INVALID					= "@@";

CCTOP::CCTopLib::CCTopLib()
{}

CCTOP::CCTopLib::CCTopLib(const CCTopLib& copy)
{}

CCTOP::CCTopLib::~CCTopLib()
{}

CCTOP::CCTopLib& CCTOP::CCTopLib::operator=(const CCTopLib& copy)
{return *this;}

CCTOP::Core::MethodContext& CCTOP::CCTopLib::getMethodContext()
{ return _methodContext; }

bool CCTOP::CCTopLib::loadParams(const std::string& paramFile)
{
	bool ret = true;
	if(!paramFile.empty())
	{
		rapidxml::xml_document<> doc;
		std::ifstream theFile (paramFile.c_str());
		if(theFile.is_open())
		{
			std::vector<char> buffer((std::istreambuf_iterator<char>(theFile)), std::istreambuf_iterator<char>());
			buffer.push_back('\0');
			doc.parse<0>(&buffer[0]);

			// Find our root node
			rapidxml::xml_node<>* cctopNode = doc.first_node(XML_ELEMENT_CCTOP);
			if(cctopNode)
			{
				rapidxml::xml_node<>* libParamsNode = cctopNode->first_node(XML_ELEMENT_LIBRARYPARAMS);
				if(libParamsNode)
				{
					for(rapidxml::xml_node<>* paramNode = libParamsNode->first_node(XML_ELEMENT_PARAM) ; paramNode; paramNode = paramNode->next_sibling(XML_ELEMENT_PARAM))
					{
						rapidxml::xml_attribute<>* keyAttr = paramNode->first_attribute(XML_ATTRIBUTE_KEY);
						rapidxml::xml_attribute<>* valueAttr = paramNode->first_attribute(XML_ATTRIBUTE_VALUE);

						if(keyAttr && valueAttr)
						{
							std::string val = valueAttr->value();

							if(val.find(XML_VALUE_INVALID) == std::string::npos)
							{
								Utils::replaceStringInPlace(val, "&amp", "&");
								Utils::replaceStringInPlace(val, "&quot", "\"");
								Utils::replaceStringInPlace(val, "&apos", "'");
								Utils::replaceStringInPlace(val, "&lt", "<");
								Utils::replaceStringInPlace(val, "&gt", ">");

								_libParams[keyAttr->value()] = val;
							}else
							{
								std::cout << "Invalid attribute: " << keyAttr->value() << " = " << val << std::endl;
								ret = false;
							}
						}
					}
				}

				rapidxml::xml_node<>* weightsNode = cctopNode->first_node(XML_ELEMENT_WEIGHTS);
				if(weightsNode)
				{
					for(rapidxml::xml_node<>* wNode = weightsNode->first_node(XML_ELEMENT_WEIGHT) ; wNode; wNode = wNode->next_sibling(XML_ELEMENT_WEIGHT))
					{
						rapidxml::xml_attribute<>* keyAttr = wNode->first_attribute(XML_ATTRIBUTE_KEY);
						rapidxml::xml_attribute<>* typeAttr = wNode->first_attribute(XML_ATTRIBUTE_TYPE);
						rapidxml::xml_attribute<>* valueAttr = wNode->first_attribute(XML_ATTRIBUTE_VALUE);

						if(keyAttr && typeAttr && valueAttr)
						{
							double val = atof(valueAttr->value());

							std::map<std::string, std::map<std::string, double> >::iterator wIter = _weights.find(keyAttr->value());
							if(wIter != _weights.end())
							{
								wIter->second[typeAttr->value()] = val;
							}else
							{
								std::map<std::string, double> temp;
								temp[typeAttr->value()] = val;
								_weights[keyAttr->value()]	= temp;
							}
						}
					}
				}

				rapidxml::xml_node<>* addParamsNode = cctopNode->first_node(XML_ELEMENT_ADDITIONALPARAMS);
				if(addParamsNode)
				{
					for(rapidxml::xml_node<>* paramNode = addParamsNode->first_node(XML_ELEMENT_PARAM) ; paramNode; paramNode = paramNode->next_sibling(XML_ELEMENT_PARAM))
					{
						rapidxml::xml_attribute<>* keyAttr = paramNode->first_attribute(XML_ATTRIBUTE_KEY);
						rapidxml::xml_attribute<>* valueAttr = paramNode->first_attribute(XML_ATTRIBUTE_VALUE);

						if(keyAttr && valueAttr)
							_additionalParams[keyAttr->value()] = atof(valueAttr->value());
					}
				}
			}
			theFile.close();

		}else
		{
			std::cerr << "Can not find file: " << paramFile << std::endl;
		}
	}else
	{
		std::cerr << "No fileName spec.: " << paramFile << std::endl;
	}

	return ret;
}

std::string CCTOP::CCTopLib::getLibParam(const std::string& key) const
{
	std::string ret;
	std::map<std::string, std::string>::const_iterator iter = _libParams.find(key);
	if(iter != _libParams.end())
	{
		ret = iter->second;
	}

	return ret;
}

double CCTOP::CCTopLib::getAdditionalParam(const std::string& key) const
{
	double ret = 0.0;
	std::map<std::string, double>::const_iterator iter = _additionalParams.find(key);
	if(iter != _additionalParams.end())
	{
		ret = iter->second;
	}

	return ret;
}

double CCTOP::CCTopLib::getWeight(const std::string& key, const std::string& type) const
{
	double ret = 0.0;
	std::map<std::string, std::map<std::string, double> >::const_iterator iter = _weights.find(key);
	if(iter != _weights.end())
	{
		std::map<std::string, double>::const_iterator wIter = iter->second.find(type);

		if(wIter != iter->second.end())
		{
			ret = wIter->second;
		}
	}

	return ret;
}

void CCTOP::CCTopLib::initialize(bool ignoreMinMax, bool duplicationEnabled)
{
	_topDBParser.parseGroupFile(getLibParam("TOPDB_XML_PATH"), _methodContext, ignoreMinMax, duplicationEnabled);
}

void CCTOP::CCTopLib::preProcess(Core::SequenceContext& seqContext) const
{
	std::string tempPath(getLibParam("TEMP_DIRECTORY_SEQFILENAME"));
	Utils::replaceStringInPlace(tempPath, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
	Utils::replaceStringInPlace(tempPath, COMMAND_VARIABLE_CACHE_FOLDER, getLibParam("CACHE_FOLDER"));

	std::string filePath(tempPath);

	//check for temp filename
	int i = 0;
	std::stringstream sstream;
	sstream << tempPath;
	sstream << i;
	filePath = sstream.str();

	while(!(access( filePath.c_str(), R_OK|W_OK ) == -1))
	{
		std::stringstream sstream;
		sstream << tempPath;
		sstream << i;
		filePath = sstream.str();
		i++;
	}

	//save seq
	std::cout << "Creating temporary file: " << filePath << std::endl;
	Utils::saveFile(filePath, seqContext.getSequence());
	seqContext.setSequenceFilePath(filePath);

	//Execute
	preProcessFile(seqContext);
}

void CCTOP::CCTopLib::preProcessFile(Core::SequenceContext& seqContext) const
{
	if(!seqContext.getSequence().empty() && !seqContext.getSequenceFilePath().empty())
	{
		//Call UniProt search
		blastUniProt(seqContext);
		if(!seqContext.getUniprotBlastAc().empty())
		{
			propeptideUPSearch(seqContext);
			signalUPSearch(seqContext);
			transitUPSearch(seqContext);
		}

		//Merge TopDB
		blastAndMergeTopDB(seqContext);
	}
}

void  CCTOP::CCTopLib::blastUniProt(Core::SequenceContext& seqContext) const
{
	std::cout << "Blasting Uniprot" << std::endl;
	std::string uniprotBlastCmd(getLibParam("UNIPROT_BLAST_COMMAND"));
	Utils::replaceStringInPlace(uniprotBlastCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
	std::string uniprotBlastXml = Utils::executeCommand(uniprotBlastCmd.c_str());
	_blastParser.parseUniProtResults(uniprotBlastXml, seqContext, getAdditionalParam("UNIPROT_BLAST_LIMIT"));

	if(!seqContext.getUniprotBlastAc().empty())
	{
		std::string nameCmd(getLibParam("UNIPROT_SEARCH_NAME"));
		Utils::replaceStringInPlace(nameCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
		std::string result = Utils::executeCommand(nameCmd.c_str());
		_uniProtParser.parseUniprotName(result, seqContext);

		nameCmd = getLibParam("UNIPROT_SEARCH_ID");
		Utils::replaceStringInPlace(nameCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
		result = Utils::executeCommand(nameCmd.c_str());
		_uniProtParser.parseUniprotId(result, seqContext);

		std::string acCmd(getLibParam("UNIPROT_SEARCH_AC"));
		Utils::replaceStringInPlace(acCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
		result = Utils::executeCommand(acCmd.c_str());
		_uniProtParser.parseUniprotACs(result, seqContext);


		std::string eviCmd(getLibParam("UNIPROT_EVIDENCE"));
		Utils::replaceStringInPlace(eviCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
		result = Utils::executeCommand(eviCmd.c_str());
		_uniProtParser.parseUniprotEvidence(result, seqContext);
	}
}

void  CCTOP::CCTopLib::blastAndMergeTopDB(Core::SequenceContext& seqContext) const
{
	std::cout << "Blasting TOPDB" << std::endl;
	std::string topdbBlastCmd(getLibParam("TOPDB_BLAST_COMMAND"));
	Utils::replaceStringInPlace(topdbBlastCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
	std::string topdbBlastXml = Utils::executeCommand(topdbBlastCmd.c_str());
	//Utils::saveFile("blast_topdb", topdbBlastXml);
	_blastParser.mergeTopDbResults(topdbBlastXml, seqContext, _methodContext);
}

void CCTOP::CCTopLib::propeptideUPSearch(Core::SequenceContext& seqContext) const
{
	std::string uniprotSeatchCmd(getLibParam("UNIPROT_SEARCH_PROPEPTIDE"));
	Utils::replaceStringInPlace(uniprotSeatchCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
	std::string uniProtResultList = Utils::executeCommand(uniprotSeatchCmd.c_str());
	_uniProtParser.parseUniProtPropeptideResults(uniProtResultList, seqContext);
}

void CCTOP::CCTopLib::transitUPSearch(Core::SequenceContext& seqContext) const
{
	std::string uniprotSeatchCmd(getLibParam("UNIPROT_SEARCH_TRANSIT"));
	Utils::replaceStringInPlace(uniprotSeatchCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
	std::string uniProtResultList = Utils::executeCommand(uniprotSeatchCmd.c_str());
	_uniProtParser.parseUniProtTransitResults(uniProtResultList, seqContext);
}

void  CCTOP::CCTopLib::signalUPSearch(Core::SequenceContext& seqContext) const
{
	std::string uniprotSeatchCmd(getLibParam("UNIPROT_SEARCH_SIGNAL"));
	Utils::replaceStringInPlace(uniprotSeatchCmd, COMMAND_VARIABLE_AC, seqContext.getUniprotBlastAc());
	std::string uniProtResultList = Utils::executeCommand(uniprotSeatchCmd.c_str());
	_uniProtParser.parseUniProtSignalResults(uniProtResultList, seqContext);
}

void CCTOP::CCTopLib::transitRegionReduction(Core::SequenceContext& seqContext) const
{
	switch(seqContext.getTransitMode())
	{
	case Core::TRANSITMODE_UNIPROT:
	{
		const std::vector<Core::Region>& regions = seqContext.getTransitRegions();
		std::vector<Core::Region>::const_iterator iter = regions.begin();

		if(regions.size())
		{
			std::stringstream redSeq;
			int lastEnd = 1;
			while(iter != regions.end())
			{
				if(iter == regions.begin())
				{
					if(iter->begin > 1)
						redSeq << seqContext.getSequence().substr(0, iter->begin - 1);
				}else
					if(( iter->begin - lastEnd ) > 1)
						redSeq << seqContext.getSequence().substr(lastEnd-1, iter->begin - lastEnd - 1) ;


				lastEnd = iter->end;

				seqContext.addRemovedTransitRegions(iter->begin, iter->end);

				iter++;
				if(iter == regions.end())
				{
					redSeq << seqContext.getSequence().substr(lastEnd);
				}
			}
			seqContext.setReducedSequence(redSeq.str());
		}
		break;
	}

	case Core::TRANSITMODE_TOPDB:
	{
		if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
		{
			const std::vector<CCTOP::Core::TopDBHit>& topdbHits = seqContext.getTopDBHits();
			if(topdbHits.size() > 0)
			{
				std::vector<CCTOP::Core::TopDBHit>::const_iterator iter = topdbHits.begin();
				if(iter != topdbHits.end())
				{
					std::vector<Core::TopologyEntry>::const_iterator sIter = iter->topology.begin();
					while(sIter != iter->topology.end())
					{
						if(sIter->loc == Core::LOCALIZATION_TRANSIT)
						{
							seqContext.addRemovedTransitRegions(sIter->beg, sIter->end);
						}
						sIter++;
					}

					seqContext.setReducedSequence(iter->reducedSeq);
				}
			}
		}
		break;
	}

	case Core::TRANSITMODE_EXT:
	{
		const std::vector<Core::Region>& regions = seqContext.getTransitRegions();
		std::vector<Core::Region>::const_iterator iter = regions.begin();
		if(regions.size())
		{
			std::stringstream redSeq;
			int lastEnd = 1;
			while(iter != regions.end())
			{
				if(iter == regions.begin())
				{
					if(iter->begin > 1)
						redSeq << seqContext.getSequence().substr(0, iter->begin - 1);
				}else
					if(( iter->begin - lastEnd ) > 1)
						redSeq << seqContext.getSequence().substr(lastEnd-1, iter->begin - lastEnd - 1) ;


				lastEnd = iter->end;

				seqContext.addRemovedTransitRegions(iter->begin, iter->end);

				iter++;
				if(iter == regions.end())
				{
					redSeq << seqContext.getSequence().substr(lastEnd);
				}
			}
			seqContext.setReducedSequence(redSeq.str());
		}

		if(!seqContext.getTransitRegions().size())
		{
			const std::vector<CCTOP::Core::TopDBHit>& topdbHits = seqContext.getTopDBHits();
			if(topdbHits.size() > 0 && !seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
			{
				std::vector<CCTOP::Core::TopDBHit>::const_iterator iter = topdbHits.begin();
				if(iter != topdbHits.end())
				{
					std::vector<Core::TopologyEntry>::const_iterator sIter = iter->topology.begin();
					while(sIter != iter->topology.end())
					{
						if(sIter->loc == Core::LOCALIZATION_TRANSIT)
						{
							seqContext.addRemovedTransitRegions(sIter->beg, sIter->end);
						}
						sIter++;
					}

					seqContext.setReducedSequence(iter->reducedSeq);
				}
			}
		}

		break;
	}

	default:
		seqContext.setReducedSequence(seqContext.getSequence());
	}

	if(!seqContext.getRemovedTransitRegions().size())
	{
		seqContext.setReducedSequence(seqContext.getSequence());
	}

	seqContext.applyRemovedTransitRegions();
}

void CCTOP::CCTopLib::signalRegionReduction(Core::SequenceContext& seqContext) const
{
	//Signaling
	//remove signalregion - different modes!
	switch (seqContext.getSignalMode())
	{
		case Core::SIGNALMODE_UNIPROT:
		{
			std::string newSequence;

			std::vector<Core::Region>& sRegions = seqContext.getSignalRegions();
			std::vector<Core::Region>::iterator sIter = sRegions.begin();

			if(sRegions.size())
			{
				std::stringstream str;
				int lastEnd = 1;
				while(sIter != sRegions.end())
				{
					if(sIter == sRegions.begin()
							&& sIter->begin > 1 )
					{
						str << seqContext.getReducedSequence().substr(0, sIter->begin-1);
					}else
						if(( sIter->begin - lastEnd ) > 1)
							str << seqContext.getReducedSequence().substr(lastEnd, sIter->begin - lastEnd - 1) ;

					lastEnd = sIter->end;
					seqContext.addRemovedSignalRegions(sIter->begin, sIter->end);
					Core::Region reg;
					reg.begin = sIter->begin;
					reg.end = sIter->end;
					seqContext.getSignalRegionMap()[Core::SIGNALMODE_UNIPROT] = reg;
					sIter++;
				}

				if(lastEnd < (int)seqContext.getReducedSequence().length()) //note: position has +1, so '<=' -> '<'!!
				{
					str << seqContext.getReducedSequence().substr(lastEnd);
				}
				seqContext.setSignalReducedSequence(str.str());
			}else
			{
				seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
			}

			break;
		}
		case Core::SIGNALMODE_SIGNALP:
		{
			std::string newSequence;
			std::string signalPCmd(getLibParam("SIGNALP_SEARCH"));
			Utils::replaceStringInPlace(signalPCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
			std::string signalPRes = Utils::executeCommand(signalPCmd.c_str());
			_signalParser.parseSignalPResults(signalPRes, seqContext);
			if(seqContext.getSignalPPos() > 0)
			{
				newSequence = seqContext.getReducedSequence().substr(seqContext.getSignalPPos());
				seqContext.setSignalReducedSequence(newSequence);
				seqContext.addRemovedSignalRegions(1, seqContext.getSignalPPos());
				Core::Region reg;
				reg.begin = 1;
				reg.end = seqContext.getSignalPPos();
				seqContext.getSignalRegionMap()[Core::SIGNALMODE_SIGNALP] = reg;
			}else
			{
				seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
			}

			break;
		}
		case Core::SIGNALMODE_TOPDB:
		{
			std::string newSequence;
			const std::vector<CCTOP::Core::TopDBHit>& topdbHits = seqContext.getTopDBHits();
			if(topdbHits.size() > 0 && !seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
			{
				std::vector<CCTOP::Core::TopDBHit>::const_iterator iter = topdbHits.begin();
				if(iter != topdbHits.end() && iter->signalEnd > -1)
				{
					std::stringstream str;
					int lastEnd = 1;
					std::vector<Core::TopologyEntry>::const_iterator sIter = iter->topology.begin();
					bool firstTopology = true;
					while(sIter != iter->topology.end())
					{
						if(sIter->loc == Core::LOCALIZATION_SIGNAL)
						{
							if(firstTopology && sIter->beg > 1 )
							{
								str << seqContext.getReducedSequence().substr(0, sIter->beg-1);
							}else
								if(( sIter->beg - lastEnd ) > 1)
									str << seqContext.getReducedSequence().substr(lastEnd, sIter->beg - lastEnd - 1) ;

							lastEnd = sIter->end;
							firstTopology = false;
							seqContext.addRemovedSignalRegions(sIter->beg, sIter->end);
							Core::Region reg;
							reg.begin = sIter->beg;
							reg.end = sIter->end;
							seqContext.getSignalRegionMap()[Core::SIGNALMODE_TOPDB] = reg;
						}
						sIter++;
					}

					if(lastEnd < (int)seqContext.getReducedSequence().length()) //note: position has +1, so '<=' -> '<'!!
					{
						str << seqContext.getReducedSequence().substr(lastEnd);
					}
					seqContext.setSignalReducedSequence(str.str());
				}else
				{
					seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
				}
			}else
			{
				seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
			}
			break;
		}
		case Core::SIGNALMODE_UNIPROT_EN:
		{
			std::string newSequence;
			bool hasTopDBSignalRegion = false;
			const std::vector<CCTOP::Core::TopDBHit>& topdbHits = seqContext.getTopDBHits();
			if(topdbHits.size() > 0)// && !seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB))
			{
				std::vector<CCTOP::Core::TopDBHit>::const_iterator iter = topdbHits.begin();
				hasTopDBSignalRegion = iter->hasSignalRegion;
				if(iter->signalEnd > -1)
				{
					std::stringstream str;
					int lastEnd = 1;
					std::vector<Core::TopologyEntry>::const_iterator sIter = iter->topology.begin();
					bool firstTopology = true;
					while(sIter != iter->topology.end())
					{
						if(sIter->loc == Core::LOCALIZATION_SIGNAL)
						{
							if(firstTopology && sIter->beg > 1 )
							{
								str << seqContext.getReducedSequence().substr(0, sIter->beg-1);
							}else
								if(( sIter->beg - lastEnd ) > 1)
									str << seqContext.getReducedSequence().substr(lastEnd, sIter->beg - lastEnd - 1) ;

							lastEnd = sIter->end;
							firstTopology = false;
							seqContext.addRemovedSignalRegions(sIter->beg, sIter->end);

							Core::Region reg;
							reg.begin = sIter->beg;
							reg.end = sIter->end;
							seqContext.getSignalRegionMap()[Core::SIGNALMODE_TOPDB] = reg;
						}
						sIter++;
					}

					if(lastEnd < (int)seqContext.getReducedSequence().length()) //note: position has +1, so '<=' -> '<'!!
					{
						str << seqContext.getReducedSequence().substr(lastEnd);
					}
					newSequence = str.str();
				}
			}

			//SignalP
			if((/*seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDB) ||*/ hasTopDBSignalRegion) && !newSequence.length())
			{
				std::string signalPCmd(getLibParam("SIGNALP_SEARCH"));
				Utils::replaceStringInPlace(signalPCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
				std::string signalPRes = Utils::executeCommand(signalPCmd.c_str());
				_signalParser.parseSignalPResults(signalPRes, seqContext);
				if(seqContext.getSignalPPos() > 0)
				{
					newSequence = seqContext.getReducedSequence().substr(seqContext.getSignalPPos()-1);
					seqContext.addRemovedSignalRegions(1, seqContext.getSignalPPos());

					Core::Region reg;
					reg.begin = 1;
					reg.end = seqContext.getSignalPPos();
					seqContext.getSignalRegionMap()[Core::SIGNALMODE_SIGNALP] = reg;
				}
			}
			if(!newSequence.empty())
			{
				seqContext.setSignalReducedSequence(newSequence);
			}else
			{
				seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
			}
			break;
		}

		default:
			seqContext.setSignalReducedSequence(seqContext.getReducedSequence());
			break;
	}
}

void CCTOP::CCTopLib::process(Core::SequenceContext& seqContext, std::string& result) const
{
	transitRegionReduction(seqContext);

	std::cout << "Saveing temporary file: " << seqContext.getSequenceFilePath() << std::endl;
	//Utils::saveFile(seqContext.getSequenceFilePath(), seqContext.getReducedSequence());
	{
		std::stringstream stream;
		stream << ">" << seqContext.getCCTopID() << "\n";
		stream << Utils::replaceString(seqContext.getReducedSequence(), "-", "");
		Utils::saveFile(seqContext.getSequenceFilePath(), stream.str());
	}

	signalRegionReduction(seqContext);

	//crap philius needs a space in the seq name, else does not run...
	std::cout << "Updateing temporary file: " << seqContext.getSequenceFilePath() << std::endl;
	std::stringstream stream;
	stream << ">" << getLibParam("TEMP_SEQFILENAME") << " 1\n";
	stream << Utils::replaceString(seqContext.getSignalReducedSequence(), "-", "");
	Utils::saveFile(seqContext.getSequenceFilePath(), stream.str());


	std::cerr << "Transit rem.:" << seqContext.getReducedSequence().length()  << seqContext.getReducedSequence() << std::endl;
	std::cerr << "Signal rem.:" << seqContext.getSignalReducedSequence().length() << " " << seqContext.getSignalReducedSequence() << std::endl;

	bool isNTerminalOutSide = false;
	if(seqContext.getRemovedSignalRegions().size())
	{
		seqContext.applyRemovedSignalRegions();

		/*std::vector<CCTOP::Core::TopDBHit>::iterator iter = seqContext.getTopDBHits().begin();
		if(iter != seqContext.getTopDBHits().end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = iter->topology.begin();
			while(topoIter != iter->topology.end()
					&& !isNTerminalOutSide)
			{
				if(topoIter->beg == 1
						&& topoIter->loc == CCTOP::Core::LOCALIZATION_OUTSIDE)
				{*/
					isNTerminalOutSide = true;
			/*	}
				topoIter++;
			}
		}*/
	}else
	{
		std::cerr << "SignalCount: " << seqContext.getRemovedSignalRegions().size() << std::endl;
	}
	seqContext.setNTerminalOutSide(isNTerminalOutSide);
	std::cerr << "setNTerminalOutSide: " << isNTerminalOutSide << std::endl;

	void** retVal = NULL;
	Core::Threads::PhobiousThread phobiousThread(*this);
	phobiousThread.setSequenceContext(&seqContext);
	phobiousThread.start();
	Core::Threads::ScampiThread scampiThread(*this);
	scampiThread.setSequenceContext(&seqContext);
	scampiThread.start();
	Core::Threads::TMHMMThread tmhmmThread(*this);
	tmhmmThread.setSequenceContext(&seqContext);
	tmhmmThread.start();

	phobiousThread.join(retVal);
	scampiThread.join(retVal);
	tmhmmThread.join(retVal);

	if(tmFilter(seqContext))
	{
		Core::Threads::TopConsThread tcThread(*this);
		tcThread.setSequenceContext(&seqContext);
		tcThread.start();
		///methodCallTOPCONS(seqContext);

		Core::Threads::MembrainThread* mThread = NULL;
		if(_methodContext.isMembrainActive())
		{
			mThread = new Core::Threads::MembrainThread(*this);
			mThread->setSequenceContext(&seqContext);
			mThread->start();
			//methodCallMemBrain(seqContext);
		}

		Core::Threads::MemsatThread msatThread(*this);
		msatThread.setSequenceContext(&seqContext);
		msatThread.start();
		//methodCallTopDom(seqContext);
		//methodCallMemsat(seqContext);

		Core::Threads::PhiliusThread phThread(*this);
		phThread.setSequenceContext(&seqContext);
		phThread.start();
		//methodCallPhobious(seqContext);
		//methodCallPhilius(seqContext);


		phThread.join(retVal);
		tcThread.join(retVal);
		msatThread.join(retVal);
		if(mThread)
		{
			mThread->join(retVal);
			delete mThread;
		}

		//delete temp file
		if(!remove(seqContext.getSequenceFilePath().c_str()))
		{
			std::cout << "Deleting temporary file: " << seqContext.getSequenceFilePath() << std::endl;
		}

		//call hmmtop&weightening
		_hmmTopLink.callHMMTOP(*this, _methodContext, seqContext, true);
		_hmmTopLink.callHMMTOP(*this, _methodContext, seqContext, false);

		seqContext.validateTopology();
	}
	//readd signal regions
	seqContext.undoRemovedSignalRegions();
	seqContext.undoRemovedTransitRegions();

	Core::XML::XMLProcessor xmlProc(*this);
	std::string copyRight(getLibParam("CCTOP_COPYRIGHT"));
	xmlProc.createXML(seqContext, _methodContext, result, seqContext.getCCTopID(), copyRight);

	//std::cerr << result.c_str() << std::endl;
}

void CCTOP::CCTopLib::update(Core::SequenceContext& seqContext, const std::string& oldResultFile, std::string& result) const
{
	bool isTr = false;
	Core::XML::XMLProcessor xmlProc(*this);
	xmlProc.parse(seqContext, _methodContext, oldResultFile, isTr);

	preProcess(seqContext);

	transitRegionReduction(seqContext);

	std::cout << "Saveing temporary file: " << seqContext.getSequenceFilePath() << std::endl;
	//Utils::saveFile(seqContext.getSequenceFilePath(), seqContext.getReducedSequence());
	std::stringstream stream;
	stream << ">" << seqContext.getCCTopID() << "\n";
	stream << Utils::replaceString(seqContext.getReducedSequence(), "-", "");
	Utils::saveFile(seqContext.getSequenceFilePath(), stream.str());

	signalRegionReduction(seqContext);

	std::cerr << "Transit rem.:" << seqContext.getReducedSequence().length()  << seqContext.getReducedSequence() << std::endl;
	std::cerr << "Signal rem.:" << seqContext.getSignalReducedSequence().length() << " " << seqContext.getSignalReducedSequence() << std::endl;

	bool isNTerminalOutSide = false;
	if(seqContext.getRemovedSignalRegions().size())
	{
		seqContext.applyRemovedSignalRegions();

		std::vector<CCTOP::Core::TopDBHit>::iterator iter = seqContext.getTopDBHits().begin();
		if(iter != seqContext.getTopDBHits().end())
		{
			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = iter->topology.begin();
			while(topoIter != iter->topology.end()
					&& !isNTerminalOutSide)
			{
				if(topoIter->beg == 1
						&& topoIter->loc == CCTOP::Core::LOCALIZATION_OUTSIDE)
				{
					isNTerminalOutSide = true;
				}
				topoIter++;
			}
		}
	}else
	{
		std::cerr << "SignalCount: " << seqContext.getRemovedSignalRegions().size() << std::endl;
	}
	seqContext.setNTerminalOutSide(isNTerminalOutSide);

	//delete temp file
	if(!remove(seqContext.getSequenceFilePath().c_str()))
	{
		std::cout << "Deleting temporary file: " << seqContext.getSequenceFilePath() << std::endl;
	}

	//call hmmtop&weightening
	_hmmTopLink.callHMMTOP(*this, _methodContext, seqContext, true);
	_hmmTopLink.callHMMTOP(*this, _methodContext, seqContext, false);

	seqContext.validateTopology();

	//readd signal regions
	seqContext.undoRemovedSignalRegions();
	seqContext.undoRemovedTransitRegions();

	std::string copyRight(getLibParam("CCTOP_COPYRIGHT"));
	xmlProc.createXML(seqContext, _methodContext, result, seqContext.getCCTopID(), copyRight);

	//std::cerr << result.c_str() << std::endl;
}

bool CCTOP::CCTopLib::tmFilter(Core::SequenceContext& seqContext) const
{
	bool ret = !seqContext.useTMFilter();

	if(!ret)
	{
		int tmMethodCount = 0;
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >& methodHits = seqContext.getMethodHits();
		std::map<std::string, std::vector<CCTOP::Core::TopologyEntry> >::iterator methodIter = methodHits.begin();
		while(methodIter != methodHits.end())
		{
			bool hasTmReg = false;

			std::vector<CCTOP::Core::TopologyEntry>::iterator topoIter = methodIter->second.begin();
			while( topoIter != methodIter->second.end()
					&& !hasTmReg)
			{
				hasTmReg = topoIter->loc == CCTOP::Core::LOCALIZATION_MEMBRANE;
				topoIter++;
			}

			if(hasTmReg)
				tmMethodCount++;
			methodIter++;
		}

		ret = tmMethodCount>1;
		seqContext.setTransmembrane(ret);
	}

	return ret;
}

void CCTOP::CCTopLib::methodCallTMHMM(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TMHMM))
	{
		std::string tmhmmCmd(getLibParam("TMHMM_METHOD_EXEC"));
		Utils::replaceStringInPlace(tmhmmCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
		std::string tmhmmResult = Utils::executeCommand(tmhmmCmd.c_str());
		_methodParser.parseTMHMM(tmhmmResult, seqContext);
	}
}

void CCTOP::CCTopLib::methodCallPhobious(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PHOBIOUS))
	{
		std::string phobiusCmd(getLibParam("PHOBIUS_METHOD_EXEC"));
		Utils::replaceStringInPlace(phobiusCmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
		std::string phobiusResult = Utils::executeCommand(phobiusCmd.c_str());
		std::cerr << "Phobious:" << phobiusCmd.c_str() << std::endl;
		_methodParser.parsePhobious(phobiusResult, seqContext);
	}
}

void CCTOP::CCTopLib::methodCallPhilius(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PHILIUS))
	{
		std::string cmd(getLibParam("PHILIUS_METHOD_EXEC"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
		std::string result = Utils::executeCommand(cmd.c_str());

		cmd = getLibParam("PHILIUS_METHOD_OUTPUT");
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
		Utils::loadFile(cmd, result);
		_methodParser.parsePhilius(result, seqContext);

		cmd = getLibParam("PHILIUS_METHOD_CLEAN");
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
		Utils::executeCommand(cmd.c_str());
	}
}


void CCTOP::CCTopLib::methodCallMemBrain(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_MEMBRAIN))
	{
		std::string cmd(getLibParam("MEMBRAIN_METHOD_EXEC"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SEQUENCE, seqContext.getSignalReducedSequence());
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_EMAIL, getLibParam("DEFAULT_EMAIL"));
		std::string result = Utils::executeCommand(cmd.c_str());
		result = _methodParser.parseMemBrainInvoke(result, seqContext);

		if(!result.empty())
		{
			std::string textId;
			hackMemBrain(result, textId);

			if(!textId.empty())
			{
				sleep(40);
				cmd = getLibParam("MEMBRAIN_METHOD_RESULT");
				Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SPEC_ID, textId);
				result = Utils::executeCommand(cmd.c_str());
				long elapsed = 40;//sec
				long limit = getAdditionalParam("MEMBRAIN_WAIT_LIMIT");
				if(!limit) limit = 7200;
				while(!_methodParser.parseMemBrain(result, seqContext)
						&& elapsed < limit)
				{
					std::cerr << "Waiting for membrain!" << std::endl;
					sleep(20);
					elapsed+=20;
					result = Utils::executeCommand(cmd.c_str());
				}
			}else
			{
				std::cerr << "\n\n!!MEMBRAINID IS NOT RESOLVED!!!\n\n" << std::endl;
			}
		}else
		{
			std::cerr << "\n\n!!MEMBRAIN IS DOWN!!!\n\n" << std::endl;
		}
	}
}

void CCTOP::CCTopLib::hackMemBrain(const std::string& incomingHash, std::string& textId) const
{
	std::vector<int> uid;
	for(int i = 0; i < (double)incomingHash.size()/2.0;i++)
	{
		if(incomingHash.at(2*i) == '0')
		{
			uid.push_back(0);
		}else
		{
			if(incomingHash.at(2*i) == '9')
			{
				uid.push_back(27);
			}else
			{
				uid.push_back(incomingHash.at(2*i)-96);
			}
		}
	}

	for(int i = (int)uid.size() - 1; i >= 0; i--)
	{
		if(i == (int)uid.size() - 1)
		{
			uid[i] = uid[i] / 3;
		}
		else
		{
			uid[i] = (uid[i] - uid[uid.size()-1]) / 2;
		}
	}

	std::stringstream str;
	for(int i = 0; i < (int)uid.size(); i++)
	{
		str << uid[i];
	}
	textId = str.str();
	std::cerr << "Resolving id from MemBrain:" << incomingHash << " -> " << textId << std::endl;
}

void CCTOP::CCTopLib::methodCallTOPCONS(Core::SequenceContext& seqContext) const
{
	std::string tmpDir(getLibParam("TOPCON_TEMP_DIR"));
	Utils::replaceStringInPlace(tmpDir, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
	mkdir(tmpDir.c_str(), 0777);

	//methodCallScampi(seqContext, tmpDir);
	methodCallScampiMsa(seqContext, tmpDir);
	methodCallProAndProDiv(seqContext, tmpDir);
	methodCallOctopus(seqContext, tmpDir);

	std::string rmDir(getLibParam("METHOD_CLEAN"));
	Utils::replaceStringInPlace(rmDir, COMMAND_VARIABLE_FOLDER, tmpDir.c_str());

	Utils::executeCommand(rmDir.c_str());
}

void CCTOP::CCTopLib::methodCallScampi(Core::SequenceContext& seqContext) const
{
	std::string tmpDir(getLibParam("TOPCON_TEMP_DIR"));
	Utils::replaceStringInPlace(tmpDir, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
	mkdir(tmpDir.c_str(), 0777);

	methodCallScampi(seqContext, tmpDir);

	std::string rmDir(getLibParam("METHOD_CLEAN"));
	Utils::replaceStringInPlace(rmDir, COMMAND_VARIABLE_FOLDER, tmpDir.c_str());

	Utils::executeCommand(rmDir.c_str());
}

void CCTOP::CCTopLib::methodCallMemsat(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_MEMSAT))
	{
		std::string tmpDir(getLibParam("MEMSAT_TEMP_DIR"));
		Utils::replaceStringInPlace(tmpDir, COMMAND_VARIABLE_CHECKSUM, seqContext.getSequenceChecksum());
		mkdir(tmpDir.c_str(), 0777);

		std::string uniqueName = seqContext.getCCTopID();
		if(uniqueName.empty())
			uniqueName = seqContext.getSequenceChecksum();
		if(uniqueName.empty())
			uniqueName = getLibParam("TEMP_SEQFILENAME");

		std::string fastaName(tmpDir + "/" + getLibParam("TEMP_FASTAFILENAME"));
		Utils::saveFile(fastaName, std::string(uniqueName)+"\n");
		std::stringstream stream;
		stream << ">" <<uniqueName << "\n";
		stream << Utils::replaceString(seqContext.getSignalReducedSequence(), "-", "");
		Utils::saveFile(tmpDir + "/" + uniqueName + ".fa", stream.str());

		std::string cmd(getLibParam("MEMSAT_EXEC"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_FASTA_DIR, tmpDir);
		std::string result = Utils::executeCommand(cmd.c_str());

		std::string outputName = getLibParam("MEMSAT_RESULT_GLOB");
		Utils::replaceStringInPlace(outputName, COMMAND_VARIABLE_MEMSAT_TEMP_DIR, tmpDir);
		Utils::replaceStringInPlace(outputName, COMMAND_VARIABLE_ID, uniqueName);
		std::string content;
		Utils::loadFile(outputName, content);
		if(_methodParser.parseMemsatGlob(content, seqContext))
		{
			std::string outputName = getLibParam("MEMSAT_RESULT");
			Utils::replaceStringInPlace(outputName, COMMAND_VARIABLE_MEMSAT_TEMP_DIR, tmpDir);
			Utils::replaceStringInPlace(outputName, COMMAND_VARIABLE_ID, uniqueName);
			std::string content;
			Utils::loadFile(outputName, content);
			_methodParser.parseMemsat(content, seqContext);
		}


		std::string rmDir(getLibParam("METHOD_CLEAN"));
		Utils::replaceStringInPlace(rmDir, COMMAND_VARIABLE_FOLDER, tmpDir.c_str());

		Utils::executeCommand(rmDir.c_str());
	}
}


void CCTOP::CCTopLib::methodCallScampiMsa(Core::SequenceContext& seqContext, const std::string& tmpDir) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_SCAMPIMSA))
	{
		std::string cmd(getLibParam("SCAMPIMSA_METHOD_EXEC"));
		std::string outputName = tmpDir + "/" + getLibParam("SCAMPIMSA_OUTPUTFILENAME");
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TOPCONS_DIR, getLibParam("TOPCONS_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_OUTPUT, outputName);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_BINARY_FOLDER, getLibParam("BLAST_BIN_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_SEQ_FILE, getLibParam("BLAST_SEQ_FILE"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TEMP_TOPCON_FOLDER, tmpDir);

		std::cerr << "Scampi msa:" << cmd << std::endl;
		std::string result = Utils::executeCommand(cmd.c_str());
		if(!result.empty())
		{
			std::string content;
			Utils::loadFile(outputName, content);

			_methodParser.parseScampiMsa(content, seqContext);
		}
	}
}


void CCTOP::CCTopLib::methodCallTopDom(Core::SequenceContext& seqContext) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_TOPDOM))
	{
		std::string cmd(getLibParam("TOPDOM_METHOD_EXEC"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SEQUENCE, seqContext.getSignalReducedSequence());
		std::string result = Utils::executeCommand(cmd.c_str());
		if(!result.empty())
		{
			/*if(result.find("Home</a></li>") == std::string::npos)
				Utils::replaceStringInPlace(result, "<li ><a href=\"?m=home\">Home</a>", "<li ><a href=\"?m=home\">Home</a></li>");*/
			/*if(result.find("/tr></fieldset>") != std::string::npos)
				Utils::replaceStringInPlace(result, "/tr></fieldset>", "/tr></table></center></fieldset>");*/


			std::cerr << result << std::endl;
			_methodParser.parseTopDom(result, seqContext, getLibParam("TOPDOM_METHOD_SUB_EXEC"));
		}
	}
}

void CCTOP::CCTopLib::methodCallProAndProDiv(Core::SequenceContext& seqContext, const std::string& tmpDir) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PRO) ||
			!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PRODIV))
	{
		std::string cmd(getLibParam("PROANDPRODIV_METHOD_EXEC"));
		std::string fastaName(tmpDir + "/" + getLibParam("TEMP_FASTAFILENAME"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_FASTA_LIST, fastaName);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_FASTA_DIR, tmpDir);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TEMP_TOPCON_FOLDER, tmpDir);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_BINARY_FOLDER, getLibParam("BLAST_BIN_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_SEQ_FILE, getLibParam("BLAST_SEQ_FILE"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TOPCONS_DIR, getLibParam("TOPCONS_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_MODHMM_DIR, getLibParam("MODHMM_DIR"));

		Utils::saveFile(fastaName, std::string(getLibParam("TEMP_SEQFILENAME"))+"\n");
		std::stringstream stream;
		stream << ">" << getLibParam("TEMP_SEQFILENAME") << "\n";
		stream << Utils::replaceString(seqContext.getSignalReducedSequence(), "-", "");
		Utils::saveFile(tmpDir + "/" + getLibParam("TEMP_SEQFILENAME") + ".fa", stream.str());

		std::string result = Utils::executeCommand(cmd.c_str());
		if(!result.empty())
		{
			if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PRO))
			{
				std::string outputName = tmpDir + "/" + getLibParam("PRO_OUTPUTFILENAME");
				std::string content;
				Utils::loadFile(outputName, content);

				_methodParser.parsePro(content, seqContext);
			}

			if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_PRODIV))
			{
				std::string outputName = tmpDir + "/" + getLibParam("PRODIV_OUTPUTFILENAME");
				std::string content;
				Utils::loadFile(outputName, content);

				_methodParser.parseProDiv(content, seqContext);
			}
		}
	}
}

void CCTOP::CCTopLib::methodCallOctopus(Core::SequenceContext& seqContext, const std::string& tmpDir) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_OCTOPUS))
	{
		std::string cmd(getLibParam("OCTOPUS_METHOD_EXEC"));
		std::string fastaName(tmpDir + "/" + getLibParam("TEMP_FASTAFILENAME"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_FASTA_LIST, fastaName);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_FASTA_DIR, tmpDir);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TEMP_TOPCON_FOLDER, tmpDir);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_BINARY_FOLDER, getLibParam("BLAST_BIN_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_BLAST_SEQ_FILE, getLibParam("BLAST_SEQ_FILE"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TOPCONS_DIR, getLibParam("TOPCONS_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_MODHMM_DIR, getLibParam("MODHMM_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_MAKEMAT_PATH, getLibParam("MAKEMAT_EXE"));


		std::string result = Utils::executeCommand(cmd.c_str());
		std::cerr << result << std::endl;
		if(!result.empty())
		{
			std::string outputName = tmpDir + "/" + getLibParam("OCTOPUS_OUTPUTFILENAME");
			std::string content;
			Utils::loadFile(outputName, content);

			_methodParser.parseOctopus(content, seqContext);
		}
	}
}

void CCTOP::CCTopLib::methodCallScampi(Core::SequenceContext& seqContext, const std::string& tmpDir) const
{
	if(!seqContext.isMethodDisabled(CCTOPLIB_METHOD_SCAMPI))
	{
		std::string cmd(getLibParam("SCAMPISINGLE_METHOD_EXEC"));
		std::string outputName(tmpDir + "/" + getLibParam("SCAMPI_OUTPUTFILENAME"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TOPCONS_DIR, getLibParam("TOPCONS_DIR"));
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_SEQFILE, seqContext.getSequenceFilePath());
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_OUTPUT, outputName);
		Utils::replaceStringInPlace(cmd, COMMAND_VARIABLE_TEMP_TOPCON_FOLDER, tmpDir);
		std::cerr << "SCAMPI: " << cmd << std::endl;

		std::string result = Utils::executeCommand(cmd.c_str());
		std::string content;
		Utils::loadFile(outputName, content);

		_methodParser.parseScampi(content, seqContext);
	}
}

